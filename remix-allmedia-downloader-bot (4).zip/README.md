# 🤖 Telegram-boy — Standalone Headless Media Downloader Bot

ربات تلگرام کاملاً مستقل، ایمن و بهینه‌شده برای اجرای ۲۴ ساعته روی **AWS EC2 (Linux)** با **PM2** یا **Docker** — بدون هیچ‌گونه وابستگی به وب‌سایت، Vite، React یا Google AI Studio.

---

## 🏗 معماری ماژولار پروژه

```text
src/
├── index.ts                      # نقطه شروع واحد (Startup، SQLite Init، Health Monitor، Lockfile، Shutdown)
├── api/
│   └── httpServer.ts             # API داخلی محدود به localhost (Healthcheck، Webhook و مدیریت محافظت‌شده)
├── bot/
│   └── telegramBot.ts            # هسته ربات تلگرام (Polling پایدار، Backoff، سهمیه روزانه، عضویت اجباری، ضداسپم)
├── services/
│   ├── database.ts               # دیتابیس پایدار SQLite (حالت WAL، Migration خودکار، Backup/Restore آنلاین، Audit Log)
│   ├── configManager.ts          # مدیریت تنظیمات، نقش‌ها و مجوزهای RBAC، کاربران و تاریخچه درخواست‌ها
│   ├── adminPanel.ts             # موتور امن پنل مدیریت (/admin) با بررسی مجوز سرور، Nonce یک‌بارمصرف و Broadcast ایمن
│   ├── adminPanelViews.ts        # رابط شیشه‌ای تمام‌فارسی بخش‌های ده‌گانه پنل مدیریت درون تلگرام
│   ├── controlService.ts         # مانیتورینگ منابع سرور، اکشن‌های کنترل‌شده ایمن و هشدارهای هوشمند به Owner
│   ├── secretsManager.ts         # بازرسی امن Secretها (بدون افشای مقدار واقعی) و راهنمای چرخش در AWS Secrets Manager/SSM
│   ├── mediaDownloader.ts        # موتور دانلود با yt-dlp + ffmpeg، صف هم‌زمانی، لغو دانلود فعال و کنترل دیسک
│   ├── mediaParser.ts            # تحلیلگر لینک، نوار پیشرفت زنده، پلتفرم‌یاب و عضویت اجباری
│   └── spotifyResolver.ts        # استخراج اطلاعات ترک/آلبوم/پلی‌لیست اسپاتیفای و دانلود صوت از منابع مجاز
└── utils/
    └── resilience.ts             # محافظ SSRF، Semaphore هم‌زمانی، Rate Limiter، Backoff و PID Lockfile
```

---

## 👑 پنل مدیریت حرفه‌ای داخل تلگرام (`/admin`)

تمام تنظیمات، کاربران، مدیران، دانلودها، سرویس Spotify و وضعیت سرور بدون نیاز به وب‌سایت مستقیماً از داخل تلگرام قابل مدیریت هستند:

- **احراز هویت و کنترل دسترسی (RBAC):** شناسایی مدیران **فقط با Telegram User ID عددی (`from.id`)** با ۴ نقش `Owner`، `Super Admin`، `Admin` و `Support` و مجوزدهی تفکیکی برای هر بخش.
- **حفاظت‌های امنیتی پنل:** بررسی مجوز سمت سرور روی تک‌تک دکمه‌ها، ابطال Callbackهای قدیمی (> ۲۴ ساعت)، تایید دومرحله‌ای با توکن یک‌بارمصرف (`adm:cfm`) برای اکشن‌های حساس، ثبت تمام تلاش‌های غیرمجاز در `audit_logs` با اطلاع‌رسانی به مالک، و سانسور خودکار Secretها.
- **بخش‌های پنل مدیریت:**
  1. **تنظیمات عمومی:** روشن/خاموش کردن ربات، حالت نگهداری (Maintenance)، ثبت‌نام کاربران جدید، پیام‌های خوش‌آمدگویی/راهنما/خطا/پشتیبانی و کانال اعلان‌ها.
  2. **مدیریت دانلود:** فعال/غیرفعال‌سازی دانلود، سقف حجم فایل، تایم‌اوت، هم‌زمانی، سهمیه روزانه کاربر، فرمت/کیفیت پیش‌فرض، مشاهده و لغو دانلودهای در حال اجرا، پاکسازی فایل‌های موقت و خطاهای اخیر.
  3. **پنل اختصاصی Spotify:** تنظیمات مستقل تک‌آهنگ/آلبوم/پلی‌لیست، کیفیت، ترجیح MP3/320k، سقف ترک، تست اتصال و لاگ خطاها (با رعایت منابع مجاز عمومی و بدون افشای Client Secret).
  4. **مدیریت کاربران و ارسال همگانی:** جستجو با ID، پروفایل و تاریخچه کاربر، مسدود/رفع مسدودیت، سهمیه اختصاصی، پیام مستقیم و Broadcast زمان‌بندی‌شده مقاوم در برابر `429 retry_after` و `403`.
  5. **مدیریت مدیران، امنیت، سرور، بکاپ و ابزارهای نگهداری:** افزودن/ویرایش/مسدودسازی مدیر، مشاهده `audit_logs` غیرقابل دستکاری، متریک‌های RAM/CPU/Disk، اکشن‌های کنترل‌شده، Backup/Restore آنلاین با `integrity_check` و `VACUUM`.

---

## 🔒 امنیت، Secretها و متغیرهای محیطی

تمام توکن‌ها، کلیدها و کوکی‌ها فقط در `.env` یا سرویس‌های **AWS Secrets Manager** / **AWS Systems Manager Parameter Store** (با IAM Role روی EC2) نگهداری می‌شوند و **هرگز** در دیتابیس SQLite، لاگ تغییرات (`audit_logs`) یا پیام‌های تلگرام نمایش داده نمی‌شوند.

| متغیر | الزام | توضیح |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | **الزامی** | توکن ربات دریافتی از `@BotFather` |
| `SUPER_ADMIN_ID` | **الزامی** | شناسه عددی تلگرام مالک اصلی (`Owner`) |
| `ADMIN_IDS` | اختیاری | لیست شناسه عددی مدیران اولیه (جداشده با کاما) |
| `BOT_DB_PATH` | اختیاری | مسیر دیتابیس پایدار SQLite (پیش‌فرض: `./data/bot.db`) |
| `BOT_BACKUPS_DIR` | اختیاری | مسیر ذخیره بکاپ‌های دیتابیس (پیش‌فرض: `./backups`) |
| `HOST` | اختیاری | پیش‌فرض `127.0.0.1` (فقط دسترسی محلی) |
| `PORT` | اختیاری | پیش‌فرض `3000` |
| `ADMIN_API_KEY` | اختیاری | کلید امنیتی هدر `x-admin-api-key` برای API محلی |
| `DISABLE_HTTP_API` | اختیاری | در صورت `true` هیچ پورت HTTP باز نمی‌شود |
| `BOT_MODE` | اختیاری | `polling` (پیشنهادی روی EC2) یا `webhook` |
| `MAX_CONCURRENT_DOWNLOADS` | اختیاری | سقف دانلود هم‌زمان پیش‌فرض |
| `INSTAGRAM_SESSION_ID` | اختیاری | سشن اینستاگرام برای پست‌های محدودشده |
| `GEMINI_API_KEY` | اختیاری | کلید Gemini برای تشخیص هوشمند نام آهنگ |
| `AWS_REGION` | اختیاری | ناحیه AWS برای یکپارچه‌سازی با Secrets Manager / SSM |
| `AWS_SECRETS_MANAGER_SECRET_ID` | اختیاری | نام/ARN سکرت در AWS Secrets Manager |
| `AWS_SSM_PARAM_PREFIX` | اختیاری | پیشوند پارامترهای رمزنگاری‌شده در AWS SSM Parameter Store |

---

## 🚀 راه‌اندازی دائمی روی AWS EC2 (اوبونتو)

### ۱. نصب اولیه (فقط یک‌بار)
```bash
git clone https://github.com/Hakimiii/Telegram-boy-.git
cd Telegram-boy-
bash setup.sh
```
اسکریپت `setup.sh` به صورت خودکار موارد زیر را انجام می‌دهد:
- نصب `ffmpeg`, `python3`, `Node.js 22`, `PM2` و فعال‌سازی `pm2-logrotate`
- ساخت پوشه‌های پایدار `data/` و `backups/` با دسترسی `chmod 700`
- ساخت Swap 2GB در سرورهای کم‌حافظه (مانند `t2.micro` / `t3.micro`)
- دریافت باینری رسمی `yt-dlp`
- ساخت امن فایل `.env` با سطح دسترسی `chmod 600`
- اجرای **تک‌نمونه‌ای (Single Instance)** ربات با `ecosystem.config.cjs`
- تنظیم `pm2 startup` جهت روشن‌شدن خودکار بعد از Reboot سرور EC2

### ۲. دستورات مدیریت روزمره روی EC2
```bash
pm2 status
pm2 logs telegram-bot
pm2 restart ecosystem.config.cjs --only telegram-bot --update-env
curl -s http://127.0.0.1:3000/health
```

### ۳. آپدیت خودکار، بکاپ دیتابیس و بازگشت امن (Rollback)
```bash
bash update.sh
```
اسکریپت `update.sh` پیش از `git pull` یک نسخه پشتیبان کامل از دیتابیس SQLite در پوشه `backups/` ذخیره می‌کند؛ تنظیمات، کاربران، مدیران و لاگ‌های پنل در آپدیت حفظ می‌شوند و در صورت خطا در تست یا اجرا، ربات و دیتابیس به وضعیت قبل بازمی‌گردند.

---

## 🐳 اجرا با Docker (اختیاری)
```bash
cp .env.example .env
# مقادیر TELEGRAM_BOT_TOKEN و SUPER_ADMIN_ID را در .env وارد کنید
docker compose up -d --build
```
پوشه‌های `./data` و `./backups` به‌صورت Volume متصل شده‌اند تا داده‌های SQLite در ری‌استارت یا بیلد مجدد حفظ شوند.

---

## 🧪 تست و بررسی کیفیت کد
```bash
npm run lint   # بررسی خطاهای تایپ TypeScript
npm test       # اجرای تست‌های واحد، RBAC، دیتابیس و امنیت
```

