import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { recordAuditLog } from './database.ts';
import { getAdminRecord } from './configManager.ts';

export type SecretKeyName =
  | 'TELEGRAM_BOT_TOKEN'
  | 'SPOTIFY_CLIENT_SECRET'
  | 'ADMIN_API_KEY'
  | 'GEMINI_API_KEY'
  | 'INSTAGRAM_SESSION_ID'
  | 'YOUTUBE_COOKIES';

export interface SecretStatusInfo {
  key: SecretKeyName;
  labelFa: string;
  isConfigured: boolean;
  source: 'aws_secrets_manager' | 'aws_ssm' | 'env' | 'cookie_file' | 'unset';
  maskedDisplay: string;
}

export interface SecretRotationChallenge {
  challengeId: string;
  secretKey: SecretKeyName;
  requestedBy: number;
  expiresAt: number;
  consumed: boolean;
}

const activeChallenges = new Map<string, SecretRotationChallenge>();

export const SECRET_DESCRIPTIONS: Array<{ key: SecretKeyName; labelFa: string; ssmSuffix: string }> = [
  { key: 'TELEGRAM_BOT_TOKEN', labelFa: 'توکن ربات تلگرام', ssmSuffix: 'telegram-bot-token' },
  { key: 'SPOTIFY_CLIENT_SECRET', labelFa: 'کلید مخفی Spotify API', ssmSuffix: 'spotify-client-secret' },
  { key: 'ADMIN_API_KEY', labelFa: 'کلید API داخلی سرور', ssmSuffix: 'admin-api-key' },
  { key: 'GEMINI_API_KEY', labelFa: 'کلید هوش مصنوعی Gemini', ssmSuffix: 'gemini-api-key' },
  { key: 'INSTAGRAM_SESSION_ID', labelFa: 'سشن کوکی اینستاگرام', ssmSuffix: 'instagram-session-id' },
  { key: 'YOUTUBE_COOKIES', labelFa: 'کوکی یوتیوب', ssmSuffix: 'youtube-cookies' },
];

export function hasCookieFileOnDisk(name: 'instagram' | 'youtube'): boolean {
  const file = name === 'instagram' ? 'instagram_cookies.txt' : 'youtube_cookies.txt';
  return (
    fs.existsSync(path.resolve(process.cwd(), file)) ||
    fs.existsSync(path.resolve('/tmp', file))
  );
}

export function getAwsIntegrationConfig(): {
  region: string;
  secretsManagerId: string;
  ssmPrefix: string;
  hasExplicitCreds: boolean;
  provider: 'aws_secrets_manager' | 'aws_ssm' | 'local_env';
} {
  const region = (process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || '').trim();
  const secretsManagerId = (process.env.AWS_SECRETS_MANAGER_SECRET_ID || '').trim();
  const ssmPrefix = (process.env.AWS_SSM_PARAM_PREFIX || '').trim();
  const hasExplicitCreds = Boolean(
    (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) ||
    process.env.AWS_CONTAINER_CREDENTIALS_RELATIVE_URI ||
    process.env.AWS_WEB_IDENTITY_TOKEN_FILE
  );

  const provider = secretsManagerId
    ? 'aws_secrets_manager'
    : ssmPrefix
    ? 'aws_ssm'
    : 'local_env';

  return { region, secretsManagerId, ssmPrefix, hasExplicitCreds, provider };
}

export function inspectSecretsStatus(): SecretStatusInfo[] {
  const awsCfg = getAwsIntegrationConfig();

  return SECRET_DESCRIPTIONS.map((item) => {
    const rawVal = (process.env[item.key] || '').trim();
    const isPlaceholder =
      !rawVal ||
      rawVal === 'YOUR_TELEGRAM_BOT_TOKEN' ||
      rawVal === 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET' ||
      rawVal === 'MY_GEMINI_API_KEY';

    if (!isPlaceholder) {
      return {
        key: item.key,
        labelFa: item.labelFa,
        isConfigured: true,
        source:
          awsCfg.provider === 'aws_secrets_manager'
            ? 'aws_secrets_manager'
            : awsCfg.provider === 'aws_ssm'
            ? 'aws_ssm'
            : 'env',
        maskedDisplay: 'تنظیم شده (محافظت‌شده 🔒)',
      };
    }

    if (item.key === 'INSTAGRAM_SESSION_ID' && hasCookieFileOnDisk('instagram')) {
      return {
        key: item.key,
        labelFa: item.labelFa,
        isConfigured: true,
        source: 'cookie_file',
        maskedDisplay: 'فایل کوکی امن با دسترسی 600 🔒',
      };
    }

    if (item.key === 'YOUTUBE_COOKIES' && hasCookieFileOnDisk('youtube')) {
      return {
        key: item.key,
        labelFa: item.labelFa,
        isConfigured: true,
        source: 'cookie_file',
        maskedDisplay: 'فایل کوکی امن با دسترسی 600 🔒',
      };
    }

    return {
      key: item.key,
      labelFa: item.labelFa,
      isConfigured: false,
      source: 'unset',
      maskedDisplay: 'تنظیم نشده ⚪',
    };
  });
}

export function checkSecretSecurityWarnings(): string[] {
  const warnings: string[] = [];
  const cwd = process.cwd();

  for (const sensitiveFile of ['.env', 'instagram_cookies.txt', 'youtube_cookies.txt']) {
    const full = path.join(cwd, sensitiveFile);
    if (fs.existsSync(full)) {
      try {
        const mode = fs.statSync(full).mode & 0o777;
        if ((mode & 0o077) !== 0) {
          try {
            fs.chmodSync(full, 0o600);
          } catch {
            warnings.push(`دسترسی فایل ${sensitiveFile} بیش از حد باز است (پیشنهاد: chmod 600).`);
          }
        }
      } catch {}
    }
  }

  const awsCfg = getAwsIntegrationConfig();
  if (awsCfg.provider === 'local_env') {
    warnings.push('مدیریت Secretها روی .env محلی است؛ برای سطح امنیتی بالاتر AWS Secrets Manager یا SSM Parameter Store توصیه می‌شود.');
  }

  if (!process.env.ADMIN_API_KEY || process.env.ADMIN_API_KEY === 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET') {
    warnings.push('متغیر ADMIN_API_KEY هنوز روی مقدار پیش‌فرض یا خالی است (API مدیریتی HTTP غیرفعال و قفل است).');
  }

  return warnings;
}

/**
 * Create a single-use Owner-only Secret Rotation Challenge (never reads/writes plaintext secrets via Telegram)
 */
export function createSecretRotationChallenge(
  ownerId: number,
  secretKey: SecretKeyName
): { success: boolean; challenge?: SecretRotationChallenge; error?: string } {
  const actor = getAdminRecord(ownerId);
  if (!actor || actor.role !== 'owner' || actor.isBlocked) {
    return { success: false, error: 'فقط مالک اصلی (Owner) مجاز به درخواست چرخش Secret است.' };
  }

  // Prune expired
  const now = Date.now();
  for (const [k, v] of activeChallenges) {
    if (v.expiresAt < now || v.consumed) {
      activeChallenges.delete(k);
    }
  }

  const challenge: SecretRotationChallenge = {
    challengeId: crypto.randomBytes(6).toString('hex'),
    secretKey,
    requestedBy: ownerId,
    expiresAt: now + 5 * 60_000,
    consumed: false,
  };
  activeChallenges.set(challenge.challengeId, challenge);

  recordAuditLog({
    actorId: ownerId,
    actorRole: actor.role,
    action: 'secret_rotation_requested',
    section: 'secrets',
    oldValue: secretKey,
    newValue: '[CHALLENGE_ISSUED]',
    result: 'success',
  });

  return { success: true, challenge };
}

export function consumeSecretRotationChallenge(
  challengeId: string,
  ownerId: number
): { valid: boolean; secretKey?: SecretKeyName; instructions?: string; error?: string } {
  const actor = getAdminRecord(ownerId);
  if (!actor || actor.role !== 'owner' || actor.isBlocked) {
    return { valid: false, error: 'دسترسی فقط برای مالک اصلی مجاز است.' };
  }

  const ch = activeChallenges.get(challengeId);
  if (!ch || ch.consumed || ch.expiresAt < Date.now() || ch.requestedBy !== ownerId) {
    return { valid: false, error: 'درخواست تغییر منقضی شده یا نامعتبر است.' };
  }

  ch.consumed = true;
  activeChallenges.delete(challengeId);

  const desc = SECRET_DESCRIPTIONS.find((d) => d.key === ch.secretKey);
  const awsCfg = getAwsIntegrationConfig();
  const ssmPath = `${(awsCfg.ssmPrefix || '/telegram-boy/prod').replace(/\/+$/, '')}/${desc?.ssmSuffix || ch.secretKey.toLowerCase()}`;
  const region = awsCfg.region || 'us-east-1';

  recordAuditLog({
    actorId: ownerId,
    actorRole: actor.role,
    action: 'secret_rotation_confirmed',
    section: 'secrets',
    oldValue: ch.secretKey,
    newValue: '[ROTATION_WORKFLOW_APPROVED]',
    result: 'success',
  });

  const instructions =
    awsCfg.provider === 'aws_secrets_manager'
      ? `از طریق AWS Secrets Manager (با دسترسی IAM محدود) Secret را بدون ارسال در تلگرام بروزرسانی کنید:\n<code>aws secretsmanager update-secret --region ${region} --secret-id "${awsCfg.secretsManagerId}" --secret-string '{"${ch.secretKey}":"NEW_VALUE"}'</code>\nسپس از بخش 🖥 وضعیت سرور، ربات را به صورت کنترل‌شده Restart کنید.`
      : `از طریق AWS SSM Parameter Store (SecureString) یا فایل امن .env روی EC2 مقدار جدید را ثبت کنید:\n<code>aws ssm put-parameter --region ${region} --name "${ssmPath}" --type SecureString --overwrite --value "NEW_VALUE"</code>\nیا در سرور EC2 فایل <code>.env</code> (با دسترسی <code>600</code>) را ویرایش کرده و سپس از بخش 🖥 وضعیت سرور، Restart کنترل‌شده را بزنید.`;

  return {
    valid: true,
    secretKey: ch.secretKey,
    instructions,
  };
}

/**
 * Optional read-only connectivity check to AWS EC2 Metadata / SSM / Secrets Manager endpoint
 */
export async function checkAwsSecretsConnectivity(): Promise<{ configured: boolean; reachable: boolean; details: string }> {
  const cfg = getAwsIntegrationConfig();
  if (cfg.provider === 'local_env') {
    return {
      configured: false,
      reachable: false,
      details: 'در حال استفاده از متغیرهای محیطی امن سرور (.env)',
    };
  }
  const region = cfg.region || 'us-east-1';
  const endpoint =
    cfg.provider === 'aws_secrets_manager'
      ? `https://secretsmanager.${region}.amazonaws.com/`
      : `https://ssm.${region}.amazonaws.com/`;
  try {
    const res = await fetch(endpoint, { method: 'HEAD', signal: AbortSignal.timeout(4000) });
    return {
      configured: true,
      reachable: res.status > 0,
      details: `متصل به ${cfg.provider === 'aws_secrets_manager' ? 'AWS Secrets Manager' : 'AWS SSM Parameter Store'} (${region})`,
    };
  } catch {
    return {
      configured: true,
      reachable: false,
      details: `خطا در ارتباط با اندپوینت AWS (${region})`,
    };
  }
}
