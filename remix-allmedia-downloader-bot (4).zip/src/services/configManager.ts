import fs from 'node:fs';
import path from 'node:path';
import {
  getDb,
  getSettingValue,
  setSettingValue,
  recordAuditLog,
} from './database.ts';

function parseEnvSuperAdminId(): number {
  const raw = process.env.SUPER_ADMIN_ID;
  if (raw) {
    const parsed = Number(raw.trim());
    if (Number.isSafeInteger(parsed) && parsed > 0) {
      return parsed;
    }
  }
  return 567645818;
}

function parseEnvAdminIds(): number[] {
  const raw = process.env.ADMIN_IDS || '';
  return raw
    .split(',')
    .map((s) => Number(s.trim()))
    .filter((id) => Number.isSafeInteger(id) && id > 0);
}

/**
 * Primary Owner / Super Admin ID (strictly sourced from server env SUPER_ADMIN_ID)
 */
export const SUPER_ADMIN_ID = parseEnvSuperAdminId();

export type AdminRole = 'owner' | 'super_admin' | 'admin' | 'support';

export type AdminPermission =
  | 'general'
  | 'download'
  | 'spotify'
  | 'users'
  | 'admins'
  | 'security'
  | 'server'
  | 'stats'
  | 'backup'
  | 'maintenance'
  | 'forcejoin'
  | 'broadcast'
  | 'cookies'
  | 'secrets';

export const ALL_ADMIN_PERMISSIONS: AdminPermission[] = [
  'general',
  'download',
  'spotify',
  'users',
  'admins',
  'security',
  'server',
  'stats',
  'backup',
  'maintenance',
  'forcejoin',
  'broadcast',
  'cookies',
  'secrets',
];

export const PERMISSION_LABELS_FA: Record<AdminPermission, string> = {
  general: 'تنظیمات عمومی',
  download: 'مدیریت دانلود',
  spotify: 'تنظیمات Spotify',
  users: 'مدیریت کاربران',
  admins: 'مدیریت مدیران',
  security: 'امنیت و دسترسی',
  server: 'وضعیت و کنترل سرور',
  stats: 'آمار و گزارشات',
  backup: 'پشتیبان‌گیری',
  maintenance: 'تعمیر و نگهداری',
  forcejoin: 'قفل عضویت اجباری',
  broadcast: 'ارسال همگانی',
  cookies: 'مدیریت کوکی‌ها',
  secrets: 'مدیریت Secretها',
};

export const ROLE_LABELS_FA: Record<AdminRole, string> = {
  owner: 'مالک اصلی (Owner)',
  super_admin: 'سوپر ادمین (Super Admin)',
  admin: 'ادمین (Admin)',
  support: 'پشتیبان (Support)',
};

export const ROLE_RANK: Record<AdminRole, number> = {
  owner: 4,
  super_admin: 3,
  admin: 2,
  support: 1,
};

export function getDefaultPermissionsForRole(role: AdminRole): AdminPermission[] {
  switch (role) {
    case 'owner':
      return [...ALL_ADMIN_PERMISSIONS];
    case 'super_admin':
      return [
        'general',
        'download',
        'spotify',
        'users',
        'server',
        'stats',
        'backup',
        'maintenance',
        'forcejoin',
        'broadcast',
        'cookies',
        'security',
      ];
    case 'admin':
      return ['users', 'stats', 'forcejoin', 'broadcast', 'download', 'spotify'];
    case 'support':
      return ['users', 'stats'];
  }
}

export interface AdminRecord {
  userId: number;
  role: AdminRole;
  permissions: AdminPermission[];
  isBlocked: boolean;
  addedBy: number | null;
  lastActiveAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface RequiredChannel {
  id: string;
  title: string;
  username: string;
  url: string;
}

export interface GeneralSettings {
  botEnabled: boolean;
  allowNewRegistrations: boolean;
  downloadsServiceEnabled: boolean;
  welcomeMessage: string;
  helpMessage: string;
  errorMessage: string;
  supportMessage: string;
  notifyChannelId: string;
  maintenanceMode: boolean;
  maintenanceMessage: string;
  notifyOnChanges: boolean;
}

export interface DownloadSettings {
  enabled: boolean;
  maxFileSizeMb: number;
  maxDownloadTimeSec: number;
  maxConcurrentDownloads: number;
  dailyLimitPerUser: number;
  outputFormat: 'mp4' | 'mkv' | 'mp3' | 'm4a';
  defaultQuality: 'best_1080' | 'best_720' | 'best_480' | 'best_360' | 'best_audio';
  storagePath: string;
  tempRetentionMinutes: number;
}

export interface SpotifySettings {
  enabled: boolean;
  allowTrack: boolean;
  allowAlbum: boolean;
  allowPlaylist: boolean;
  defaultQuality: '320kbps' | '192kbps' | '128kbps';
  preferMp3: boolean;
  allow320kbpsWhenAvailable: boolean;
  maxPlaylistTracks: number;
  maxFileSizeMb: number;
  maxConcurrent: number;
  timeoutSec: number;
}

export interface BotAdminConfig {
  forceJoinEnabled: boolean;
  channels: RequiredChannel[];
  mainChannelUrl: string;
  supportUsername: string;
  adminIds: number[];
  general: GeneralSettings;
  download: DownloadSettings;
  spotify: SpotifySettings;
}

const PRIMARY_CONFIG_PATH = path.resolve(process.cwd(), 'bot_config.json');
const PRIMARY_USERS_PATH = path.resolve(process.cwd(), 'bot_users.json');

export const DEFAULT_GENERAL_SETTINGS: GeneralSettings = {
  botEnabled: true,
  allowNewRegistrations: true,
  downloadsServiceEnabled: true,
  welcomeMessage: '',
  helpMessage: '',
  errorMessage: '❌ متاسفانه در پردازش درخواست خطایی رخ داد. لطفاً دقایقی دیگر مجدد تلاش کنید.',
  supportMessage: 'در صورت بروز هرگونه مشکل یا سوال، با آیدی پشتیبانی در ارتباط باشید.',
  notifyChannelId: '',
  maintenanceMode: false,
  maintenanceMessage: '🔧 ربات موقتاً در حال بروزرسانی و تعمیر و نگهداری است. لطفاً ساعاتی دیگر مراجعه فرمایید.',
  notifyOnChanges: true,
};

export const DEFAULT_DOWNLOAD_SETTINGS: DownloadSettings = {
  enabled: true,
  maxFileSizeMb: 50,
  maxDownloadTimeSec: 180,
  maxConcurrentDownloads: Math.max(1, Math.min(8, parseInt(process.env.MAX_CONCURRENT_DOWNLOADS || '3', 10) || 3)),
  dailyLimitPerUser: 0,
  outputFormat: 'mp4',
  defaultQuality: 'best_720',
  storagePath: path.resolve('/tmp/downloads'),
  tempRetentionMinutes: 20,
};

export const DEFAULT_SPOTIFY_SETTINGS: SpotifySettings = {
  enabled: true,
  allowTrack: true,
  allowAlbum: true,
  allowPlaylist: true,
  defaultQuality: '320kbps',
  preferMp3: true,
  allow320kbpsWhenAvailable: true,
  maxPlaylistTracks: 15,
  maxFileSizeMb: 50,
  maxConcurrent: 2,
  timeoutSec: 90,
};

const defaultConfig: BotAdminConfig = {
  forceJoinEnabled: false,
  channels: [],
  mainChannelUrl: process.env.MAIN_CHANNEL_URL || '',
  supportUsername: process.env.SUPPORT_USERNAME || 'admin',
  adminIds: Array.from(new Set([SUPER_ADMIN_ID, ...parseEnvAdminIds()])),
  general: { ...DEFAULT_GENERAL_SETTINGS },
  download: { ...DEFAULT_DOWNLOAD_SETTINGS },
  spotify: { ...DEFAULT_SPOTIFY_SETTINGS },
};

let bootstrappedFromLegacy = false;
let cachedConfig: BotAdminConfig | null = null;

function syncOwnerAndEnvAdmins(): void {
  const db = getDb();
  const now = new Date().toISOString();

  // Always ensure server-configured SUPER_ADMIN_ID is Owner & unblocked with full permissions
  db.prepare(
    `INSERT INTO admins (user_id, role, permissions_json, is_blocked, added_by, last_active_at, created_at, updated_at)
     VALUES (?, 'owner', ?, 0, NULL, NULL, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       role = 'owner',
       permissions_json = excluded.permissions_json,
       is_blocked = 0,
       updated_at = excluded.updated_at`
  ).run(SUPER_ADMIN_ID, JSON.stringify(ALL_ADMIN_PERMISSIONS), now, now);

  // Ensure env ADMIN_IDS exist at least as 'admin' if not already registered
  for (const envAdminId of parseEnvAdminIds()) {
    if (envAdminId === SUPER_ADMIN_ID) continue;
    db.prepare(
      `INSERT OR IGNORE INTO admins (user_id, role, permissions_json, is_blocked, added_by, last_active_at, created_at, updated_at)
       VALUES (?, 'admin', ?, 0, ?, NULL, ?, ?)`
    ).run(envAdminId, JSON.stringify(getDefaultPermissionsForRole('admin')), SUPER_ADMIN_ID, now, now);
  }
}

function bootstrapDbFromLegacyJsonOnce(): void {
  if (bootstrappedFromLegacy) return;
  bootstrappedFromLegacy = true;

  const db = getDb();
  syncOwnerAndEnvAdmins();

  const existingCore = getSettingValue<Partial<BotAdminConfig>>('core_config');
  if (!existingCore) {
    let legacy: any = null;
    try {
      if (fs.existsSync(PRIMARY_CONFIG_PATH)) {
        legacy = JSON.parse(fs.readFileSync(PRIMARY_CONFIG_PATH, 'utf-8'));
      }
    } catch {}

    const now = new Date().toISOString();
    const coreToSave = {
      forceJoinEnabled: Boolean(legacy?.forceJoinEnabled ?? defaultConfig.forceJoinEnabled),
      channels: Array.isArray(legacy?.channels) ? legacy.channels : [],
      mainChannelUrl: String(legacy?.mainChannelUrl ?? defaultConfig.mainChannelUrl),
      supportUsername: String(legacy?.supportUsername ?? defaultConfig.supportUsername),
    };
    setSettingValue('core_config', coreToSave, SUPER_ADMIN_ID);

    if (Array.isArray(legacy?.adminIds)) {
      for (const rawId of legacy.adminIds) {
        const numId = Number(rawId);
        if (Number.isSafeInteger(numId) && numId > 0 && numId !== SUPER_ADMIN_ID) {
          db.prepare(
            `INSERT OR IGNORE INTO admins (user_id, role, permissions_json, is_blocked, added_by, last_active_at, created_at, updated_at)
             VALUES (?, 'admin', ?, 0, ?, NULL, ?, ?)`
          ).run(numId, JSON.stringify(getDefaultPermissionsForRole('admin')), SUPER_ADMIN_ID, now, now);
        }
      }
    }
  }

  if (!getSettingValue('general')) setSettingValue('general', DEFAULT_GENERAL_SETTINGS, SUPER_ADMIN_ID);
  if (!getSettingValue('download')) setSettingValue('download', DEFAULT_DOWNLOAD_SETTINGS, SUPER_ADMIN_ID);
  if (!getSettingValue('spotify')) setSettingValue('spotify', DEFAULT_SPOTIFY_SETTINGS, SUPER_ADMIN_ID);

  // Import legacy users JSON once if SQLite users table is empty
  const userCountRow = db.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number } | undefined;
  if (Number(userCountRow?.cnt || 0) === 0 && fs.existsSync(PRIMARY_USERS_PATH)) {
    try {
      const legacyUsers = JSON.parse(fs.readFileSync(PRIMARY_USERS_PATH, 'utf-8'));
      if (Array.isArray(legacyUsers)) {
        const now = new Date().toISOString();
        const stmt = db.prepare(
          `INSERT OR IGNORE INTO users (user_id, first_name, username, joined_at, last_active_at)
           VALUES (?, NULL, NULL, ?, ?)`
        );
        db.exec('BEGIN IMMEDIATE;');
        try {
          for (const rawId of legacyUsers) {
            const uid = Number(rawId);
            if (Number.isSafeInteger(uid) && uid > 0) {
              stmt.run(uid, now, now);
            }
          }
          db.exec('COMMIT;');
        } catch (err) {
          db.exec('ROLLBACK;');
          throw err;
        }
      }
    } catch {}
  }
}

export function resetConfigCaches(): void {
  cachedConfig = null;
  bootstrappedFromLegacy = false;
}

export function loadBotConfig(): BotAdminConfig {
  if (cachedConfig) return cachedConfig;
  bootstrapDbFromLegacyJsonOnce();

  const core = getSettingValue<{
    forceJoinEnabled?: boolean;
    channels?: RequiredChannel[];
    mainChannelUrl?: string;
    supportUsername?: string;
  }>('core_config');

  const general = getSettingValue<Partial<GeneralSettings>>('general');
  const download = getSettingValue<Partial<DownloadSettings>>('download');
  const spotify = getSettingValue<Partial<SpotifySettings>>('spotify');

  const activeAdmins = listAdmins().filter((a) => !a.isBlocked).map((a) => a.userId);
  const adminIds = Array.from(new Set([SUPER_ADMIN_ID, ...parseEnvAdminIds(), ...activeAdmins]));

  const loaded: BotAdminConfig = {
    forceJoinEnabled: Boolean(core?.forceJoinEnabled ?? defaultConfig.forceJoinEnabled),
    channels: Array.isArray(core?.channels) ? core!.channels : [],
    mainChannelUrl: String(core?.mainChannelUrl ?? defaultConfig.mainChannelUrl),
    supportUsername: String(core?.supportUsername ?? defaultConfig.supportUsername),
    adminIds,
    general: { ...DEFAULT_GENERAL_SETTINGS, ...(general || {}) },
    download: { ...DEFAULT_DOWNLOAD_SETTINGS, ...(download || {}) },
    spotify: { ...DEFAULT_SPOTIFY_SETTINGS, ...(spotify || {}) },
  };

  cachedConfig = loaded;
  return loaded;
}

export function saveBotConfig(
  config: Partial<BotAdminConfig>,
  actorId: number | null = null
): BotAdminConfig {
  bootstrapDbFromLegacyJsonOnce();
  const current = loadBotConfig();

  const updated: BotAdminConfig = {
    ...current,
    ...config,
    general: { ...current.general, ...(config.general || {}) },
    download: { ...current.download, ...(config.download || {}) },
    spotify: { ...current.spotify, ...(config.spotify || {}) },
  };

  setSettingValue(
    'core_config',
    {
      forceJoinEnabled: updated.forceJoinEnabled,
      channels: updated.channels,
      mainChannelUrl: updated.mainChannelUrl,
      supportUsername: updated.supportUsername,
    },
    actorId
  );
  setSettingValue('general', updated.general, actorId);
  setSettingValue('download', updated.download, actorId);
  setSettingValue('spotify', updated.spotify, actorId);

  if (Array.isArray(config.adminIds)) {
    const db = getDb();
    const now = new Date().toISOString();
    for (const id of config.adminIds) {
      const num = Number(id);
      if (Number.isSafeInteger(num) && num > 0 && num !== SUPER_ADMIN_ID) {
        db.prepare(
          `INSERT OR IGNORE INTO admins (user_id, role, permissions_json, is_blocked, added_by, last_active_at, created_at, updated_at)
           VALUES (?, 'admin', ?, 0, ?, NULL, ?, ?)`
        ).run(num, JSON.stringify(getDefaultPermissionsForRole('admin')), actorId ?? SUPER_ADMIN_ID, now, now);
      }
    }
  }

  cachedConfig = null;
  return loadBotConfig();
}

export function updateGeneralSettings(
  patch: Partial<GeneralSettings>,
  actorId: number
): GeneralSettings {
  const current = loadBotConfig().general;
  const updated = { ...current, ...patch };
  setSettingValue('general', updated, actorId);
  cachedConfig = null;
  return updated;
}

export function updateDownloadSettings(
  patch: Partial<DownloadSettings>,
  actorId: number
): DownloadSettings {
  const current = loadBotConfig().download;
  const updated = { ...current, ...patch };
  setSettingValue('download', updated, actorId);
  cachedConfig = null;
  return updated;
}

export function updateSpotifySettings(
  patch: Partial<SpotifySettings>,
  actorId: number
): SpotifySettings {
  const current = loadBotConfig().spotify;
  const updated = { ...current, ...patch };
  setSettingValue('spotify', updated, actorId);
  cachedConfig = null;
  return updated;
}

// =======================
// RBAC & Admin Management
// =======================

function rowToAdminRecord(row: any): AdminRecord {
  let perms: AdminPermission[] = [];
  try {
    const parsed = JSON.parse(row.permissions_json);
    if (Array.isArray(parsed)) {
      perms = parsed.filter((p): p is AdminPermission => ALL_ADMIN_PERMISSIONS.includes(p));
    }
  } catch {}
  return {
    userId: Number(row.user_id),
    role: row.role as AdminRole,
    permissions: row.role === 'owner' ? [...ALL_ADMIN_PERMISSIONS] : perms,
    isBlocked: Boolean(row.is_blocked),
    addedBy: row.added_by !== null && row.added_by !== undefined ? Number(row.added_by) : null,
    lastActiveAt: row.last_active_at || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function listAdmins(): AdminRecord[] {
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const rows = db.prepare('SELECT * FROM admins ORDER BY created_at ASC').all();
  return rows.map(rowToAdminRecord);
}

export function getAdminRecord(userId: number | string): AdminRecord | null {
  const numId = Number(userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) return null;
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const row = db.prepare('SELECT * FROM admins WHERE user_id = ?').get(numId);
  if (!row) return null;
  return rowToAdminRecord(row);
}

export function isUserAdmin(userId: number | string): boolean {
  const numId = Number(userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) return false;
  if (numId === SUPER_ADMIN_ID) return true;
  const record = getAdminRecord(numId);
  if (!record || record.isBlocked) return false;
  return true;
}

export function hasAdminPermission(userId: number | string, section: AdminPermission): boolean {
  const numId = Number(userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) return false;
  if (numId === SUPER_ADMIN_ID) return true;
  const record = getAdminRecord(numId);
  if (!record || record.isBlocked) return false;
  if (record.role === 'owner') return true;
  return record.permissions.includes(section);
}

export function canManageTargetAdmin(actor: AdminRecord, targetUserId: number, targetNewRole?: AdminRole): { allowed: boolean; reason?: string } {
  if (actor.isBlocked) return { allowed: false, reason: 'حساب مدیریت شما مسدود است.' };
  if (targetUserId === SUPER_ADMIN_ID) {
    return { allowed: false, reason: 'مالک اصلی (Owner) غیرقابل تغییر یا حذف است.' };
  }

  const target = getAdminRecord(targetUserId);
  const actorRank = ROLE_RANK[actor.role];

  if (actor.role !== 'owner' && !actor.permissions.includes('admins')) {
    return { allowed: false, reason: 'شما مجوز مدیریت ادمین‌ها را ندارید.' };
  }

  if (target) {
    const targetRank = ROLE_RANK[target.role];
    if (actorRank <= targetRank) {
      return { allowed: false, reason: 'تغییر یا حذف مدیر هم‌سطح یا بالاتر فقط توسط مالک اصلی امکان‌پذیر است.' };
    }
  }

  if (targetNewRole) {
    if (targetNewRole === 'owner') {
      return { allowed: false, reason: 'نقش Owner فقط از طریق تنظیمات امن سرور قابل تعیین است.' };
    }
    const newRank = ROLE_RANK[targetNewRole];
    if (actorRank <= newRank) {
      return { allowed: false, reason: 'فقط مدیر دارای سطح دسترسی بالاتر می‌تواند این نقش را اختصاص دهد.' };
    }
  }

  return { allowed: true };
}

export function upsertAdmin(
  actorId: number,
  targetUserId: number,
  role: Exclude<AdminRole, 'owner'>,
  permissions?: AdminPermission[]
): { success: boolean; message: string; record?: AdminRecord } {
  if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0) {
    return { success: false, message: 'شناسه عددی تلگرام نامعتبر است.' };
  }

  const actor = getAdminRecord(actorId);
  if (!actor) {
    return { success: false, message: 'دسترسی غیرمجاز.' };
  }

  const permCheck = canManageTargetAdmin(actor, targetUserId, role);
  if (!permCheck.allowed) {
    return { success: false, message: permCheck.reason || 'دسترسی غیرمجاز' };
  }

  const db = getDb();
  const now = new Date().toISOString();
  const finalPerms = permissions
    ? permissions.filter((p) => ALL_ADMIN_PERMISSIONS.includes(p))
    : getDefaultPermissionsForRole(role);

  // Non-owners cannot grant secrets or admins permissions
  const sanitizedPerms =
    actor.role === 'owner'
      ? finalPerms
      : finalPerms.filter((p) => p !== 'secrets' && p !== 'admins');

  db.prepare(
    `INSERT INTO admins (user_id, role, permissions_json, is_blocked, added_by, last_active_at, created_at, updated_at)
     VALUES (?, ?, ?, 0, ?, NULL, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       role = excluded.role,
       permissions_json = excluded.permissions_json,
       updated_at = excluded.updated_at`
  ).run(targetUserId, role, JSON.stringify(sanitizedPerms), actorId, now, now);

  cachedConfig = null;
  recordAuditLog({
    actorId,
    actorRole: actor.role,
    action: 'upsert_admin',
    section: 'admins',
    oldValue: null,
    newValue: `user=${targetUserId},role=${role}`,
    result: 'success',
  });

  return {
    success: true,
    message: `مدیر ${targetUserId} با نقش ${ROLE_LABELS_FA[role]} ثبت شد.`,
    record: getAdminRecord(targetUserId) || undefined,
  };
}

export function setAdminBlocked(
  actorId: number,
  targetUserId: number,
  blocked: boolean
): { success: boolean; message: string } {
  const actor = getAdminRecord(actorId);
  if (!actor || actor.role !== 'owner') {
    return { success: false, message: 'فقط مالک اصلی (Owner) مجاز به مسدود یا رفع مسدودیت مدیران است.' };
  }
  if (targetUserId === SUPER_ADMIN_ID) {
    return { success: false, message: 'امکان مسدود کردن مالک اصلی وجود ندارد.' };
  }
  const target = getAdminRecord(targetUserId);
  if (!target) {
    return { success: false, message: 'مدیر مورد نظر یافت نشد.' };
  }

  const db = getDb();
  db.prepare('UPDATE admins SET is_blocked = ?, updated_at = ? WHERE user_id = ?').run(
    blocked ? 1 : 0,
    new Date().toISOString(),
    targetUserId
  );
  cachedConfig = null;

  recordAuditLog({
    actorId,
    actorRole: actor.role,
    action: blocked ? 'block_admin' : 'unblock_admin',
    section: 'admins',
    oldValue: String(target.isBlocked),
    newValue: String(blocked),
    result: 'success',
  });

  return {
    success: true,
    message: blocked ? `مدیر ${targetUserId} مسدود شد.` : `مسدودیت مدیر ${targetUserId} برداشته شد.`,
  };
}

export function toggleAdminPermission(
  actorId: number,
  targetUserId: number,
  permission: AdminPermission
): { success: boolean; message: string; enabled?: boolean } {
  const actor = getAdminRecord(actorId);
  if (!actor) return { success: false, message: 'دسترسی غیرمجاز.' };

  const permCheck = canManageTargetAdmin(actor, targetUserId);
  if (!permCheck.allowed) return { success: false, message: permCheck.reason || 'دسترسی غیرمجاز.' };

  if (actor.role !== 'owner' && (permission === 'secrets' || permission === 'admins')) {
    return { success: false, message: 'تعیین دسترسی Secretها و مدیریت مدیران فقط توسط مالک اصلی مجاز است.' };
  }

  const target = getAdminRecord(targetUserId);
  if (!target) return { success: false, message: 'مدیر یافت نشد.' };

  const exists = target.permissions.includes(permission);
  const nextPerms = exists
    ? target.permissions.filter((p) => p !== permission)
    : [...target.permissions, permission];

  const db = getDb();
  db.prepare('UPDATE admins SET permissions_json = ?, updated_at = ? WHERE user_id = ?').run(
    JSON.stringify(nextPerms),
    new Date().toISOString(),
    targetUserId
  );

  recordAuditLog({
    actorId,
    actorRole: actor.role,
    action: 'toggle_admin_permission',
    section: 'admins',
    oldValue: `${targetUserId}:${permission}=${exists}`,
    newValue: `${targetUserId}:${permission}=${!exists}`,
    result: 'success',
  });

  return {
    success: true,
    enabled: !exists,
    message: !exists
      ? `دسترسی «${PERMISSION_LABELS_FA[permission]}» فعال شد.`
      : `دسترسی «${PERMISSION_LABELS_FA[permission]}» غیرفعال شد.`,
  };
}

export function touchAdminActivity(userId: number): void {
  try {
    const db = getDb();
    db.prepare('UPDATE admins SET last_active_at = ? WHERE user_id = ?').run(new Date().toISOString(), userId);
  } catch {}
}

/**
 * Legacy-compatible addAdminId
 */
export function addAdminId(id: number): boolean {
  if (!Number.isSafeInteger(id) || id <= 0) return false;
  const res = upsertAdmin(SUPER_ADMIN_ID, id, 'admin');
  return res.success;
}

/**
 * Legacy-compatible removeAdminId
 */
export function removeAdminId(id: number, actorId: number = SUPER_ADMIN_ID): boolean {
  if (id === SUPER_ADMIN_ID) return false;
  const actor = getAdminRecord(actorId);
  if (!actor) return false;
  const permCheck = canManageTargetAdmin(actor, id);
  if (!permCheck.allowed) return false;

  const db = getDb();
  const target = getAdminRecord(id);
  const res = db.prepare('DELETE FROM admins WHERE user_id = ?').run(id);
  cachedConfig = null;

  if (Number(res.changes) > 0) {
    recordAuditLog({
      actorId,
      actorRole: actor.role,
      action: 'remove_admin',
      section: 'admins',
      oldValue: target ? `${id}:${target.role}` : String(id),
      newValue: 'removed',
      result: 'success',
    });
    return true;
  }
  return false;
}

// =======================
// Setting Validators
// =======================

export const NUMERIC_SETTING_BOUNDS: Record<string, { min: number; max: number; labelFa: string }> = {
  'download.maxFileSizeMb': { min: 5, max: 2000, labelFa: 'حداکثر حجم فایل (مگابایت)' },
  'download.maxDownloadTimeSec': { min: 15, max: 900, labelFa: 'حداکثر زمان دانلود (ثانیه)' },
  'download.maxConcurrentDownloads': { min: 1, max: 10, labelFa: 'تعداد دانلود همزمان' },
  'download.dailyLimitPerUser': { min: 0, max: 10000, labelFa: 'محدودیت روزانه هر کاربر (0 = نامحدود)' },
  'download.tempRetentionMinutes': { min: 1, max: 1440, labelFa: 'زمان نگهداری فایل‌های موقت (دقیقه)' },
  'spotify.maxPlaylistTracks': { min: 1, max: 100, labelFa: 'سقف تعداد آهنگ‌های Playlist' },
  'spotify.maxFileSizeMb': { min: 5, max: 500, labelFa: 'حداکثر حجم فایل Spotify (مگابایت)' },
  'spotify.maxConcurrent': { min: 1, max: 5, labelFa: 'تعداد عملیات همزمان Spotify' },
  'spotify.timeoutSec': { min: 10, max: 300, labelFa: 'زمان Timeout اسپاتیفای (ثانیه)' },
};

export function validateNumericSetting(
  settingKey: string,
  rawInput: string | number
): { valid: boolean; value?: number; error?: string } {
  const bounds = NUMERIC_SETTING_BOUNDS[settingKey];
  if (!bounds) {
    return { valid: false, error: 'کلید تنظیمات عددی ناشناخته است.' };
  }
  const normalized = String(rawInput)
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .trim();
  if (!/^\d+$/.test(normalized)) {
    return { valid: false, error: 'لطفاً فقط یک عدد صحیح وارد کنید.' };
  }
  const num = Number(normalized);
  if (!Number.isSafeInteger(num) || num < bounds.min || num > bounds.max) {
    return {
      valid: false,
      error: `مقدار «${bounds.labelFa}» باید بین ${bounds.min} تا ${bounds.max} باشد.`,
    };
  }
  return { valid: true, value: num };
}

export function validateStoragePath(rawPath: string): { valid: boolean; resolved?: string; error?: string } {
  const trimmed = (rawPath || '').trim();
  if (!trimmed || trimmed.includes('\0') || trimmed.includes('..')) {
    return { valid: false, error: 'مسیر ذخیره‌سازی نامعتبر یا غیرامن است.' };
  }
  const resolved = path.resolve(trimmed);
  const allowedTmp = path.resolve('/tmp');
  const allowedAppDownloads = path.resolve(process.cwd(), 'downloads');
  const isInsideTmp = resolved === allowedTmp || resolved.startsWith(allowedTmp + path.sep);
  const isInsideAppDownloads = resolved === allowedAppDownloads || resolved.startsWith(allowedAppDownloads + path.sep);

  if (!isInsideTmp && !isInsideAppDownloads) {
    return {
      valid: false,
      error: `برای امنیت سرور، مسیر ذخیره فقط باید داخل ${allowedTmp} یا ${allowedAppDownloads} باشد (مثلاً /tmp/downloads).`,
    };
  }
  return { valid: true, resolved };
}

// =======================
// Users, Quotas & History
// =======================

export interface BotUserProfile {
  userId: number;
  firstName: string | null;
  username: string | null;
  joinedAt: string;
  lastActiveAt: string;
  isBanned: boolean;
  banReason: string | null;
  dailyLimitOverride: number | null;
  totalRequests: number;
  totalDownloads: number;
  dailyDate: string | null;
  dailyCount: number;
}

export interface UserRequestRecord {
  id: number;
  userId: number;
  platform: string | null;
  url: string | null;
  action: string;
  qualityId: string | null;
  status: string;
  errorMessage: string | null;
  createdAt: string;
}

function getTodayDateUtc(): string {
  return new Date().toISOString().slice(0, 10);
}

function rowToUserProfile(row: any): BotUserProfile {
  const today = getTodayDateUtc();
  return {
    userId: Number(row.user_id),
    firstName: row.first_name || null,
    username: row.username || null,
    joinedAt: row.joined_at,
    lastActiveAt: row.last_active_at,
    isBanned: Boolean(row.is_banned),
    banReason: row.ban_reason || null,
    dailyLimitOverride:
      row.daily_limit_override !== null && row.daily_limit_override !== undefined
        ? Number(row.daily_limit_override)
        : null,
    totalRequests: Number(row.total_requests || 0),
    totalDownloads: Number(row.total_downloads || 0),
    dailyDate: row.daily_date || null,
    dailyCount: row.daily_date === today ? Number(row.daily_count || 0) : 0,
  };
}

export function getUserProfile(userId: number | string): BotUserProfile | null {
  const numId = Number(userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) return null;
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const row = db.prepare('SELECT * FROM users WHERE user_id = ?').get(numId);
  return row ? rowToUserProfile(row) : null;
}

export function upsertUserActivity(
  userId: number | string,
  meta?: { firstName?: string; username?: string }
): { registered: boolean; allowed: boolean; profile?: BotUserProfile } {
  const numId = Number(userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) {
    return { registered: false, allowed: false };
  }
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const existing = db.prepare('SELECT * FROM users WHERE user_id = ?').get(numId);
  const config = loadBotConfig();

  if (!existing && !config.general.allowNewRegistrations && !isUserAdmin(numId)) {
    return { registered: false, allowed: false };
  }

  const now = new Date().toISOString();
  const safeFirstName = meta?.firstName ? String(meta.firstName).slice(0, 100) : null;
  const safeUsername = meta?.username ? String(meta.username).replace(/^@/, '').slice(0, 80) : null;

  if (!existing) {
    db.prepare(
      `INSERT INTO users (user_id, first_name, username, joined_at, last_active_at, total_requests)
       VALUES (?, ?, ?, ?, ?, 1)`
    ).run(numId, safeFirstName, safeUsername, now, now);
  } else {
    db.prepare(
      `UPDATE users SET
         first_name = COALESCE(?, first_name),
         username = COALESCE(?, username),
         last_active_at = ?,
         total_requests = total_requests + 1
       WHERE user_id = ?`
    ).run(safeFirstName, safeUsername, now, numId);
  }

  return {
    registered: !existing,
    allowed: true,
    profile: getUserProfile(numId) || undefined,
  };
}

export function checkUserDailyQuota(userId: number | string): {
  allowed: boolean;
  usedToday: number;
  limit: number;
} {
  if (isUserAdmin(userId)) {
    return { allowed: true, usedToday: 0, limit: 0 };
  }
  const config = loadBotConfig();
  const profile = getUserProfile(userId);
  const effectiveLimit =
    profile?.dailyLimitOverride !== null && profile?.dailyLimitOverride !== undefined
      ? profile.dailyLimitOverride
      : config.download.dailyLimitPerUser;

  if (!effectiveLimit || effectiveLimit <= 0) {
    return { allowed: true, usedToday: profile?.dailyCount || 0, limit: 0 };
  }

  const usedToday = profile?.dailyCount || 0;
  return {
    allowed: usedToday < effectiveLimit,
    usedToday,
    limit: effectiveLimit,
  };
}

export function incrementUserDownloadCount(userId: number | string): void {
  const numId = Number(userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) return;
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const today = getTodayDateUtc();
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO users (user_id, joined_at, last_active_at, total_downloads, daily_date, daily_count)
     VALUES (?, ?, ?, 1, ?, 1)
     ON CONFLICT(user_id) DO UPDATE SET
       last_active_at = excluded.last_active_at,
       total_downloads = total_downloads + 1,
       daily_count = CASE WHEN users.daily_date = excluded.daily_date THEN users.daily_count + 1 ELSE 1 END,
       daily_date = excluded.daily_date`
  ).run(numId, now, now, today);
}

export function recordUserRequestLog(entry: {
  userId: number | string;
  platform?: string;
  url?: string;
  action: string;
  qualityId?: string;
  status: 'pending' | 'success' | 'error' | 'cancelled';
  errorMessage?: string;
}): void {
  const numId = Number(entry.userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) return;
  try {
    bootstrapDbFromLegacyJsonOnce();
    const db = getDb();
    db.prepare(
      `INSERT INTO user_requests (user_id, platform, url, action, quality_id, status, error_message, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      numId,
      entry.platform ? String(entry.platform).slice(0, 32) : null,
      entry.url ? String(entry.url).slice(0, 300) : null,
      String(entry.action).slice(0, 80),
      entry.qualityId ? String(entry.qualityId).slice(0, 40) : null,
      entry.status,
      entry.errorMessage ? String(entry.errorMessage).slice(0, 300) : null,
      new Date().toISOString()
    );
  } catch {}
}

export function getUserRequestHistory(userId: number | string, limit: number = 10): UserRequestRecord[] {
  const numId = Number(userId);
  if (!Number.isSafeInteger(numId) || numId <= 0) return [];
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM user_requests WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(numId, Math.max(1, Math.min(30, limit)));
  return rows.map((r: any) => ({
    id: Number(r.id),
    userId: Number(r.user_id),
    platform: r.platform || null,
    url: r.url || null,
    action: r.action,
    qualityId: r.quality_id || null,
    status: r.status,
    errorMessage: r.error_message || null,
    createdAt: r.created_at,
  }));
}

export function getRecentDownloaderErrors(platformFilter?: string, limit: number = 12): UserRequestRecord[] {
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const safeLimit = Math.max(1, Math.min(30, limit));
  const rows = platformFilter
    ? db
        .prepare("SELECT * FROM user_requests WHERE status = 'error' AND platform = ? ORDER BY id DESC LIMIT ?")
        .all(platformFilter, safeLimit)
    : db.prepare("SELECT * FROM user_requests WHERE status = 'error' ORDER BY id DESC LIMIT ?").all(safeLimit);

  return rows.map((r: any) => ({
    id: Number(r.id),
    userId: Number(r.user_id),
    platform: r.platform || null,
    url: r.url || null,
    action: r.action,
    qualityId: r.quality_id || null,
    status: r.status,
    errorMessage: r.error_message || null,
    createdAt: r.created_at,
  }));
}

export function setUserBannedStatus(
  targetUserId: number,
  banned: boolean,
  reason: string | null = null,
  actorId: number | null = null
): boolean {
  if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0) return false;
  if (isUserAdmin(targetUserId)) return false;
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO users (user_id, joined_at, last_active_at, is_banned, ban_reason)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       is_banned = excluded.is_banned,
       ban_reason = excluded.ban_reason`
  ).run(targetUserId, now, now, banned ? 1 : 0, banned ? reason : null);

  if (actorId) {
    recordAuditLog({
      actorId,
      actorRole: getAdminRecord(actorId)?.role,
      action: banned ? 'ban_user' : 'unban_user',
      section: 'users',
      oldValue: null,
      newValue: `user=${targetUserId}${reason ? `,reason=${reason.slice(0, 60)}` : ''}`,
      result: 'success',
    });
  }
  return true;
}

export function setUserDailyLimitOverride(
  targetUserId: number,
  limitOrNull: number | null,
  actorId: number | null = null
): boolean {
  if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0) return false;
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO users (user_id, joined_at, last_active_at, daily_limit_override)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       daily_limit_override = excluded.daily_limit_override`
  ).run(targetUserId, now, now, limitOrNull);

  if (actorId) {
    recordAuditLog({
      actorId,
      actorRole: getAdminRecord(actorId)?.role,
      action: 'set_user_quota',
      section: 'users',
      oldValue: null,
      newValue: `user=${targetUserId},limit=${limitOrNull === null ? 'global' : limitOrNull}`,
      result: 'success',
    });
  }
  return true;
}

export function getActiveUsersList(withinHours: number = 24, limit: number = 15): BotUserProfile[] {
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const sinceIso = new Date(Date.now() - withinHours * 3600_000).toISOString();
  const rows = db
    .prepare('SELECT * FROM users WHERE last_active_at >= ? ORDER BY last_active_at DESC LIMIT ?')
    .all(sinceIso, Math.max(1, Math.min(30, limit)));
  return rows.map(rowToUserProfile);
}

export function getUsersStatsSummary(): {
  totalUsers: number;
  active24h: number;
  bannedUsers: number;
  totalRecordedDownloads: number;
} {
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const total = db.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number };
  const active = db
    .prepare('SELECT COUNT(*) as cnt FROM users WHERE last_active_at >= ?')
    .get(new Date(Date.now() - 24 * 3600_000).toISOString()) as { cnt: number };
  const banned = db.prepare('SELECT COUNT(*) as cnt FROM users WHERE is_banned = 1').get() as { cnt: number };
  const dlSum = db.prepare('SELECT COALESCE(SUM(total_downloads), 0) as total FROM users').get() as { total: number };
  return {
    totalUsers: Number(total?.cnt || 0),
    active24h: Number(active?.cnt || 0),
    bannedUsers: Number(banned?.cnt || 0),
    totalRecordedDownloads: Number(dlSum?.total || 0),
  };
}

/**
 * Legacy-compatible user registration & counters
 */
export function registerUserId(userId: number | string): void {
  upsertUserActivity(userId);
}

export function flushBotUsersSync(): void {
  // SQLite WAL persists writes synchronously per statement; checkpoint WAL cleanly on shutdown
  try {
    const db = getDb();
    db.exec('PRAGMA wal_checkpoint(PASSIVE);');
  } catch {}
}

export function getRegisteredUsers(): number[] {
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const rows = db.prepare('SELECT user_id FROM users WHERE is_banned = 0').all() as Array<{ user_id: number }>;
  return rows.map((r) => Number(r.user_id));
}

export function getRegisteredUsersCount(): number {
  bootstrapDbFromLegacyJsonOnce();
  const db = getDb();
  const row = db.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number } | undefined;
  return Number(row?.cnt || 0);
}
