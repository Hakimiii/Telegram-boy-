import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { GoogleGenAI } from '@google/genai';
import {
  identifyPlatform,
  getStandardQualityOptions,
  extractDynamicQualityOptions,
  type VideoFormatOption,
  formatDuration,
  formatFileSize,
  parseSongInfoFromText,
  type IdentifiedSong,
  extractInstagramShortcode,
  isInstagramCookieRejectionError,
  parseInstagramEmbedHtml,
} from './mediaParser.ts';
import { extractSpotifyInfo, downloadSpotifyTrack } from './spotifyResolver.ts';
import { validateSafeHttpUrl, AsyncSemaphore } from '../utils/resilience.ts';

import { loadBotConfig } from './configManager.ts';

export { validateSafeHttpUrl };

const execFileAsync = promisify(execFile);
const YT_DLP_PATH = path.resolve(process.cwd(), 'bin/yt-dlp');
const DEFAULT_DOWNLOAD_DIR = path.resolve('/tmp/downloads');
const PRIMARY_COOKIES_PATH = path.resolve(process.cwd(), 'instagram_cookies.txt');
const BACKUP_COOKIES_PATH = path.resolve('/tmp/instagram_cookies.txt');
const PRIMARY_YT_COOKIES_PATH = path.resolve(process.cwd(), 'youtube_cookies.txt');
const BACKUP_YT_COOKIES_PATH = path.resolve('/tmp/youtube_cookies.txt');

export function getActiveDownloadDir(): string {
  try {
    const dir = loadBotConfig().download.storagePath || DEFAULT_DOWNLOAD_DIR;
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    return dir;
  } catch {
    if (!fs.existsSync(DEFAULT_DOWNLOAD_DIR)) {
      fs.mkdirSync(DEFAULT_DOWNLOAD_DIR, { recursive: true });
    }
    return DEFAULT_DOWNLOAD_DIR;
  }
}

const MAX_CONCURRENT_DOWNLOADS = Math.max(
  1,
  Math.min(8, parseInt(process.env.MAX_CONCURRENT_DOWNLOADS || '3', 10) || 3)
);
const downloadSemaphore = new AsyncSemaphore(MAX_CONCURRENT_DOWNLOADS);

export interface ActiveDownloadEntry {
  id: string;
  userId?: number | string;
  platform: string;
  url: string;
  startedAt: number;
  percent: number;
  cancel: () => void;
}

const activeDownloadsRegistry = new Map<string, ActiveDownloadEntry>();

export function listActiveDownloads(): Array<Omit<ActiveDownloadEntry, 'cancel'>> {
  return Array.from(activeDownloadsRegistry.values()).map(({ cancel: _c, ...rest }) => rest);
}

export function cancelActiveDownload(id: string): boolean {
  const entry = activeDownloadsRegistry.get(id);
  if (!entry) return false;
  try {
    entry.cancel();
  } catch {}
  activeDownloadsRegistry.delete(id);
  return true;
}

export function cancelAllActiveDownloads(): number {
  let count = 0;
  for (const [id, entry] of activeDownloadsRegistry.entries()) {
    try {
      entry.cancel();
      count++;
    } catch {}
    activeDownloadsRegistry.delete(id);
  }
  return count;
}

export function clearMediaCaches(): void {
  mediaInfoCache.clear();
  downloadedFileCache.clear();
}

export function getDownloadQueueStats() {
  return {
    maxConcurrent: loadBotConfig().download.maxConcurrentDownloads || MAX_CONCURRENT_DOWNLOADS,
    active: Math.max(downloadSemaphore.active, activeDownloadsRegistry.size),
    pending: downloadSemaphore.pending,
  };
}

let ytDlpVerified = false;
let ytDlpEnsurePromise: Promise<void> | null = null;

function isPython3Available(): boolean {
  const candidates = ['/usr/bin/python3', '/usr/local/bin/python3', '/bin/python3'];
  for (const p of candidates) {
    if (fs.existsSync(p)) return true;
  }
  const pathDirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  for (const dir of pathDirs) {
    if (fs.existsSync(path.join(dir, 'python3'))) return true;
  }
  return false;
}

function isPythonShebangScript(filePath: string): boolean {
  try {
    const fd = fs.openSync(filePath, 'r');
    const buf = Buffer.alloc(32);
    const bytesRead = fs.readSync(fd, buf, 0, 32, 0);
    fs.closeSync(fd);
    const header = buf.subarray(0, bytesRead).toString('utf-8');
    return header.startsWith('#!') && header.toLowerCase().includes('python');
  } catch {
    return false;
  }
}

function getPreferredYtDlpDownloadUrl(): string {
  if (process.platform === 'linux') {
    if (process.arch === 'arm64') {
      return 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_aarch64';
    }
    return 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux';
  }
  return 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp';
}

export function getYtDlpBinaryPath(): string {
  if (fs.existsSync(YT_DLP_PATH)) {
    if (!ytDlpVerified) {
      try {
        fs.chmodSync(YT_DLP_PATH, 0o755);
      } catch {}
    }
    return YT_DLP_PATH;
  }
  return 'yt-dlp';
}

export async function ensureYtDlpExecutable(): Promise<void> {
  if (ytDlpVerified && fs.existsSync(YT_DLP_PATH)) return;
  if (ytDlpEnsurePromise) return ytDlpEnsurePromise;

  ytDlpEnsurePromise = (async () => {
    const binDir = path.dirname(YT_DLP_PATH);
    if (!fs.existsSync(binDir)) {
      fs.mkdirSync(binDir, { recursive: true });
    }

    const pythonPresent = isPython3Available();

    if (fs.existsSync(YT_DLP_PATH)) {
      try {
        const stat = fs.statSync(YT_DLP_PATH);
        const needsPython = isPythonShebangScript(YT_DLP_PATH);
        if (stat.size > 100_000 && (!needsPython || pythonPresent)) {
          fs.chmodSync(YT_DLP_PATH, 0o755);
          ytDlpVerified = true;
          return;
        }
        if (needsPython && !pythonPresent) {
          console.warn('[yt-dlp] Existing bin/yt-dlp requires python3, which is missing in this container. Replacing with standalone yt-dlp_linux binary...');
        }
      } catch {}
    }

    const primaryUrl = getPreferredYtDlpDownloadUrl();
    const fallbackUrl = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp';
    const urls = primaryUrl === fallbackUrl ? [primaryUrl] : [primaryUrl, fallbackUrl];

    for (const dlUrl of urls) {
      try {
        console.log(`[yt-dlp] Downloading standalone yt-dlp binary from ${dlUrl}...`);
        const res = await fetch(dlUrl, { signal: AbortSignal.timeout(60_000) });
        if (res.ok) {
          const arrayBuf = await res.arrayBuffer();
          const buf = Buffer.from(arrayBuf);
          if (buf.length > 100_000) {
            const tmpPath = `${YT_DLP_PATH}.tmp`;
            fs.writeFileSync(tmpPath, buf);
            fs.chmodSync(tmpPath, 0o755);
            fs.renameSync(tmpPath, YT_DLP_PATH);
            ytDlpVerified = true;
            console.log('[yt-dlp] Standalone binary installed and made executable successfully.');
            return;
          }
        }
      } catch (err) {
        console.warn(`[yt-dlp] Download failed from ${dlUrl}:`, err);
      }
    }
  })().finally(() => {
    ytDlpEnsurePromise = null;
  });

  return ytDlpEnsurePromise;
}

// Ensure default download directory exists
if (!fs.existsSync(DEFAULT_DOWNLOAD_DIR)) {
  fs.mkdirSync(DEFAULT_DOWNLOAD_DIR, { recursive: true });
}

const INVALID_IG_COOKIE_MARKER = path.resolve('/tmp/ig_invalid_cookie.sha256');
const rejectedIgCookieHashes = new Set<string>();

function hashCookieSecret(val: string): string {
  return crypto.createHash('sha256').update(val.trim()).digest('hex');
}

function isPlaceholderInstagramSession(val: string): boolean {
  const lower = val.trim().toLowerCase();
  if (!lower) return false;
  const placeholders = new Set([
    'your_session_id',
    'your_instagram_session_id',
    'session_id',
    'placeholder',
    'changeme',
    'change_me',
    'none',
    'null',
    'undefined',
    'false',
    'test',
  ]);
  if (placeholders.has(lower) || /^<.*>$/.test(lower)) return true;
  const isNetscape = val.includes('\t') || val.includes('# Netscape');
  if (!isNetscape && (val.length < 8 || /\s/.test(val))) {
    return true;
  }
  return false;
}

function isKnownInvalidInstagramSession(val: string): boolean {
  const digest = hashCookieSecret(val);
  if (rejectedIgCookieHashes.has(digest)) return true;
  try {
    if (fs.existsSync(INVALID_IG_COOKIE_MARKER)) {
      const stored = fs.readFileSync(INVALID_IG_COOKIE_MARKER, 'utf-8')
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean);
      for (const h of stored) rejectedIgCookieHashes.add(h);
      return rejectedIgCookieHashes.has(digest);
    }
  } catch {}
  return false;
}

function recordInvalidInstagramSession(val: string): void {
  const trimmed = val.trim();
  if (!trimmed) return;
  const digest = hashCookieSecret(trimmed);
  rejectedIgCookieHashes.add(digest);
  try {
    const existing = fs.existsSync(INVALID_IG_COOKIE_MARKER)
      ? fs.readFileSync(INVALID_IG_COOKIE_MARKER, 'utf-8').split('\n').map((l) => l.trim()).filter(Boolean)
      : [];
    if (!existing.includes(digest)) {
      existing.push(digest);
      fs.writeFileSync(INVALID_IG_COOKIE_MARKER, existing.slice(-10).join('\n') + '\n', { encoding: 'utf-8', mode: 0o600 });
    }
  } catch {}
}

function clearInvalidInstagramSessionMarker(): void {
  rejectedIgCookieHashes.clear();
  try {
    if (fs.existsSync(INVALID_IG_COOKIE_MARKER)) fs.unlinkSync(INVALID_IG_COOKIE_MARKER);
  } catch {}
}

export function invalidateBadInstagramCookies(): void {
  try {
    const activePath = getActiveInstagramCookiesPath();
    if (activePath && fs.existsSync(activePath)) {
      const raw = fs.readFileSync(activePath, 'utf-8');
      recordInvalidInstagramSession(raw);
      // Also extract raw sessionid token if stored in Netscape format
      const tokenMatch = raw.match(/\tsessionid\t([^\s\n]+)/);
      if (tokenMatch?.[1]) {
        recordInvalidInstagramSession(tokenMatch[1]);
      }
    }
    if (process.env.INSTAGRAM_SESSION_ID) {
      recordInvalidInstagramSession(process.env.INSTAGRAM_SESSION_ID);
    }
  } catch {}
  clearInstagramCookies();
}

// Initialize session cookies from env if present (skipping previously invalidated/placeholder values)
if (process.env.INSTAGRAM_SESSION_ID && !hasInstagramCookies()) {
  saveInstagramSession(process.env.INSTAGRAM_SESSION_ID, { source: 'env' });
}

export function clearInstagramCookies() {
  try {
    if (fs.existsSync(PRIMARY_COOKIES_PATH)) fs.unlinkSync(PRIMARY_COOKIES_PATH);
    if (fs.existsSync(BACKUP_COOKIES_PATH)) fs.unlinkSync(BACKUP_COOKIES_PATH);
    console.log('[Instagram] Cookies cleared.');
  } catch (err) {
    console.warn('[Instagram] Error clearing cookies:', err);
  }
}

export function saveInstagramSession(
  sessionIdOrNetscape: string,
  options?: { source?: 'env' | 'manual' }
): { success: boolean; message: string } {
  try {
    const val = sessionIdOrNetscape.trim();
    if (!val) {
      clearInvalidInstagramSessionMarker();
      clearInstagramCookies();
      return { success: true, message: 'سشن اینستاگرام با موفقیت حذف شد.' };
    }

    if (isPlaceholderInstagramSession(val)) {
      return { success: false, message: 'مقدار سشن اینستاگرام نامعتبر یا پیش‌فرض است.' };
    }

    if (options?.source === 'env' && isKnownInvalidInstagramSession(val)) {
      return { success: false, message: 'سشن محیطی اینستاگرام قبلاً منقضی تشخیص داده شده و نادیده گرفته شد.' };
    }

    if (options?.source !== 'env') {
      clearInvalidInstagramSessionMarker();
    }

    let cookieContent = '';
    if (val.includes('\t') || val.includes('# Netscape')) {
      cookieContent = val.endsWith('\n') ? val : val + '\n';
    } else {
      cookieContent = `# Netscape HTTP Cookie File\n.instagram.com\tTRUE\t/\tTRUE\t2147483647\tsessionid\t${val}\n`;
    }

    fs.writeFileSync(PRIMARY_COOKIES_PATH, cookieContent, { encoding: 'utf-8', mode: 0o600 });
    try {
      fs.writeFileSync(BACKUP_COOKIES_PATH, cookieContent, { encoding: 'utf-8', mode: 0o600 });
    } catch {}

    return { success: true, message: 'کوکی و سشن اینستاگرام با موفقیت ذخیره شد.' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'خطا در ذخیره سشن' };
  }
}

export function hasInstagramCookies(): boolean {
  return fs.existsSync(PRIMARY_COOKIES_PATH) || fs.existsSync(BACKUP_COOKIES_PATH);
}

function getActiveInstagramCookiesPath(): string | null {
  if (fs.existsSync(PRIMARY_COOKIES_PATH)) return PRIMARY_COOKIES_PATH;
  if (fs.existsSync(BACKUP_COOKIES_PATH)) return BACKUP_COOKIES_PATH;
  return null;
}

export function clearYoutubeCookies() {
  try {
    if (fs.existsSync(PRIMARY_YT_COOKIES_PATH)) fs.unlinkSync(PRIMARY_YT_COOKIES_PATH);
    if (fs.existsSync(BACKUP_YT_COOKIES_PATH)) fs.unlinkSync(BACKUP_YT_COOKIES_PATH);
    console.log('[YouTube] Cookies cleared.');
  } catch (err) {
    console.warn('[YouTube] Error clearing cookies:', err);
  }
}

export function saveYoutubeCookies(cookiesContent: string): { success: boolean; message: string } {
  try {
    const val = cookiesContent.trim();
    if (!val) {
      clearYoutubeCookies();
      return { success: true, message: 'کوکی یوتیوب حذف شد.' };
    }
    const cleanContent = val.endsWith('\n') ? val : val + '\n';
    fs.writeFileSync(PRIMARY_YT_COOKIES_PATH, cleanContent, { encoding: 'utf-8', mode: 0o600 });
    try {
      fs.writeFileSync(BACKUP_YT_COOKIES_PATH, cleanContent, { encoding: 'utf-8', mode: 0o600 });
    } catch {}
    return { success: true, message: 'کوکی‌های یوتیوب با موفقیت ذخیره و فعال شدند.' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'خطا در ذخیره کوکی یوتیوب' };
  }
}

export function hasYoutubeCookies(): boolean {
  return fs.existsSync(PRIMARY_YT_COOKIES_PATH) || fs.existsSync(BACKUP_YT_COOKIES_PATH);
}

function getActiveYoutubeCookiesPath(): string | null {
  if (fs.existsSync(PRIMARY_YT_COOKIES_PATH)) return PRIMARY_YT_COOKIES_PATH;
  if (fs.existsSync(BACKUP_YT_COOKIES_PATH)) return BACKUP_YT_COOKIES_PATH;
  return null;
}

function getActiveCookieFileForUrl(url: string): string | null {
  if (url.includes('instagram.com')) {
    return getActiveInstagramCookiesPath();
  }
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    return getActiveYoutubeCookiesPath();
  }
  return null;
}

function getYoutubeExtraArgsArray(url: string): string[] {
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    if (hasYoutubeCookies()) {
      return [];
    }
    return ['--extractor-args', 'youtube:player-client=android,web'];
  }
  return [];
}

export interface ExtractedMediaInfo {
  url: string;
  title: string;
  thumbnail: string;
  duration: number;
  durationFormatted: string;
  uploader: string;
  platform: string;
  platformNameFa: string;
  platformNameEn: string;
  viewCount?: number;
  availableFormats: VideoFormatOption[];
  track?: string;
  artist?: string;
  album?: string;
  genre?: string;
}

export interface DownloadResult {
  id: string;
  filePath: string;
  fileName: string;
  fileSizeBytes: number;
  fileSizeFormatted: string;
  mimeType: string;
  title: string;
  duration: number;
  ext: string;
  songInfo?: IdentifiedSong;
}

export interface DownloadProgress {
  percent: number;
  downloadedFormatted?: string;
  totalFormatted?: string;
  speedFormatted?: string;
  etaFormatted?: string;
  stage?: 'downloading' | 'processing' | 'uploading';
}

export interface RunYtDlpOptions {
  downloadId?: string;
  userId?: number | string;
  platform?: string;
  url?: string;
  signal?: AbortSignal;
}

/**
 * Executes yt-dlp with realtime streaming progress feedback & cancellation support
 */
export function runYtDlpDownload(
  args: string[],
  onProgress?: (progress: DownloadProgress) => void,
  timeoutMs?: number,
  meta?: RunYtDlpOptions
): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  const configuredTimeoutMs = (loadBotConfig().download.maxDownloadTimeSec || 180) * 1000;
  const effectiveTimeoutMs = timeoutMs ?? configuredTimeoutMs;
  const downloadDir = getActiveDownloadDir();

  return new Promise((resolve, reject) => {
    const ytBin = getYtDlpBinaryPath();
    const child = spawn(ytBin, args);
    let stdout = '';
    let stderr = '';
    let timer: NodeJS.Timeout | null = null;
    let cancelled = false;

    const regId = meta?.downloadId || crypto.randomUUID().slice(0, 8);
    const killChild = () => {
      if (cancelled) return;
      cancelled = true;
      if (timer) clearTimeout(timer);
      try {
        child.kill('SIGKILL');
      } catch {}
    };

    activeDownloadsRegistry.set(regId, {
      id: regId,
      userId: meta?.userId,
      platform: meta?.platform || 'other',
      url: meta?.url || '',
      startedAt: Date.now(),
      percent: 0,
      cancel: killChild,
    });

    if (meta?.signal) {
      if (meta.signal.aborted) {
        killChild();
      } else {
        meta.signal.addEventListener('abort', killChild, { once: true });
      }
    }

    if (effectiveTimeoutMs > 0) {
      timer = setTimeout(() => {
        try { child.kill('SIGKILL'); } catch {}
        activeDownloadsRegistry.delete(regId);
        reject(new Error(`دانلود بیش از حد مجاز زمان برد (${Math.round(effectiveTimeoutMs / 1000)} ثانیه).`));
      }, effectiveTimeoutMs);
    }

    let buffer = '';
    let streamPass = 1;
    let lastRawPercent = 0;
    let maxEmittedPercent = 0;

    child.stdout.on('data', (chunk) => {
      const str = chunk.toString();
      stdout += str;
      buffer += str;

      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (!line.includes('[download]')) continue;
        const m = line.match(/\[download\]\s+([0-9.]+)%\s+of\s+~?\s*([^\s]+)(?:\s+(?:in\s+([^\s]+)\s+at|at)\s+([^\s]+))?(?:\s+ETA\s+([^\s]+))?/i);
        if (m) {
          const rawPercent = parseFloat(m[1]);
          const totalRaw = m[2];
          const speedRaw = m[4] || (m[3] && !m[4] ? m[3] : undefined);
          const etaRaw = m[5];

          // Detect transition between video and audio stream downloads to prevent percentage resets
          if (rawPercent < lastRawPercent - 20 && lastRawPercent >= 90) {
            streamPass++;
          }
          lastRawPercent = rawPercent;

          let scaledPercent = rawPercent;
          if (streamPass === 1) {
            // First stream (usually video): scales 0..100 -> 0..75%
            scaledPercent = Math.min(75, Math.round(rawPercent * 0.75));
          } else if (streamPass >= 2) {
            // Second stream (usually audio): scales 0..100 -> 75..96%
            scaledPercent = Math.min(96, 75 + Math.round(rawPercent * 0.21));
          }

          maxEmittedPercent = Math.max(maxEmittedPercent, scaledPercent);

          let downloadedFormatted: string | undefined;
          let totalFormatted = totalRaw;
          const numMatch = totalRaw.match(/([0-9.]+)([A-Za-z]+)/);
          if (numMatch) {
            const val = parseFloat(numMatch[1]);
            const unit = numMatch[2];
            const downloadedVal = (val * (rawPercent / 100)).toFixed(1);
            downloadedFormatted = `${downloadedVal} ${unit}`;
          }

          const activeEntry = activeDownloadsRegistry.get(regId);
          if (activeEntry) activeEntry.percent = maxEmittedPercent;

          onProgress?.({
            percent: maxEmittedPercent,
            downloadedFormatted,
            totalFormatted,
            speedFormatted: speedRaw && speedRaw !== 'Unknown' ? speedRaw : undefined,
            etaFormatted: etaRaw && etaRaw !== 'Unknown' ? etaRaw : undefined,
            stage: maxEmittedPercent >= 97 ? 'processing' : 'downloading',
          });
        }
      }
    });

    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });

    child.on('error', (err) => {
      if (timer) clearTimeout(timer);
      activeDownloadsRegistry.delete(regId);
      reject(err);
    });

    child.on('close', (code) => {
      if (timer) clearTimeout(timer);
      activeDownloadsRegistry.delete(regId);
      if (cancelled) {
        reject(new Error('دانلود توسط مدیر لغو شد.'));
        return;
      }
      if (code === 0) {
        resolve({ stdout, stderr, exitCode: code });
      } else {
        // Check if output file was written to disk despite non-zero exit code
        const oIndex = args.indexOf('-o');
        if (oIndex !== -1 && args[oIndex + 1]) {
          const expectedPrefix = path.basename(args[oIndex + 1]).split('.')[0].replace(/%[^\s]+/g, '');
          if (expectedPrefix) {
            const matches = fs.readdirSync(downloadDir).filter(f => f.startsWith(expectedPrefix));
            if (matches.length > 0) {
              const fullP = path.join(downloadDir, matches[0]);
              if (fs.existsSync(fullP) && fs.statSync(fullP).size > 10000) {
                console.log(`[yt-dlp] Non-zero exit code ${code}, but valid file exists: ${matches[0]}`);
                resolve({ stdout, stderr, exitCode: code ?? 0 });
                return;
              }
            }
          }
        }
        const errorMsg = stderr.trim() || stdout.trim() || `yt-dlp exited with code ${code}`;
        reject(new Error(errorMsg));
      }
    });
  });
}

/**
 * Clean up old downloads, stale partial files, and enforce disk budget
 */
export function cleanOldDownloads(forceAll: boolean = false): { deletedCount: number; freedBytes: number } {
  let deletedCount = 0;
  let freedBytes = 0;
  try {
    const downloadDir = getActiveDownloadDir();
    if (!fs.existsSync(downloadDir)) return { deletedCount: 0, freedBytes: 0 };
    const retentionMinutes = Math.max(1, loadBotConfig().download.tempRetentionMinutes || 20);
    const retentionMs = retentionMinutes * 60 * 1000;
    const files = fs.readdirSync(downloadDir);
    const now = Date.now();
    let totalSizeBytes = 0;
    const fileStats: { file: string; fullPath: string; mtimeMs: number; size: number }[] = [];

    for (const file of files) {
      try {
        const fullPath = path.join(downloadDir, file);
        const stat = fs.statSync(fullPath);

        if (forceAll) {
          fs.unlinkSync(fullPath);
          deletedCount++;
          freedBytes += stat.size;
          continue;
        }

        // Immediately clean stale .part / .ytdl / .info.json files older than 10 minutes
        const isTempArtifact = file.endsWith('.part') || file.endsWith('.ytdl') || file.endsWith('.info.json');
        if (isTempArtifact && now - stat.mtimeMs > 10 * 60 * 1000) {
          fs.unlinkSync(fullPath);
          deletedCount++;
          freedBytes += stat.size;
          continue;
        }

        // Remove completed files older than configured retention
        if (now - stat.mtimeMs > retentionMs) {
          fs.unlinkSync(fullPath);
          deletedCount++;
          freedBytes += stat.size;
          continue;
        }

        totalSizeBytes += stat.size;
        fileStats.push({ file, fullPath, mtimeMs: stat.mtimeMs, size: stat.size });
      } catch {}
    }

    // If total storage exceeds 800MB, remove oldest files until under 400MB
    if (totalSizeBytes > 800 * 1024 * 1024) {
      fileStats.sort((a, b) => a.mtimeMs - b.mtimeMs);
      for (const item of fileStats) {
        if (totalSizeBytes <= 400 * 1024 * 1024) break;
        try {
          if (fs.existsSync(item.fullPath)) {
            fs.unlinkSync(item.fullPath);
            totalSizeBytes -= item.size;
            deletedCount++;
            freedBytes += item.size;
          }
        } catch {}
      }
    }
  } catch (err) {
    console.error('Error cleaning old downloads:', err);
  }
  return { deletedCount, freedBytes };
}

export function ensureSufficientDiskSpace(minFreeMb: number = 250): void {
  try {
    const downloadDir = getActiveDownloadDir();
    if (!fs.existsSync(downloadDir)) {
      fs.mkdirSync(downloadDir, { recursive: true });
    }
    if (typeof fs.statfsSync !== 'function') return;
    const stats = fs.statfsSync(downloadDir);
    const freeMb = (Number(stats.bavail) * Number(stats.bsize)) / (1024 * 1024);
    if (freeMb < minFreeMb) {
      cleanOldDownloads(false);
      const afterStats = fs.statfsSync(downloadDir);
      const afterFreeMb = (Number(afterStats.bavail) * Number(afterStats.bsize)) / (1024 * 1024);
      if (afterFreeMb < minFreeMb) {
        throw new Error(`فضای خالی دیسک سرور کافی نیست (${Math.round(afterFreeMb)} مگابایت باقی‌مانده). لطفاً دقایقی دیگر تلاش کنید.`);
      }
    }
  } catch (err: any) {
    if (err?.message?.includes('فضای خالی دیسک')) throw err;
  }
}

// Clean on initialization and periodically every 10 minutes
cleanOldDownloads();
const cleanupInterval = setInterval(cleanOldDownloads, 10 * 60 * 1000);
if (cleanupInterval.unref) cleanupInterval.unref();

const mediaInfoCache = new Map<string, { data: ExtractedMediaInfo; exp: number }>();
const MAX_MEDIA_INFO_CACHE = 250;

export function getCachedMediaInfo(url: string): ExtractedMediaInfo | null {
  const clean = identifyPlatform(url).cleanUrl;
  const item = mediaInfoCache.get(clean);
  if (item && item.exp > Date.now()) {
    return item.data;
  }
  if (item) mediaInfoCache.delete(clean);
  return null;
}

export function cacheMediaInfo(url: string, data: ExtractedMediaInfo, ttlMs: number = 30 * 60 * 1000) {
  const clean = identifyPlatform(url).cleanUrl;
  if (mediaInfoCache.has(clean)) {
    mediaInfoCache.delete(clean);
  }
  mediaInfoCache.set(clean, { data, exp: Date.now() + ttlMs });

  if (mediaInfoCache.size > MAX_MEDIA_INFO_CACHE) {
    const now = Date.now();
    for (const [k, v] of mediaInfoCache) {
      if (v.exp < now) mediaInfoCache.delete(k);
    }
    while (mediaInfoCache.size > MAX_MEDIA_INFO_CACHE) {
      const oldestKey = mediaInfoCache.keys().next().value;
      if (oldestKey === undefined) break;
      mediaInfoCache.delete(oldestKey);
    }
  }
}

const inFlightExtractions = new Map<string, Promise<ExtractedMediaInfo>>();

/**
 * Extract video information & formats using yt-dlp (with deduplication & shell-free execution)
 */
export async function extractMediaInfo(url: string): Promise<ExtractedMediaInfo> {
  const safeInputUrl = validateSafeHttpUrl(url);
  const platform = identifyPlatform(safeInputUrl);
  const cleanUrl = validateSafeHttpUrl(platform.cleanUrl);

  const cached = getCachedMediaInfo(cleanUrl);
  if (cached) {
    return cached;
  }

  const existingPromise = inFlightExtractions.get(cleanUrl);
  if (existingPromise) {
    return existingPromise;
  }

  const extractionPromise = (async (): Promise<ExtractedMediaInfo> => {
    if (platform.platform === 'spotify') {
      const sp = await extractSpotifyInfo(cleanUrl);
      const spResult: ExtractedMediaInfo = {
        url: cleanUrl,
        title: sp.title,
        thumbnail: sp.thumbnail,
        duration: 180,
        durationFormatted: '3:00',
        uploader: sp.artist,
        platform: 'spotify',
        platformNameFa: 'اسپاتیفای',
        platformNameEn: 'Spotify',
        availableFormats: [
          {
            id: 'best_audio',
            label: '🎵 320kbps MP3 (Original)',
            labelFa: '🎵 دانلود فایل صوتی اورجینال (320k)',
            resolution: '320kbps',
            ext: 'mp3',
            isAudioOnly: true,
            qualityRank: 1,
          }
        ],
        track: sp.title,
        artist: sp.artist,
        album: sp.album,
      };
      cacheMediaInfo(cleanUrl, spResult);
      return spResult;
    }

    await ensureYtDlpExecutable();
    const cookieFile = getActiveCookieFileForUrl(cleanUrl);
    const userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
    const ytArgs = getYoutubeExtraArgsArray(cleanUrl);
    const ytDlpBin = getYtDlpBinaryPath();

    const baseArgs = [
      '--dump-json',
      '--js-runtimes', 'node',
      '--no-warnings',
      '--no-playlist',
      '--flat-playlist',
      '--no-check-certificates',
      '--socket-timeout', '10',
      '--extractor-retries', '1',
      '--skip-download',
      '--user-agent', userAgent,
      ...ytArgs,
    ];

    const argsWithCookies = cookieFile
      ? [...baseArgs, '--cookies', cookieFile, cleanUrl]
      : [...baseArgs, cleanUrl];

    try {
      let stdoutData = '';
      try {
        const res = await execFileAsync(ytDlpBin, argsWithCookies, { timeout: 25000, maxBuffer: 10 * 1024 * 1024 });
        stdoutData = res.stdout;
      } catch (cmdErr: any) {
        if (cookieFile) {
          console.log(`[yt-dlp] Cookie extraction failed for ${platform.platformNameEn}; retrying without cookies.`);
          const res = await execFileAsync(ytDlpBin, [...baseArgs, cleanUrl], { timeout: 25000, maxBuffer: 10 * 1024 * 1024 });
          stdoutData = res.stdout;
          if (platform.platform === 'instagram' && isInstagramCookieRejectionError(cmdErr?.message || '')) {
            console.log('[Instagram] Stored cookie session was rejected; automatically cleared stale cookie.');
            invalidateBadInstagramCookies();
          }
        } else {
          throw cmdErr;
        }
      }
      const info = JSON.parse(stdoutData);

      const title = info.title || `${platform.platformNameFa} - ویدیو`;
      const thumbnail = info.thumbnail || info.thumbnails?.[0]?.url || '';
      const duration = info.duration || 0;
      const uploader = info.uploader || info.channel || info.uploader_id || platform.platformNameEn;
      const viewCount = info.view_count || undefined;

      const track = info.track || undefined;
      const artist = info.artist || (info.artists && info.artists[0]) || undefined;
      const album = info.album || undefined;
      const genre = info.genre || (info.genres && info.genres[0]) || undefined;

      const formats = extractDynamicQualityOptions(info.formats, duration, platform.platform);

      const result: ExtractedMediaInfo = {
        url: cleanUrl,
        title,
        thumbnail,
        duration,
        durationFormatted: formatDuration(duration),
        uploader,
        platform: platform.platform,
        platformNameFa: platform.platformNameFa,
        platformNameEn: platform.platformNameEn,
        viewCount,
        availableFormats: formats,
        track,
        artist,
        album,
        genre,
      };
      cacheMediaInfo(cleanUrl, result);
      return result;
    } catch (err: any) {
      const summary = String(err?.message || err || '')
        .replace(/\bERROR:\s*/gi, '')
        .split('\n')[0]
        .slice(0, 180);
      console.log(`[yt-dlp] Metadata extraction fallback to standard options for ${cleanUrl}: ${summary}`);

      const formats = getStandardQualityOptions(platform.platform);
      return {
        url: cleanUrl,
        title: `${platform.platformNameFa} - رسانه آماده دانلود`,
        thumbnail: '',
        duration: 0,
        durationFormatted: 'نامشخص',
        uploader: platform.platformNameFa,
        platform: platform.platform,
        platformNameFa: platform.platformNameFa,
        platformNameEn: platform.platformNameEn,
        availableFormats: formats,
      };
    }
  })();

  inFlightExtractions.set(cleanUrl, extractionPromise);
  try {
    return await extractionPromise;
  } finally {
    inFlightExtractions.delete(cleanUrl);
  }
}

/**
 * AI & Heuristic Song Recognition for Reels and Videos
 */
export async function identifySongFromMedia(url: string, existingInfo?: ExtractedMediaInfo): Promise<IdentifiedSong> {
  const info = existingInfo || await extractMediaInfo(url);

  // If yt-dlp extracted embedded track and artist
  if (info.track && info.artist) {
    return {
      title: info.track,
      artist: info.artist,
      album: info.album || 'Single',
      genre: info.genre,
      confidence: 'high',
      searchQuery: `${info.artist} - ${info.track}`,
    };
  }

  // Parse title heuristics
  const heuristic = parseSongInfoFromText(info.title, info.uploader);

  // If Gemini API key is present, use AI for smart identification
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
    try {
      const ai = new GoogleGenAI();
      const prompt = `Identify the exact music track, song name, and artist used in this social media post/reel.
Post Title: "${info.title}"
Platform: "${info.platformNameEn}"
Uploader/Creator: "${info.uploader}"
URL: "${info.url}"

Respond in JSON format only:
{
  "title": "Exact Song Name",
  "artist": "Artist or Band Name",
  "album": "Album Name (or Single)",
  "genre": "Genre",
  "confidence": "high" or "medium"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      if (parsed.title && parsed.artist) {
        return {
          title: parsed.title,
          artist: parsed.artist,
          album: parsed.album || 'Single',
          genre: parsed.genre,
          confidence: 'high',
          searchQuery: `${parsed.artist} - ${parsed.title}`,
        };
      }
    } catch (e) {
      console.warn('Gemini song recognition fallback:', e);
    }
  }

  return heuristic;
}

const downloadedFileCache = new Map<string, { result: DownloadResult; exp: number }>();
const inFlightDownloads = new Map<string, Promise<DownloadResult>>();

/**
 * Downloads a video or audio file with the specified quality
 */
export async function downloadMedia(
  url: string,
  qualityId: string = 'best_720',
  onProgress?: (progress: DownloadProgress) => void,
  userId?: number | string
): Promise<DownloadResult> {
  const safeInputUrl = validateSafeHttpUrl(url);
  const platform = identifyPlatform(safeInputUrl);
  const cleanUrl = validateSafeHttpUrl(platform.cleanUrl);

  const cfg = loadBotConfig();
  if (!cfg.general.downloadsServiceEnabled || !cfg.download.enabled) {
    throw new Error('سرویس دانلود موقتاً توسط مدیر ربات غیرفعال شده است.');
  }

  const downloadDir = getActiveDownloadDir();
  const cacheKey = `${cleanUrl}::${qualityId}`;
  const cachedEntry = downloadedFileCache.get(cacheKey);
  if (cachedEntry && cachedEntry.exp > Date.now() && fs.existsSync(cachedEntry.result.filePath)) {
    onProgress?.({ percent: 100, stage: 'uploading' });
    return cachedEntry.result;
  }

  const existingDownload = inFlightDownloads.get(cacheKey);
  if (existingDownload) {
    return existingDownload;
  }

  const runDownload = downloadSemaphore.run(async (): Promise<DownloadResult> => {
    ensureSufficientDiskSpace(250);
    if (platform.platform === 'spotify') {
      onProgress?.({ percent: 15, stage: 'downloading' });
      const sp = await extractSpotifyInfo(cleanUrl);
      onProgress?.({ percent: 45, stage: 'downloading' });
      const result = await downloadSpotifyTrack(sp);
      onProgress?.({ percent: 100, stage: 'uploading' });
      const dlResult: DownloadResult = {
        id: result.id,
        filePath: result.filePath,
        fileName: result.fileName,
        fileSizeBytes: result.fileSizeBytes,
        fileSizeFormatted: result.fileSizeFormatted,
        mimeType: 'audio/mpeg',
        title: `${result.artist} - ${result.title}`,
        duration: 180,
        ext: 'mp3',
        songInfo: {
          title: result.title,
          artist: result.artist,
          album: result.album,
          confidence: 'high',
          searchQuery: `${result.artist} ${result.title}`,
        },
      };
      downloadedFileCache.set(cacheKey, { result: dlResult, exp: Date.now() + 15 * 60 * 1000 });
      return dlResult;
    }

    const cookieFile = getActiveCookieFileForUrl(cleanUrl);
    const fileId = crypto.randomUUID();
    const isAudio = qualityId === 'best_audio' || qualityId === 'standard_audio' || qualityId === 'find_song';
    const configuredFormat = cfg.download.outputFormat || 'mp4';
    const audioFormat = configuredFormat === 'm4a' ? 'm4a' : 'mp3';
    const videoContainer = configuredFormat === 'mkv' ? 'mkv' : 'mp4';
    const ext = isAudio ? audioFormat : videoContainer;
    const outputTemplate = path.join(downloadDir, `${fileId}.%(ext)s`);

    const browserUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
    const isYouTube = platform.platform === 'youtube';

    const args: string[] = [
      '--newline',
      '--progress',
      '--no-playlist',
      '--no-check-certificates',
      '--geo-bypass',
      '--concurrent-fragments', '4',
      '--socket-timeout', '15',
      '--retries', '2',
      '--fragment-retries', '2',
      '--user-agent', browserUserAgent,
      '--js-runtimes', 'node',
    ];

    if (cookieFile) {
      args.push('--cookies', cookieFile);
    }

    if (isYouTube && !hasYoutubeCookies()) {
      args.push('--extractor-args', 'youtube:player-client=android,web');
    }

    if (isAudio) {
      args.push('-x', '--audio-format', audioFormat, '-f', 'ba[ext=m4a]/ba/bestaudio/b');
    } else if (isYouTube) {
      switch (qualityId) {
        case 'best_1080':
          args.push('-f', 'bv*[height<=1080][ext=mp4]+ba[ext=m4a]/bv*[height<=1080]+ba/b[height<=1080]/22/18/best[ext=mp4]/best', '--merge-output-format', videoContainer);
          break;
        case 'best_720':
          args.push('-f', '22/bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[height<=720]/18/best[ext=mp4]/best', '--merge-output-format', videoContainer);
          break;
        case 'best_480':
          args.push('-f', 'bv*[height<=480][ext=mp4]+ba[ext=m4a]/b[height<=480]/18/best[ext=mp4]/best', '--merge-output-format', videoContainer);
          break;
        case 'best_360':
          args.push('-f', '18/b[height<=360][ext=mp4]/bv*[height<=360]+ba/best[ext=mp4]/best', '--merge-output-format', videoContainer);
          break;
        case 'best_240':
          args.push('-f', '18/b[height<=240][ext=mp4]/bv*[height<=240]+ba/best[ext=mp4]/best', '--merge-output-format', videoContainer);
          break;
        default:
          args.push('-f', '18/22/best[ext=mp4]/best', '--merge-output-format', videoContainer);
          break;
      }
    } else {
      // Non-YouTube platforms (TikTok, Twitter, Pinterest, Facebook, etc.)
      switch (qualityId) {
        case 'best_1080':
          args.push('-f', 'bestvideo[height<=1080]+bestaudio/best[height<=1080]/best', '--merge-output-format', videoContainer);
          break;
        case 'best_720':
          args.push('-f', 'bestvideo[height<=720]+bestaudio/best[height<=720]/best', '--merge-output-format', videoContainer);
          break;
        case 'best_480':
          args.push('-f', 'bestvideo[height<=480]+bestaudio/best[height<=480]/best', '--merge-output-format', videoContainer);
          break;
        case 'best_360':
        case 'best_240':
          args.push('-f', 'bestvideo[height<=360]+bestaudio/best[height<=360]/best', '--merge-output-format', videoContainer);
          break;
        default:
          args.push('-f', 'bestvideo+bestaudio/best', '--merge-output-format', videoContainer);
          break;
      }
    }

    args.push('-o', outputTemplate, cleanUrl);

    await ensureYtDlpExecutable();

    const dlTimeoutMs = Math.max(15, cfg.download.maxDownloadTimeSec || 180) * 1000;
    const dlMeta = { downloadId: fileId.slice(0, 8), userId, platform: platform.platform, url: cleanUrl };

    try {
      await runYtDlpDownload(args, onProgress, dlTimeoutMs, dlMeta);
    } catch (err: any) {
      const errMsg = String(err?.message || '');
      if (errMsg.includes('لغو شد')) throw err;
      const isIgCookieErr = platform.platform === 'instagram' && Boolean(cookieFile) && isInstagramCookieRejectionError(errMsg);
      if (isIgCookieErr) {
        console.log('[Instagram] Stored cookie session was rejected during media download; clearing stale cookie and retrying without cookies.');
        invalidateBadInstagramCookies();
      } else {
        console.log(`[downloadMedia] Attempt ${qualityId} did not succeed, retrying with fallback options...`);
      }
      await ensureYtDlpExecutable();

      const buildFallbackArgs = (includeCookie: boolean): string[] => {
        const fb: string[] = [
          '--newline',
          '--progress',
          '--no-playlist',
          '--no-check-certificates',
          '--geo-bypass',
          '--concurrent-fragments', '4',
          '--socket-timeout', '15',
          '--retries', '2',
          '--extractor-retries', '2',
          '--user-agent', browserUserAgent,
          '--js-runtimes', 'node',
        ];
        if (includeCookie && cookieFile) {
          fb.push('--cookies', cookieFile);
        }
        if (isYouTube && (!includeCookie || !hasYoutubeCookies())) {
          fb.push('--extractor-args', 'youtube:player-client=android,web');
        }
        if (isAudio) {
          fb.push('-x', '--audio-format', audioFormat, '-f', 'ba/bestaudio/b');
        } else if (isYouTube) {
          fb.push('-f', '18/22/best[ext=mp4]/best', '--merge-output-format', videoContainer);
        } else {
          fb.push('-f', 'bv*+ba/b/best', '--merge-output-format', videoContainer);
        }
        fb.push('-o', outputTemplate, cleanUrl);
        return fb;
      };

      const shouldTryWithCookiesFirst = Boolean(cookieFile) && !isIgCookieErr;
      try {
        await runYtDlpDownload(buildFallbackArgs(shouldTryWithCookiesFirst), onProgress, dlTimeoutMs, dlMeta);
      } catch (fbErr: any) {
        if (String(fbErr?.message || '').includes('لغو شد')) throw fbErr;
        if (shouldTryWithCookiesFirst) {
          console.log(`[downloadMedia] Cookie fallback failed for ${platform.platformNameEn}; retrying without cookies.`);
          if (platform.platform === 'instagram' && isInstagramCookieRejectionError(String(fbErr?.message || ''))) {
            invalidateBadInstagramCookies();
          }
          await runYtDlpDownload(buildFallbackArgs(false), onProgress, dlTimeoutMs, dlMeta);
        } else {
          throw fbErr;
        }
      }
    }

    const matchingFiles = fs.readdirSync(downloadDir).filter(f => f.startsWith(fileId));
    if (matchingFiles.length === 0) {
      throw new Error('فایل دانلود شده یافت نشد.');
    }

    let actualFileName = matchingFiles[0];
    let finalFilePath = path.join(downloadDir, actualFileName);
    let actualExt = path.extname(actualFileName).replace('.', '') || ext;

    // If video format is webm or mkv (when mp4 configured), convert to MP4 so Telegram can play it inline
    if (!isAudio && videoContainer === 'mp4' && (actualExt === 'webm' || actualExt === 'mkv')) {
      onProgress?.({ percent: 98, stage: 'processing' });
      const mp4Path = path.join(downloadDir, `${fileId}.mp4`);
      try {
        await execFileAsync(
          'ffmpeg',
          ['-y', '-i', finalFilePath, '-c:v', 'copy', '-c:a', 'aac', '-movflags', '+faststart', mp4Path],
          { timeout: 45000 }
        );
        if (fs.existsSync(mp4Path) && fs.statSync(mp4Path).size > 0) {
          try { fs.unlinkSync(finalFilePath); } catch {}
          finalFilePath = mp4Path;
          actualFileName = path.basename(mp4Path);
          actualExt = 'mp4';
        }
      } catch (remuxErr) {
        console.warn('[downloadMedia] Remux copy failed, trying full transcode to MP4:', remuxErr);
        try {
          await execFileAsync(
            'ffmpeg',
            ['-y', '-i', finalFilePath, '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '26', '-c:a', 'aac', '-movflags', '+faststart', mp4Path],
            { timeout: 90000 }
          );
          if (fs.existsSync(mp4Path) && fs.statSync(mp4Path).size > 0) {
            try { fs.unlinkSync(finalFilePath); } catch {}
            finalFilePath = mp4Path;
            actualFileName = path.basename(mp4Path);
            actualExt = 'mp4';
          }
        } catch (transErr) {
          console.warn('[downloadMedia] Transcode fallback failed:', transErr);
        }
      }
    }

    onProgress?.({ percent: 100, stage: 'uploading' });

    const stats = fs.statSync(finalFilePath);
    const maxAllowedBytes = Math.max(5, cfg.download.maxFileSizeMb || 50) * 1024 * 1024;
    if (stats.size > maxAllowedBytes) {
      try { fs.unlinkSync(finalFilePath); } catch {}
      throw new Error(`حجم فایل (${formatFileSize(stats.size)}) بیشتر از سقف مجاز تنظیم‌شده (${cfg.download.maxFileSizeMb} MB) است.`);
    }
    const mimeType = isAudio || actualExt === 'mp3' || actualExt === 'm4a' ? 'audio/mpeg' : 'video/mp4';

    let songInfo: IdentifiedSong | undefined = undefined;
    if (qualityId === 'find_song' || platform.platform === 'soundcloud') {
      try {
        songInfo = await identifySongFromMedia(cleanUrl);
      } catch {}
    }

    const dlResult: DownloadResult = {
      id: fileId,
      filePath: finalFilePath,
      fileName: actualFileName,
      fileSizeBytes: stats.size,
      fileSizeFormatted: formatFileSize(stats.size),
      mimeType,
      title: 'Downloaded Media',
      duration: 0,
      ext: actualExt,
      songInfo,
    };

    downloadedFileCache.set(cacheKey, { result: dlResult, exp: Date.now() + 15 * 60 * 1000 });
    if (downloadedFileCache.size > 200) {
      const now = Date.now();
      for (const [k, v] of downloadedFileCache) {
        if (v.exp < now) downloadedFileCache.delete(k);
      }
    }

    return dlResult;
  });

  inFlightDownloads.set(cacheKey, runDownload);
  try {
    return await runDownload;
  } finally {
    inFlightDownloads.delete(cacheKey);
  }
}

export interface InstagramMediaItem {
  filePath: string;
  fileName: string;
  type: 'video' | 'photo';
  sizeBytes: number;
  sizeFormatted: string;
}

export interface InstagramPostResult {
  id: string;
  caption: string;
  uploader: string;
  title: string;
  items: InstagramMediaItem[];
}

async function downloadInstagramViaPublicEmbed(
  cleanUrl: string,
  downloadDir: string,
  fileId: string,
  maxAllowedBytes: number,
  userAgent: string,
  onProgress?: (progress: DownloadProgress) => void
): Promise<{ caption: string; uploader: string; title: string } | null> {
  const shortcode = extractInstagramShortcode(cleanUrl);
  if (!shortcode) return null;

  const candidatePages = [
    `https://www.instagram.com/p/${shortcode}/embed/captioned/`,
    `https://www.instagram.com/reel/${shortcode}/embed/`,
  ];

  for (const pageUrl of candidatePages) {
    try {
      const safePageUrl = validateSafeHttpUrl(pageUrl);
      const res = await fetch(safePageUrl, {
        headers: {
          'User-Agent': userAgent,
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
        },
        signal: AbortSignal.timeout(12_000),
      });
      if (!res.ok) continue;
      const html = await res.text();
      const parsed = parseInstagramEmbedHtml(html);
      if (parsed.mediaUrls.length === 0) continue;

      let downloadedCount = 0;
      for (let i = 0; i < Math.min(parsed.mediaUrls.length, 10); i++) {
        const item = parsed.mediaUrls[i];
        let safeMediaUrl: string;
        try {
          safeMediaUrl = validateSafeHttpUrl(item.url);
        } catch {
          continue;
        }
        const mediaRes = await fetch(safeMediaUrl, {
          headers: { 'User-Agent': userAgent, 'Referer': 'https://www.instagram.com/' },
          signal: AbortSignal.timeout(25_000),
        });
        if (!mediaRes.ok) continue;

        const contentLen = Number(mediaRes.headers.get('content-length') || '0');
        if (contentLen > maxAllowedBytes) {
          throw new Error(`حجم فایل (${formatFileSize(contentLen)}) بیشتر از سقف مجاز تنظیم‌شده است.`);
        }

        const buf = Buffer.from(await mediaRes.arrayBuffer());
        if (buf.length === 0) continue;
        if (buf.length > maxAllowedBytes) {
          throw new Error(`حجم فایل (${formatFileSize(buf.length)}) بیشتر از سقف مجاز تنظیم‌شده است.`);
        }

        const ext = item.type === 'video' ? 'mp4' : 'jpg';
        const indexStr = String(downloadedCount + 1).padStart(2, '0');
        const outPath = path.join(downloadDir, `${fileId}_${indexStr}.${ext}`);
        fs.writeFileSync(outPath, buf);
        downloadedCount++;
        onProgress?.({ percent: Math.min(95, 40 + Math.round(((i + 1) / parsed.mediaUrls.length) * 55)), stage: 'downloading' });
      }

      if (downloadedCount > 0) {
        return {
          caption: parsed.caption,
          uploader: parsed.uploader || 'اینستاگرام',
          title: parsed.caption ? parsed.caption.slice(0, 80) : 'Instagram Post',
        };
      }
    } catch (err: any) {
      if (String(err?.message || '').includes('بیشتر از سقف مجاز')) throw err;
    }
  }
  return null;
}

/**
 * Single-pass Instagram Post / Reel / Carousel downloader (metadata + media in ONE yt-dlp run)
 */
export async function downloadInstagramPost(
  url: string,
  onProgress?: (progress: DownloadProgress) => void,
  userId?: number | string
): Promise<InstagramPostResult> {
  const cfg = loadBotConfig();
  if (!cfg.general.downloadsServiceEnabled || !cfg.download.enabled) {
    throw new Error('سرویس دانلود موقتاً توسط مدیر ربات غیرفعال شده است.');
  }
  const downloadDir = getActiveDownloadDir();
  const maxAllowedBytes = Math.max(5, cfg.download.maxFileSizeMb || 50) * 1024 * 1024;

  return downloadSemaphore.run(async () => {
    ensureSufficientDiskSpace(250);
    const safeInputUrl = validateSafeHttpUrl(url);
    const platform = identifyPlatform(safeInputUrl);
    const cleanUrl = validateSafeHttpUrl(platform.cleanUrl);
    const igCookiePath = getActiveInstagramCookiesPath();
    await ensureYtDlpExecutable();

    const fileId = crypto.randomUUID();
    const outputTemplate = path.join(downloadDir, `${fileId}_%(autonumber)02d.%(ext)s`);
    const videoContainer = cfg.download.outputFormat === 'mkv' ? 'mkv' : 'mp4';

    const browserUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
    const baseArgs: string[] = [
      '--newline',
      '--progress',
      '--yes-playlist',
      '--write-info-json',
      '--no-check-certificates',
      '--geo-bypass',
      '--concurrent-fragments', '4',
      '--socket-timeout', '15',
      '--retries', '2',
      '--extractor-retries', '2',
      '--js-runtimes', 'node',
      '--user-agent', browserUserAgent,
      '-f', 'bv*+ba/b/best',
      '--merge-output-format', videoContainer,
      '-o', outputTemplate,
    ];

    const downloadArgs = igCookiePath
      ? [...baseArgs, '--cookies', igCookiePath, cleanUrl]
      : [...baseArgs, cleanUrl];

    const dlTimeoutMs = Math.max(15, cfg.download.maxDownloadTimeSec || 180) * 1000;
    const dlMeta = { downloadId: fileId.slice(0, 8), userId, platform: 'instagram', url: cleanUrl };

    let embedFallbackMeta: { caption: string; uploader: string; title: string } | null = null;
    let lastError: any = null;

    try {
      await runYtDlpDownload(downloadArgs, onProgress, dlTimeoutMs, dlMeta);
    } catch (err: any) {
      lastError = err;
      const errMsg = String(err?.message || '');
      if (errMsg.includes('لغو شد')) throw err;

      if (igCookiePath) {
        if (isInstagramCookieRejectionError(errMsg)) {
          console.log('[Instagram] Stored cookie session was rejected by Instagram; cleared stale cookie and retrying without cookies.');
          invalidateBadInstagramCookies();
        } else {
          console.log('[Instagram] Cookie-based download attempt failed; retrying without cookies...');
        }

        const fallbackArgs = [...baseArgs, cleanUrl];
        try {
          await runYtDlpDownload(fallbackArgs, onProgress, dlTimeoutMs, dlMeta);
          lastError = null;
        } catch (fbErr: any) {
          lastError = fbErr;
          if (String(fbErr?.message || '').includes('لغو شد')) throw fbErr;
        }
      }

      // Tier 3: Alternate URL form (/p/ <-> /reel/) or public embed fallback if yt-dlp still failed
      if (lastError) {
        const shortcode = extractInstagramShortcode(cleanUrl);
        const altUrl = shortcode
          ? (cleanUrl.includes('/reel/')
            ? `https://www.instagram.com/p/${shortcode}/`
            : `https://www.instagram.com/reel/${shortcode}/`)
          : null;

        if (altUrl && altUrl !== cleanUrl) {
          console.log(`[Instagram] Retrying via alternate URL format (${altUrl})...`);
          try {
            await runYtDlpDownload([...baseArgs, altUrl], onProgress, dlTimeoutMs, dlMeta);
            lastError = null;
          } catch (altErr: any) {
            lastError = altErr;
            if (String(altErr?.message || '').includes('لغو شد')) throw altErr;
          }
        }

        if (lastError) {
          console.log('[Instagram] yt-dlp download did not succeed; attempting public embed fallback...');
          embedFallbackMeta = await downloadInstagramViaPublicEmbed(
            cleanUrl,
            downloadDir,
            fileId,
            maxAllowedBytes,
            browserUserAgent,
            onProgress
          );
          if (embedFallbackMeta) {
            lastError = null;
          }
        }
      }
    }

    const allSessionFiles = fs.readdirSync(downloadDir).filter(f => f.startsWith(fileId)).sort();
    const infoJsonFiles = allSessionFiles.filter(f => f.endsWith('.info.json'));
    const matchingFiles = allSessionFiles.filter(f => !f.endsWith('.info.json') && !f.endsWith('.part') && !f.endsWith('.ytdl'));

    let caption = embedFallbackMeta?.caption || '';
    let uploader = embedFallbackMeta?.uploader || 'اینستاگرام';
    let title = embedFallbackMeta?.title || 'Instagram Post';

    if (infoJsonFiles.length > 0) {
      try {
        const rawJson = fs.readFileSync(path.join(downloadDir, infoJsonFiles[0]), 'utf-8');
        const info = JSON.parse(rawJson);
        caption = info.description || info.title || caption;
        uploader = info.uploader || info.channel || uploader;
        title = info.title || title;
      } catch {}
      for (const jf of infoJsonFiles) {
        try { fs.unlinkSync(path.join(downloadDir, jf)); } catch {}
      }
    }

    if (matchingFiles.length === 0) {
      if (lastError) {
        const rawErr = String(lastError?.message || '');
        if (rawErr.includes('not available to everyone') || rawErr.includes('certain audiences') || rawErr.includes('login page') || rawErr.includes('login_required')) {
          throw lastError;
        }
        const shortSummary = rawErr.replace(/\bERROR:\s*/gi, '').split('\n')[0].slice(0, 180);
        throw new Error(`دانلود پست اینستاگرام انجام نشد (${shortSummary || 'خطای نامشخص'}).`);
      }
      throw new Error('فایلی برای این پست اینستاگرام یافت نشد.');
    }

    const items: InstagramMediaItem[] = [];
    for (const file of matchingFiles) {
      const fullPath = path.join(downloadDir, file);
      const stats = fs.statSync(fullPath);
      if (stats.size <= 0) {
        try { fs.unlinkSync(fullPath); } catch {}
        continue;
      }
      if (stats.size > maxAllowedBytes) {
        for (const f of matchingFiles) {
          try { fs.unlinkSync(path.join(downloadDir, f)); } catch {}
        }
        throw new Error(`حجم فایل (${formatFileSize(stats.size)}) بیشتر از سقف مجاز تنظیم‌شده (${cfg.download.maxFileSizeMb} MB) است.`);
      }
      const ext = path.extname(file).toLowerCase();
      const isVideo = ext === '.mp4' || ext === '.mov' || ext === '.mkv' || ext === '.webm';
      items.push({
        filePath: fullPath,
        fileName: file,
        type: isVideo ? 'video' : 'photo',
        sizeBytes: stats.size,
        sizeFormatted: formatFileSize(stats.size),
      });
    }

    if (items.length === 0) {
      throw new Error('فایل معتبری برای این پست اینستاگرام دریافت نشد.');
    }

    return {
      id: fileId,
      caption,
      uploader,
      title,
      items,
    };
  });
}

/**
 * Get direct streaming URL without local disk download
 */
export async function getDirectStreamUrl(url: string, qualityId: string = 'best_720'): Promise<string | null> {
  try {
    const safeInputUrl = validateSafeHttpUrl(url);
    const platform = identifyPlatform(safeInputUrl);
    const cleanUrl = validateSafeHttpUrl(platform.cleanUrl);
    const cookieFile = getActiveCookieFileForUrl(cleanUrl);

    let formatArg = 'b';
    if (qualityId === 'best_audio' || qualityId === 'find_song') {
      formatArg = 'bestaudio';
    } else if (qualityId === 'best_720') {
      formatArg = 'best[height<=720]/b';
    } else if (qualityId === 'best_1080') {
      formatArg = 'best[height<=1080]/b';
    }

    const args = ['-g', '-f', formatArg, '--js-runtimes', 'node', '--socket-timeout', '10'];
    if (cookieFile) {
      args.push('--cookies', cookieFile);
    }
    args.push(cleanUrl);

    const { stdout } = await execFileAsync(getYtDlpBinaryPath(), args, { timeout: 20000 });
    const directUrl = stdout.trim().split('\n')[0];
    return directUrl || null;
  } catch {
    return null;
  }
}

/**
 * Extracts audio from an Instagram video or URL as a high-quality 320kbps MP3
 */
export async function extractInstagramAudio(
  urlOrFilePath: string,
  onProgress?: (progress: DownloadProgress) => void,
  userId?: number | string
): Promise<DownloadResult> {
  const downloadDir = getActiveDownloadDir();
  const resolvedInput = path.resolve(urlOrFilePath);
  if (resolvedInput.startsWith(downloadDir) && fs.existsSync(resolvedInput) && fs.statSync(resolvedInput).size > 0) {
    return downloadSemaphore.run(async () => {
      ensureSufficientDiskSpace(150);
      const fileId = crypto.randomUUID();
      const mp3Path = path.join(downloadDir, `${fileId}.mp3`);
      onProgress?.({ percent: 35, stage: 'processing' });
      try {
        await execFileAsync(
          'ffmpeg',
          ['-y', '-i', resolvedInput, '-vn', '-c:a', 'libmp3lame', '-b:a', '320k', mp3Path],
          { timeout: 45000 }
        );
        if (fs.existsSync(mp3Path) && fs.statSync(mp3Path).size > 0) {
          onProgress?.({ percent: 100, stage: 'uploading' });
          const stats = fs.statSync(mp3Path);
          return {
            id: fileId,
            filePath: mp3Path,
            fileName: `${fileId}.mp3`,
            fileSizeBytes: stats.size,
            fileSizeFormatted: formatFileSize(stats.size),
            mimeType: 'audio/mpeg',
            title: 'Instagram Audio',
            duration: 0,
            ext: 'mp3',
          };
        }
      } catch (ffmpegErr) {
        console.warn('[extractInstagramAudio] Local transcode failed, fallback to url download:', ffmpegErr);
      }
      return await downloadMedia(urlOrFilePath, 'best_audio', onProgress, userId);
    });
  }

  // Case 2: urlOrFilePath is an Instagram URL (already acquires downloadSemaphore inside downloadMedia)
  return await downloadMedia(urlOrFilePath, 'best_audio', onProgress, userId);
}

