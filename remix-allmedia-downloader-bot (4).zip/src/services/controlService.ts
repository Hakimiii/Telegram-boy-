import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  getDb,
  recordAuditLog,
  shouldSendAlert,
  createDatabaseBackup,
  vacuumDatabase,
  getLastBackupSummary,
  countUnauthorizedAttempts,
} from './database.ts';
import {
  SUPER_ADMIN_ID,
  loadBotConfig,
  updateGeneralSettings,
  updateDownloadSettings,
  getAdminRecord,
} from './configManager.ts';
import {
  getActiveDownloadDir,
  getDownloadQueueStats,
  listActiveDownloads,
  cleanOldDownloads,
  clearMediaCaches,
} from './mediaDownloader.ts';
import { checkAwsSecretsConnectivity } from './secretsManager.ts';

export interface BotControlBridge {
  sendMessage: (chatId: number | string, text: string) => Promise<void>;
  getBotRuntimeSummary: () => {
    isActive: boolean;
    isWebhookMode: boolean;
    botUsername?: string;
    totalRequests: number;
    totalDownloads: number;
    lastError: string | null;
    inFlightMessages: number;
  };
  restartBotConnection: () => Promise<{ success: boolean; message: string }>;
  flushStateSync: () => void;
  getHttpApiRunning: () => boolean;
}

const PROCESS_STARTED_AT = new Date().toISOString();
let botBridge: BotControlBridge | null = null;
let healthMonitorInterval: NodeJS.Timeout | null = null;
let httpApiRunningFlag = false;

export function setHttpApiRunning(running: boolean): void {
  httpApiRunningFlag = running;
}

export function isHttpApiRunningFlag(): boolean {
  return httpApiRunningFlag;
}

export function registerBotControlBridge(bridge: BotControlBridge): void {
  botBridge = bridge;
}

export function getBotControlBridge(): BotControlBridge | null {
  return botBridge;
}

export interface ServerMetricsSnapshot {
  botActive: boolean;
  botMode: string;
  botUsername: string;
  backendApiActive: boolean;
  downloaderEnabled: boolean;
  spotifyEnabled: boolean;
  activeDownloadsCount: number;
  queuedDownloadsCount: number;
  maxConcurrentDownloads: number;
  inFlightRequests: number;
  ramRssMb: number;
  ramHeapMb: number;
  osTotalMemMb: number;
  osFreeMemMb: number;
  osMemUsedPercent: number;
  cpuCores: number;
  cpuLoad1m: number;
  diskFreeMb: number | null;
  diskTotalMb: number | null;
  tempDirFilesCount: number;
  tempDirSizeMb: number;
  uptimeSeconds: number;
  lastRestartAt: string;
  lastBotError: string | null;
  recentErrorsCount: number;
  unauthorizedAttempts1h: number;
  lastBackupAt: string | null;
  lastBackupStatus: string;
}

export function getServerMetrics(): ServerMetricsSnapshot {
  const config = loadBotConfig();
  const mem = process.memoryUsage();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMemPct = totalMem > 0 ? Math.round(((totalMem - freeMem) / totalMem) * 100) : 0;
  const load1 = os.loadavg()[0] || 0;
  const botRuntime = botBridge?.getBotRuntimeSummary();
  const qStats = getDownloadQueueStats();
  const activeDownloads = listActiveDownloads();

  const downloadDir = getActiveDownloadDir();
  let diskFreeMb: number | null = null;
  let diskTotalMb: number | null = null;
  try {
    if (typeof fs.statfsSync === 'function' && fs.existsSync(downloadDir)) {
      const fsStats = fs.statfsSync(downloadDir);
      diskFreeMb = Math.round((Number(fsStats.bavail) * Number(fsStats.bsize)) / (1024 * 1024));
      diskTotalMb = Math.round((Number(fsStats.blocks) * Number(fsStats.bsize)) / (1024 * 1024));
    }
  } catch {}

  let tempFiles = 0;
  let tempBytes = 0;
  try {
    if (fs.existsSync(downloadDir)) {
      const files = fs.readdirSync(downloadDir);
      for (const f of files) {
        try {
          const st = fs.statSync(path.join(downloadDir, f));
          if (st.isFile()) {
            tempFiles++;
            tempBytes += st.size;
          }
        } catch {}
      }
    }
  } catch {}

  let recentErrorsCount = 0;
  try {
    const db = getDb();
    const since = new Date(Date.now() - 24 * 3600_000).toISOString();
    const row = db
      .prepare("SELECT COUNT(*) as cnt FROM user_requests WHERE status = 'error' AND created_at >= ?")
      .get(since) as { cnt: number } | undefined;
    recentErrorsCount = Number(row?.cnt || 0);
  } catch {}

  const backupSummary = getLastBackupSummary();

  return {
    botActive: Boolean(botRuntime?.isActive),
    botMode: botRuntime?.isWebhookMode ? 'Webhook' : 'Long Polling',
    botUsername: botRuntime?.botUsername || 'N/A',
    backendApiActive: botBridge ? botBridge.getHttpApiRunning() : process.env.DISABLE_HTTP_API !== 'true',
    downloaderEnabled: config.general.downloadsServiceEnabled && config.download.enabled,
    spotifyEnabled: config.spotify.enabled,
    activeDownloadsCount: activeDownloads.length,
    queuedDownloadsCount: qStats.pending,
    maxConcurrentDownloads: qStats.maxConcurrent,
    inFlightRequests: botRuntime?.inFlightMessages || 0,
    ramRssMb: Number((mem.rss / 1024 / 1024).toFixed(1)),
    ramHeapMb: Number((mem.heapUsed / 1024 / 1024).toFixed(1)),
    osTotalMemMb: Math.round(totalMem / 1024 / 1024),
    osFreeMemMb: Math.round(freeMem / 1024 / 1024),
    osMemUsedPercent: usedMemPct,
    cpuCores: os.cpus().length || 1,
    cpuLoad1m: Number(load1.toFixed(2)),
    diskFreeMb,
    diskTotalMb,
    tempDirFilesCount: tempFiles,
    tempDirSizeMb: Number((tempBytes / 1024 / 1024).toFixed(1)),
    uptimeSeconds: Math.floor(process.uptime()),
    lastRestartAt: PROCESS_STARTED_AT,
    lastBotError: botRuntime?.lastError || null,
    recentErrorsCount,
    unauthorizedAttempts1h: countUnauthorizedAttempts(60),
    lastBackupAt: backupSummary.lastBackupAt,
    lastBackupStatus: backupSummary.status,
  };
}

export async function checkServicesConnectivity(): Promise<{
  internetOk: boolean;
  telegramOk: boolean;
  telegramLatencyMs: number | null;
  spotifyOk: boolean;
  spotifyLatencyMs: number | null;
  awsStatus: string;
}> {
  let telegramOk = false;
  let telegramLatencyMs: number | null = null;
  try {
    const t0 = Date.now();
    const res = await fetch('https://api.telegram.org/', { method: 'HEAD', signal: AbortSignal.timeout(5000) });
    telegramLatencyMs = Date.now() - t0;
    telegramOk = res.status > 0;
  } catch {}

  let spotifyOk = false;
  let spotifyLatencyMs: number | null = null;
  try {
    const t0 = Date.now();
    const res = await fetch('https://open.spotify.com/oembed?url=https://open.spotify.com/track/4uLU6hMCjMI75M1A2tKUQC', {
      method: 'GET',
      signal: AbortSignal.timeout(5000),
    });
    spotifyLatencyMs = Date.now() - t0;
    spotifyOk = res.ok;
  } catch {}

  const aws = await checkAwsSecretsConnectivity();

  return {
    internetOk: telegramOk || spotifyOk,
    telegramOk,
    telegramLatencyMs,
    spotifyOk,
    spotifyLatencyMs,
    awsStatus: aws.details,
  };
}

export type ControlledAction =
  | 'restart_bot'
  | 'restart_backend_process'
  | 'pause_downloads'
  | 'resume_downloads'
  | 'clean_temp_files'
  | 'vacuum_db'
  | 'run_backup';

export async function executeControlledAction(
  actorId: number,
  action: ControlledAction
): Promise<{ success: boolean; message: string }> {
  const actor = getAdminRecord(actorId);
  if (!actor || actor.isBlocked) {
    recordAuditLog({
      actorId,
      action: `control:${action}`,
      section: 'server',
      result: 'denied',
    });
    return { success: false, message: 'دسترسی غیرمجاز.' };
  }

  switch (action) {
    case 'restart_bot': {
      if (!actor.permissions.includes('server') && actor.role !== 'owner') {
        return { success: false, message: 'مجوز کنترل سرور برای شما فعال نیست.' };
      }
      if (!botBridge) {
        return { success: false, message: 'سرویس اتصال ربات هنوز مقداردهی نشده است.' };
      }
      const res = await botBridge.restartBotConnection();
      recordAuditLog({
        actorId,
        actorRole: actor.role,
        action: 'restart_bot',
        section: 'server',
        newValue: res.success ? 'restarted' : res.message,
        result: res.success ? 'success' : 'failed',
      });
      return res;
    }

    case 'restart_backend_process': {
      if (actor.role !== 'owner') {
        return { success: false, message: 'ری‌استارت کامل پردازش سرور فقط توسط مالک اصلی مجاز است.' };
      }
      recordAuditLog({
        actorId,
        actorRole: actor.role,
        action: 'restart_backend_process',
        section: 'server',
        newValue: 'graceful_exit_for_pm2_restart',
        result: 'success',
      });
      await createDatabaseBackup(actorId, 'pre-controlled-restart');
      botBridge?.flushStateSync();
      setTimeout(() => {
        process.exit(0);
      }, 1200);
      return {
        success: true,
        message: 'فرآیند ری‌استارت کنترل‌شده آغاز شد. PM2/Docker تا چند ثانیه دیگر ربات را مجدداً بالا می‌آورد.',
      };
    }

    case 'pause_downloads': {
      if (!actor.permissions.includes('server') && !actor.permissions.includes('download') && actor.role !== 'owner') {
        return { success: false, message: 'عدم دسترسی به کنترل دانلود.' };
      }
      updateGeneralSettings({ downloadsServiceEnabled: false }, actorId);
      updateDownloadSettings({ enabled: false }, actorId);
      recordAuditLog({
        actorId,
        actorRole: actor.role,
        action: 'pause_downloads',
        section: 'server',
        oldValue: 'enabled',
        newValue: 'paused',
        result: 'success',
      });
      return { success: true, message: '⏸ سرویس دانلود موقتاً متوقف شد.' };
    }

    case 'resume_downloads': {
      if (!actor.permissions.includes('server') && !actor.permissions.includes('download') && actor.role !== 'owner') {
        return { success: false, message: 'عدم دسترسی به کنترل دانلود.' };
      }
      updateGeneralSettings({ downloadsServiceEnabled: true }, actorId);
      updateDownloadSettings({ enabled: true }, actorId);
      recordAuditLog({
        actorId,
        actorRole: actor.role,
        action: 'resume_downloads',
        section: 'server',
        oldValue: 'paused',
        newValue: 'enabled',
        result: 'success',
      });
      return { success: true, message: '▶️ سرویس دانلود مجدداً فعال شد.' };
    }

    case 'clean_temp_files': {
      if (!actor.permissions.includes('maintenance') && !actor.permissions.includes('download') && actor.role !== 'owner') {
        return { success: false, message: 'عدم دسترسی به پاکسازی فایل‌های موقت.' };
      }
      const { deletedCount, freedBytes } = cleanOldDownloads(true);
      clearMediaCaches();
      const freedMb = (freedBytes / 1024 / 1024).toFixed(1);
      recordAuditLog({
        actorId,
        actorRole: actor.role,
        action: 'clean_temp_files',
        section: 'maintenance',
        newValue: `deleted=${deletedCount},freedMb=${freedMb}`,
        result: 'success',
      });
      return {
        success: true,
        message: `🧹 پاکسازی کامل انجام شد: ${deletedCount} فایل موقت حذف و ${freedMb} مگابایت فضا آزاد شد.`,
      };
    }

    case 'vacuum_db': {
      if (!actor.permissions.includes('maintenance') && !actor.permissions.includes('backup') && actor.role !== 'owner') {
        return { success: false, message: 'عدم دسترسی به بهینه‌سازی دیتابیس.' };
      }
      const res = vacuumDatabase();
      recordAuditLog({
        actorId,
        actorRole: actor.role,
        action: 'vacuum_db',
        section: 'maintenance',
        newValue: `sizeBytes=${res.sizeBytes}`,
        result: 'success',
      });
      return {
        success: true,
        message: `🗜 بهینه‌سازی و فشرده‌سازی دیتابیس SQLite انجام شد (حجم فعلی: ${(res.sizeBytes / 1024).toFixed(1)} KB).`,
      };
    }

    case 'run_backup': {
      if (!actor.permissions.includes('backup') && actor.role !== 'owner') {
        return { success: false, message: 'عدم دسترسی به پشتیبان‌گیری.' };
      }
      const res = await createDatabaseBackup(actorId, 'manual-admin-panel');
      if (!res.success || !res.backup) {
        await notifyOwnerAlert(
          'backup_failed',
          `⚠️ <b>هشدار شکست Backup:</b>\nعملیات تهیه نسخه پشتیبان ناموفق بود: ${res.error || 'خطای نامشخص'}`
        );
        return { success: false, message: res.error || 'خطا در تهیه نسخه پشتیبان' };
      }
      recordAuditLog({
        actorId,
        actorRole: actor.role,
        action: 'create_backup',
        section: 'backup',
        newValue: res.backup.file_name,
        result: 'success',
      });
      return {
        success: true,
        message: `💾 نسخه پشتیبان با موفقیت ایجاد و تایید سلامت شد:\n<code>${res.backup.file_name}</code> (${(res.backup.size_bytes / 1024).toFixed(1)} KB)`,
      };
    }
  }
}

/**
 * Send deduplicated critical alert to Owner (and optional notify channel)
 */
export async function notifyOwnerAlert(
  alertKey: string,
  htmlMessage: string,
  cooldownMs: number = 15 * 60_000
): Promise<boolean> {
  if (!shouldSendAlert(alertKey, cooldownMs)) {
    return false;
  }
  if (!botBridge) return false;

  let sent = false;
  try {
    await botBridge.sendMessage(SUPER_ADMIN_ID, htmlMessage);
    sent = true;
  } catch (err) {
    console.warn('[Alert] Failed to deliver alert to owner:', err);
  }

  const notifyCh = loadBotConfig().general.notifyChannelId;
  if (notifyCh && String(notifyCh) !== String(SUPER_ADMIN_ID)) {
    try {
      await botBridge.sendMessage(notifyCh, htmlMessage);
    } catch {}
  }

  return sent;
}

/**
 * Notify configured admin channel/owner when a non-secret configuration changes
 */
export async function notifyConfigChange(summaryHtml: string): Promise<void> {
  const cfg = loadBotConfig();
  if (!cfg.general.notifyOnChanges || !botBridge) return;
  const target = cfg.general.notifyChannelId || String(SUPER_ADMIN_ID);
  try {
    await botBridge.sendMessage(target, `🔔 <b>اعلان تغییر تنظیمات:</b>\n${summaryHtml}`);
  } catch {}
}

/**
 * Periodic server health & security monitor (RAM, Disk, Unauthorized attempts, Bot errors)
 */
export function startAdminHealthMonitor(): void {
  if (healthMonitorInterval) return;

  healthMonitorInterval = setInterval(async () => {
    try {
      const m = getServerMetrics();

      if (m.diskFreeMb !== null && m.diskFreeMb < 300) {
        await notifyOwnerAlert(
          'low_disk_space',
          `🚨 <b>هشدار کمبود فضای دیسک سرور!</b>\nفضای باقی‌مانده: <b>${m.diskFreeMb} مگابایت</b>.\nتوصیه: از بخش تعمیر و نگهداری، فایل‌های موقت را پاکسازی کنید.`,
          30 * 60_000
        );
      }

      if (m.ramRssMb > 420 || m.osMemUsedPercent > 92) {
        await notifyOwnerAlert(
          'high_ram_usage',
          `🚨 <b>هشدار مصرف بالای حافظه RAM!</b>\nمصرف ربات: <b>${m.ramRssMb} MB</b> | کل سیستم: <b>${m.osMemUsedPercent}%</b>`,
          20 * 60_000
        );
      }

      if (m.unauthorizedAttempts1h >= 5) {
        await notifyOwnerAlert(
          'unauthorized_attempts_burst',
          `🛡 <b>هشدار امنیتی: تلاش‌های ورود غیرمجاز متعدد</b>\nدر یک ساعت اخیر <b>${m.unauthorizedAttempts1h}</b> تلاش غیرمجاز برای دسترسی به پنل مدیریت ثبت و مسدود شده است.`,
          30 * 60_000
        );
      }
    } catch {}
  }, 5 * 60_000);

  healthMonitorInterval.unref?.();
}

export function stopAdminHealthMonitor(): void {
  if (healthMonitorInterval) {
    clearInterval(healthMonitorInterval);
    healthMonitorInterval = null;
  }
}
