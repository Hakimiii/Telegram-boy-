import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  getDb,
  closeDb,
  recordAuditLog,
  getRecentAuditLogs,
  createDatabaseBackup,
  restoreDatabaseBackup,
  redactSensitiveText,
} from './database.ts';
import {
  SUPER_ADMIN_ID,
  loadBotConfig,
  resetConfigCaches,
  upsertAdmin,
  getAdminRecord,
  setAdminBlocked,
  toggleAdminPermission,
  hasAdminPermission,
  canManageTargetAdmin,
  updateGeneralSettings,
  updateDownloadSettings,
  updateSpotifySettings,
  validateNumericSetting,
  validateStoragePath,
  upsertUserActivity,
  checkUserDailyQuota,
  incrementUserDownloadCount,
  setUserBannedStatus,
  setUserDailyLimitOverride,
} from './configManager.ts';
import {
  sendAdminDashboard,
  handleAdminCallbackQuery,
  handleAdminMessageStep,
  runSafeBroadcast,
  clearAdminPanelTransientStateForTests,
} from './adminPanel.ts';
import {
  inspectSecretsStatus,
  checkSecretSecurityWarnings,
  createSecretRotationChallenge,
  consumeSecretRotationChallenge,
} from './secretsManager.ts';
import { executeControlledAction } from './controlService.ts';

interface CapturedTelegramCall {
  method: string;
  args: any[];
}

function createFakeTelegramClient(overrides: Record<string, (...args: any[]) => any> = {}) {
  const calls: CapturedTelegramCall[] = [];
  const client: any = {
    calls,
    async sendMessage(chatId: any, text: string, extra?: any) {
      calls.push({ method: 'sendMessage', args: [chatId, text, extra] });
      return overrides.sendMessage ? overrides.sendMessage(chatId, text, extra) : { message_id: 100 + calls.length };
    },
    async editMessageText(chatId: any, msgId: number, text: string, extra?: any) {
      calls.push({ method: 'editMessageText', args: [chatId, msgId, text, extra] });
      return overrides.editMessageText ? overrides.editMessageText(chatId, msgId, text, extra) : { message_id: msgId };
    },
    async answerCallbackQuery(queryId: string, extra?: any) {
      calls.push({ method: 'answerCallbackQuery', args: [queryId, extra] });
      return true;
    },
    async deleteMessage(chatId: any, msgId: number) {
      calls.push({ method: 'deleteMessage', args: [chatId, msgId] });
      return true;
    },
    async copyMessage(toId: any, fromId: any, msgId: number) {
      calls.push({ method: 'copyMessage', args: [toId, fromId, msgId] });
      if (overrides.copyMessage) return overrides.copyMessage(toId, fromId, msgId);
      return { message_id: 500 };
    },
    async forwardMessage(toId: any, fromId: any, msgId: number) {
      calls.push({ method: 'forwardMessage', args: [toId, fromId, msgId] });
      if (overrides.forwardMessage) return overrides.forwardMessage(toId, fromId, msgId);
      return { message_id: 501 };
    },
    async getMe() {
      return { id: 999, username: 'test_bot', first_name: 'TestBot' };
    },
  };
  return client;
}

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tg-boy-admin-test-'));
const tempDbPath = path.join(tempRoot, 'bot_state.db');
const tempBackupsDir = path.join(tempRoot, 'backups');

test.beforeEach(() => {
  closeDb();
  resetConfigCaches();
  clearAdminPanelTransientStateForTests();
  try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch {}
  fs.mkdirSync(tempRoot, { recursive: true });
  process.env.BOT_DB_PATH = tempDbPath;
  process.env.BOT_BACKUPS_DIR = tempBackupsDir;
  getDb();
});

test.after(() => {
  closeDb();
  try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch {}
});

test('1. Non-admin cannot open /admin or invoke any adm:* callback and denial is logged', async () => {
  const client = createFakeTelegramClient();
  const nonAdminId = 111222333;

  const opened = await sendAdminDashboard(client, nonAdminId, undefined, nonAdminId);
  assert.equal(opened, false);
  assert.equal(client.calls.length, 0);

  const handled = await handleAdminCallbackQuery(client, {
    id: 'q1',
    from: { id: nonAdminId, username: 'attacker' },
    data: 'adm:sec:general',
    message: { chat: { id: nonAdminId }, message_id: 50, date: Math.floor(Date.now() / 1000) },
  });
  assert.equal(handled, true);
  const ans = client.calls.find((c: CapturedTelegramCall) => c.method === 'answerCallbackQuery');
  assert.ok(ans);
  assert.equal(ans.args[1].show_alert, true);

  const logs = getRecentAuditLogs(10);
  assert.ok(logs.some((l) => l.actor_id === nonAdminId && l.result === 'denied'));
});

test('2. Username spoofing is ignored; only numeric from.id matches RBAC Owner/Admins', async () => {
  const client = createFakeTelegramClient();
  const attackerId = 888777666;
  const handled = await handleAdminCallbackQuery(client, {
    id: 'q-spoof',
    from: { id: attackerId, username: 'owner_real_username' },
    data: 'adm:menu',
    message: { chat: { id: SUPER_ADMIN_ID }, message_id: 10, date: Math.floor(Date.now() / 1000) },
  });
  assert.equal(handled, true);
  const ans = client.calls.find((c: CapturedTelegramCall) => c.method === 'answerCallbackQuery');
  assert.match(ans.args[1].text, /دسترسی غیرمجاز/);
});

test('3. Stale callbacks (>24h) and cross-user confirmation nonces are rejected', async () => {
  const client = createFakeTelegramClient();
  const expiredTs = Math.floor(Date.now() / 1000) - 90_000;

  await handleAdminCallbackQuery(client, {
    id: 'q-stale',
    from: { id: SUPER_ADMIN_ID },
    data: 'adm:sec:general',
    message: { chat: { id: SUPER_ADMIN_ID }, message_id: 11, date: expiredTs },
  });
  const ans = client.calls.find((c: CapturedTelegramCall) => c.method === 'answerCallbackQuery');
  assert.match(ans.args[1].text, /منقضی/);

  // Create a real confirmation nonce as SUPER_ADMIN_ID
  upsertAdmin(SUPER_ADMIN_ID, 20001, 'super_admin');
  await handleAdminCallbackQuery(client, {
    id: 'q-ask',
    from: { id: SUPER_ADMIN_ID },
    data: 'adm:srv:pause_dl_ask',
    message: { chat: { id: SUPER_ADMIN_ID }, message_id: 12, date: Math.floor(Date.now() / 1000) },
  });
  const cfmEdit = client.calls.find((c: CapturedTelegramCall) => c.method === 'editMessageText');
  const kb = cfmEdit?.args[3]?.reply_markup?.inline_keyboard;
  const cfmCallback: string | undefined = kb?.[0]?.[0]?.callback_data;
  assert.ok(cfmCallback && cfmCallback.startsWith('adm:cfm:'));

  // Another admin tries to redeem Owner's confirmation nonce
  const client2 = createFakeTelegramClient();
  await handleAdminCallbackQuery(client2, {
    id: 'q-hijack',
    from: { id: 20001 },
    data: cfmCallback,
    message: { chat: { id: 20001 }, message_id: 13, date: Math.floor(Date.now() / 1000) },
  });
  const hijackAns = client2.calls.find((c: CapturedTelegramCall) => c.method === 'answerCallbackQuery');
  assert.match(hijackAns.args[1].text, /نامعتبر|دیگری|منقضی/);
});

test('4. RBAC hierarchy, Owner-only sections, granular permissions, and admin blocking work strictly', async () => {
  const superAdminId = 30001;
  const adminId = 30002;
  const supportId = 30003;

  assert.equal(upsertAdmin(SUPER_ADMIN_ID, superAdminId, 'super_admin').success, true);
  assert.equal(upsertAdmin(SUPER_ADMIN_ID, adminId, 'admin').success, true);
  assert.equal(upsertAdmin(SUPER_ADMIN_ID, supportId, 'support').success, true);

  // Support cannot access Owner-only secrets or admins section
  assert.equal(hasAdminPermission(supportId, 'users'), true);
  assert.equal(hasAdminPermission(supportId, 'secrets'), false);
  assert.equal(hasAdminPermission(supportId, 'admins'), false);

  const client = createFakeTelegramClient();
  await handleAdminCallbackQuery(client, {
    id: 'q-sup-secrets',
    from: { id: supportId },
    data: 'adm:sec_secrets',
    message: { chat: { id: supportId }, message_id: 21, date: Math.floor(Date.now() / 1000) },
  });
  assert.match(client.calls[0].args[1].text, /دسترسی غیرمجاز/);

  const ownerRec = getAdminRecord(SUPER_ADMIN_ID)!;
  const adminRec = getAdminRecord(adminId)!;

  // Admin cannot modify Owner or SuperAdmin
  assert.equal(canManageTargetAdmin(adminRec, SUPER_ADMIN_ID).allowed, false);
  assert.equal(canManageTargetAdmin(adminRec, superAdminId).allowed, false);
  assert.equal(canManageTargetAdmin(ownerRec, superAdminId).allowed, true);

  // Granular permission toggle works
  const permBefore = hasAdminPermission(adminId, 'spotify');
  const toggled = toggleAdminPermission(SUPER_ADMIN_ID, adminId, 'spotify');
  assert.equal(toggled.success, true);
  assert.equal(hasAdminPermission(adminId, 'spotify'), !permBefore);

  // Blocking an admin immediately revokes all access
  const blockRes = setAdminBlocked(SUPER_ADMIN_ID, adminId, true);
  assert.equal(blockRes.success, true);
  assert.equal(hasAdminPermission(adminId, 'users'), false);
  assert.equal(getAdminRecord(adminId)?.isBlocked, true);
});

test('5. Settings persist across cache resets & database reconnects (restart/update simulation)', async () => {
  updateGeneralSettings(
    {
      maintenanceMode: true,
      maintenanceMessage: 'در حال بروزرسانی هسته',
      allowNewRegistrations: false,
    },
    SUPER_ADMIN_ID
  );
  updateDownloadSettings(
    {
      maxFileSizeMb: 42,
      dailyLimitPerUser: 15,
      defaultQuality: 'best_480',
    },
    SUPER_ADMIN_ID
  );
  updateSpotifySettings(
    {
      defaultQuality: '192kbps',
      maxPlaylistTracks: 12,
      preferMp3: false,
    },
    SUPER_ADMIN_ID
  );

  // Simulate restart by closing SQLite and clearing all in-memory caches
  closeDb();
  resetConfigCaches();

  const reloaded = loadBotConfig();
  assert.equal(reloaded.general.maintenanceMode, true);
  assert.equal(reloaded.general.maintenanceMessage, 'در حال بروزرسانی هسته');
  assert.equal(reloaded.general.allowNewRegistrations, false);
  assert.equal(reloaded.download.maxFileSizeMb, 42);
  assert.equal(reloaded.download.dailyLimitPerUser, 15);
  assert.equal(reloaded.download.defaultQuality, 'best_480');
  assert.equal(reloaded.spotify.defaultQuality, '192kbps');
  assert.equal(reloaded.spotify.maxPlaylistTracks, 12);
  assert.equal(reloaded.spotify.preferMp3, false);
});

test('6. Secrets are never leaked in views, secret inspection, or audit logs, and rotation challenge requires Owner', async () => {
  const prevTok = process.env.TELEGRAM_BOT_TOKEN;
  const prevKey = process.env.ADMIN_API_KEY;
  process.env.TELEGRAM_BOT_TOKEN = '1234567890:AAF9_super_secret_token_value_12345';
  process.env.ADMIN_API_KEY = 'super-secret-admin-api-key-987654321';

  try {
    const statusList = inspectSecretsStatus();
    const warnings = checkSecretSecurityWarnings();
    const serialized = JSON.stringify({ statusList, warnings });
    assert.equal(serialized.includes('AAF9_super_secret_token_value_12345'), false);
    assert.equal(serialized.includes('super-secret-admin-api-key-987654321'), false);

    // Audit log auto-redaction
    const redacted = redactSensitiveText(
      'changed TELEGRAM_BOT_TOKEN=1234567890:AAF9_super_secret_token_value_12345 Bearer mytoken1234567890abcdef'
    );
    assert.equal(redacted.includes('AAF9_super_secret_token_value_12345'), false);
    assert.equal(redacted.includes('mytoken1234567890abcdef'), false);

    recordAuditLog({
      actorId: SUPER_ADMIN_ID,
      actorRole: 'owner',
      action: 'test_redaction',
      section: 'secrets',
      newValue: 'TELEGRAM_BOT_TOKEN=1234567890:AAF9_super_secret_token_value_12345',
      result: 'success',
    });
    const logs = getRecentAuditLogs(5);
    assert.equal(JSON.stringify(logs).includes('AAF9_super_secret_token_value_12345'), false);

    // Owner-only single-use rotation challenge
    const chRes = createSecretRotationChallenge(SUPER_ADMIN_ID, 'ADMIN_API_KEY');
    assert.equal(chRes.success, true);
    assert.ok(chRes.challenge);

    const badAttempt = consumeSecretRotationChallenge(chRes.challenge.challengeId, 999999);
    assert.equal(badAttempt.valid, false);

    const goodAttempt = consumeSecretRotationChallenge(chRes.challenge.challengeId, SUPER_ADMIN_ID);
    assert.equal(goodAttempt.valid, true);
    assert.equal(goodAttempt.secretKey, 'ADMIN_API_KEY');

    // Replay of consumed challenge must fail
    const replay = consumeSecretRotationChallenge(chRes.challenge.challengeId, SUPER_ADMIN_ID);
    assert.equal(replay.valid, false);
  } finally {
    if (prevTok === undefined) delete process.env.TELEGRAM_BOT_TOKEN;
    else process.env.TELEGRAM_BOT_TOKEN = prevTok;
    if (prevKey === undefined) delete process.env.ADMIN_API_KEY;
    else process.env.ADMIN_API_KEY = prevKey;
  }
});

test('7. Input validation rejects out-of-range numbers and path traversal storage paths', () => {
  assert.equal(validateNumericSetting('download.maxFileSizeMb', '1').valid, false);
  assert.equal(validateNumericSetting('download.maxFileSizeMb', '9999').valid, false);
  assert.equal(validateNumericSetting('download.maxFileSizeMb', 'abc').valid, false);
  assert.equal(validateNumericSetting('download.maxFileSizeMb', '45').value, 45);

  assert.equal(validateStoragePath('/etc/passwd').valid, false);
  assert.equal(validateStoragePath('../../root').valid, false);
  assert.equal(validateStoragePath('/tmp/downloads').valid, true);
});

test('8. Online backup and restore preserve SQLite state and verify integrity', async () => {
  updateGeneralSettings({ welcomeMessage: 'نسخه اصلی خوش‌آمدگویی' }, SUPER_ADMIN_ID);
  const bkRes = await createDatabaseBackup(SUPER_ADMIN_ID, 'unit-test-snapshot');
  assert.equal(bkRes.success, true);
  assert.ok(bkRes.backup);
  assert.ok(fs.existsSync(bkRes.backup.file_path));

  // Mutate setting after backup
  updateGeneralSettings({ welcomeMessage: 'تغییر اشتباه پس از بکاپ' }, SUPER_ADMIN_ID);
  resetConfigCaches();
  assert.equal(loadBotConfig().general.welcomeMessage, 'تغییر اشتباه پس از بکاپ');

  // Restore snapshot
  const restoreRes = await restoreDatabaseBackup(bkRes.backup.id, SUPER_ADMIN_ID);
  assert.equal(restoreRes.success, true);
  resetConfigCaches();
  assert.equal(loadBotConfig().general.welcomeMessage, 'نسخه اصلی خوش‌آمدگویی');
});

test('9. Controlled actions work safely for authorized admins and reject unauthorized users', async () => {
  const supportId = 40001;
  upsertAdmin(SUPER_ADMIN_ID, supportId, 'support');

  const deniedRes = await executeControlledAction(supportId, 'vacuum_db');
  assert.equal(deniedRes.success, false);

  const vacuumRes = await executeControlledAction(SUPER_ADMIN_ID, 'vacuum_db');
  assert.equal(vacuumRes.success, true);

  const pauseRes = await executeControlledAction(SUPER_ADMIN_ID, 'pause_downloads');
  assert.equal(pauseRes.success, true);
  assert.equal(loadBotConfig().download.enabled, false);

  const resumeRes = await executeControlledAction(SUPER_ADMIN_ID, 'resume_downloads');
  assert.equal(resumeRes.success, true);
  assert.equal(loadBotConfig().download.enabled, true);
});

test('10. Daily quota enforcement, per-user override, and user ban behave accurately', () => {
  const uid = 50001;
  updateDownloadSettings({ dailyLimitPerUser: 2 }, SUPER_ADMIN_ID);
  upsertUserActivity(uid, { firstName: 'Ali', username: 'ali_test' });

  assert.equal(checkUserDailyQuota(uid).allowed, true);
  incrementUserDownloadCount(uid);
  incrementUserDownloadCount(uid);
  const afterTwo = checkUserDailyQuota(uid);
  assert.equal(afterTwo.allowed, false);
  assert.equal(afterTwo.usedToday, 2);

  // Per-user override raises quota for specific user
  setUserDailyLimitOverride(uid, 5, SUPER_ADMIN_ID);
  assert.equal(checkUserDailyQuota(uid).allowed, true);

  // Ban prevents usage & persists
  assert.equal(setUserBannedStatus(uid, true, 'spam', SUPER_ADMIN_ID), true);
  assert.equal(upsertUserActivity(uid).profile?.isBanned, true);
});

test('11. Safe broadcast handles 429 retry_after, 403 blocked users, and succeeds cleanly', async () => {
  const retrySeen = new Set<number>();
  const client = createFakeTelegramClient({
    async copyMessage(toId: number) {
      if (toId === 1002 && !retrySeen.has(toId)) {
        retrySeen.add(toId);
        throw new Error('Too Many Requests: retry after 0');
      }
      if (toId === 1003) {
        throw new Error('Forbidden: bot was blocked by the user');
      }
      return { message_id: 900 };
    },
  });

  const stats = await runSafeBroadcast(client, SUPER_ADMIN_ID, 77, 'copy', [1001, 1002, 1003, 1004]);
  assert.equal(stats.total, 4);
  assert.equal(stats.successCount, 3);
  assert.equal(stats.blockedCount, 1);
  assert.equal(stats.failedCount, 1);
});

test('12. Admin step immediately deletes plaintext cookie message from Telegram chat', async () => {
  const client = createFakeTelegramClient();
  await handleAdminCallbackQuery(client, {
    id: 'q-cookie',
    from: { id: SUPER_ADMIN_ID },
    data: 'adm:ig_set',
    message: { chat: { id: SUPER_ADMIN_ID }, message_id: 90, date: Math.floor(Date.now() / 1000) },
  });

  const handled = await handleAdminMessageStep(client, {
    chat: { id: SUPER_ADMIN_ID },
    from: { id: SUPER_ADMIN_ID },
    message_id: 555,
    text: '123456%3Aabcdefg_secret_sessionid',
  });
  assert.equal(handled, true);

  const deleted = client.calls.find((c: CapturedTelegramCall) => c.method === 'deleteMessage' && c.args[1] === 555);
  assert.ok(deleted, 'Cookie message must be deleted immediately from Telegram chat');

  // Verify audit log recorded [REDACTED], never cookie text
  const logs = getRecentAuditLogs(5);
  assert.equal(JSON.stringify(logs).includes('abcdefg_secret_sessionid'), false);
});
