import crypto from 'node:crypto';
import {
  ROLE_RANK,
  isUserAdmin,
  getAdminRecord,
  hasAdminPermission,
  canManageTargetAdmin,
  upsertAdmin,
  setAdminBlocked,
  toggleAdminPermission,
  removeAdminId,
  touchAdminActivity,
  loadBotConfig,
  saveBotConfig,
  updateGeneralSettings,
  updateDownloadSettings,
  updateSpotifySettings,
  validateNumericSetting,
  validateStoragePath,
  getRegisteredUsers,
  getRegisteredUsersCount,
  getUserProfile,
  setUserBannedStatus,
  setUserDailyLimitOverride,
  resetConfigCaches,
  type AdminPermission,
  type AdminRole,
  type AdminRecord,
  type RequiredChannel,
} from './configManager.ts';
import {
  recordAuditLog,
  restoreDatabaseBackup,
  countUnauthorizedAttempts,
} from './database.ts';
import {
  executeControlledAction,
  notifyOwnerAlert,
  notifyConfigChange,
} from './controlService.ts';
import {
  createSecretRotationChallenge,
  consumeSecretRotationChallenge,
  type SecretKeyName,
} from './secretsManager.ts';
import {
  renderMainMenuView,
  renderGeneralSettingsView,
  renderDownloadSettingsView,
  renderActiveDownloadsView,
  renderDownloadErrorsView,
  renderSpotifySettingsView,
  renderUsersManagementView,
  renderActiveUsersListView,
  renderUserProfileView,
  renderAdminsManagementView,
  renderSingleAdminDetailView,
  renderAdminPermissionsView,
  renderSecuritySectionView,
  renderSecretsRotationMenu,
  renderAuditLogPageView,
  renderServerStatusView,
  renderStatsAndReportsView,
  renderBackupSectionView,
  renderMaintenanceToolsView,
  buildPingConnectivityReport,
  escHtml,
} from './adminPanelViews.ts';
import {
  type TelegramClient,
  getBotState,
  setBotWebhook,
  removeBotWebhook,
  getBotWebhookInfo,
  testChannelAccess,
} from '../bot/telegramBot.ts';
import { normalizeChannelIdentifier } from './mediaParser.ts';
import {
  hasInstagramCookies,
  saveInstagramSession,
  clearInstagramCookies,
  hasYoutubeCookies,
  saveYoutubeCookies,
  clearYoutubeCookies,
  cancelActiveDownload,
} from './mediaDownloader.ts';

interface AdminStepState {
  step: string;
  actorId: number;
  data?: any;
  createdAt: number;
}

interface PendingConfirmation {
  nonce: string;
  actorId: number;
  requiredPermission: AdminPermission;
  ownerOnly?: boolean;
  actionType: string;
  payload: any;
  summaryHtml: string;
  backCallback: string;
  expiresAt: number;
}

const adminSteps = new Map<number, AdminStepState>();
const pendingConfirmations = new Map<string, PendingConfirmation>();

const CALLBACK_MAX_AGE_SECONDS = 86_400; // Reject buttons older than 24h

export function clearAdminPanelTransientStateForTests(): void {
  adminSteps.clear();
  pendingConfirmations.clear();
}

function createConfirmation(
  actorId: number,
  requiredPermission: AdminPermission,
  actionType: string,
  payload: any,
  summaryHtml: string,
  backCallback: string,
  ownerOnly: boolean = false
): { text: string; keyboard: any[][] } {
  const now = Date.now();
  for (const [k, v] of pendingConfirmations) {
    if (v.expiresAt < now) pendingConfirmations.delete(k);
  }

  const nonce = crypto.randomBytes(6).toString('hex');
  pendingConfirmations.set(nonce, {
    nonce,
    actorId,
    requiredPermission,
    ownerOnly,
    actionType,
    payload,
    summaryHtml,
    backCallback,
    expiresAt: now + 3 * 60_000, // 3 minutes TTL
  });

  const text =
`⚠️ <b>تأیید نهایی عملیات</b>
━━━━━━━━━━━━━━━━━━━━
${summaryHtml}

⏳ <i>این تأییدیه فقط تا ۳ دقیقه آینده و صرفاً برای حساب شما معتبر است.</i>`;

  const keyboard = [
    [
      { text: '✅ تأیید و اجرا', callback_data: `adm:cfm:${nonce}` },
      { text: '❌ انصراف', callback_data: backCallback },
    ],
  ];

  return { text, keyboard };
}

async function editOrSend(
  client: TelegramClient,
  chatId: number | string,
  messageId: number | undefined,
  text: string,
  keyboard: any[][]
): Promise<void> {
  if (messageId) {
    try {
      await client.editMessageText(chatId, messageId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: keyboard },
      });
      return;
    } catch {}
  }
  await client.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: keyboard },
  });
}

function getRequiredPermissionForCallback(data: string): { perm: AdminPermission | null; ownerOnly?: boolean } {
  if (data === 'adm:menu' || data === 'adm:refresh' || data === 'adm:close') return { perm: null };
  if (data.startsWith('adm:sec:')) {
    const sec = data.replace('adm:sec:', '') as AdminPermission;
    return { perm: sec };
  }
  if (data.startsWith('adm:gen:')) return { perm: 'general' };
  if (data === 'adm:set_main_ch' || data === 'adm:set_support') return { perm: 'general' };
  if (data.startsWith('adm:dl:')) return { perm: 'download' };
  if (data.startsWith('adm:sp:')) return { perm: 'spotify' };
  if (data.startsWith('adm:usr:')) return { perm: 'users' };
  if (data === 'adm:dm' || data === 'adm:broadcast' || data === 'adm:bc_copy' || data === 'adm:bc_fwd') {
    return { perm: data === 'adm:dm' ? 'users' : 'broadcast' };
  }
  if (data.startsWith('adm:adm:') || data === 'adm:admin_add' || data === 'adm:admin_remove' || data.startsWith('adm:del_admin:')) {
    return { perm: 'admins' };
  }
  if (data === 'adm:sec_secrets' || data.startsWith('adm:sec_rot_ask:')) {
    return { perm: 'secrets', ownerOnly: true };
  }
  if (data.startsWith('adm:sec_audit:')) return { perm: 'security' };
  if (data.startsWith('adm:srv:')) {
    if (data === 'adm:srv:restart_proc_ask') return { perm: 'server', ownerOnly: true };
    return { perm: 'server' };
  }
  if (data === 'adm:stats' || data === 'adm:logs') return { perm: 'stats' };
  if (data.startsWith('adm:bk:')) return { perm: 'backup' };
  if (data.startsWith('adm:mnt:') || data === 'adm:webhook' || data === 'adm:wh_set' || data === 'adm:wh_del' || data === 'adm:wh_ping') {
    return { perm: 'maintenance' };
  }
  if (data === 'adm:forcejoin' || data.startsWith('adm:fj_')) return { perm: 'forcejoin' };
  if (data === 'adm:instagram' || data.startsWith('adm:ig_') || data === 'adm:youtube' || data.startsWith('adm:yt_')) {
    return { perm: 'cookies' };
  }
  if (data === 'adm:settings') return { perm: 'general' };
  return { perm: 'general' };
}

async function handleUnauthorizedAttempt(
  client: TelegramClient,
  userId: number,
  action: string,
  section: string,
  queryId?: string
): Promise<void> {
  const rec = getAdminRecord(userId);
  recordAuditLog({
    actorId: userId,
    actorRole: rec?.role || 'unauthorized',
    action,
    section,
    result: 'denied',
  });

  if (queryId) {
    await client.answerCallbackQuery(queryId, {
      text: '⛔️ دسترسی غیرمجاز! شما مجوز ورود یا اجرای این بخش را ندارید.',
      show_alert: true,
    });
  }

  const recentDenied = countUnauthorizedAttempts(10);
  if (recentDenied >= 3) {
    await notifyOwnerAlert(
      `unauth_${userId}`,
      `🚨 <b>هشدار امنیتی: تلاش دسترسی غیرمجاز به پنل</b>\n👤 شناسه کاربر: <code>${userId}</code>\n🎯 بخش/عملیات: <code>${escHtml(action)}</code>\n📊 تعداد تلاش‌های ۱۰ دقیقه اخیر: ${recentDenied}`,
      10 * 60_000
    );
  }
}

/**
 * Open or refresh the main Persian admin dashboard
 */
export async function sendAdminDashboard(
  client: TelegramClient,
  chatId: number,
  messageId?: number,
  actorUserId?: number
): Promise<boolean> {
  const uid = actorUserId ?? chatId;
  const actor = getAdminRecord(uid);
  if (!actor || actor.isBlocked) {
    recordAuditLog({
      actorId: uid,
      action: 'open_admin_dashboard',
      section: 'admins',
      result: 'denied',
    });
    return false;
  }

  touchAdminActivity(uid);
  adminSteps.delete(chatId);
  const view = renderMainMenuView(actor);
  await editOrSend(client, chatId, messageId, view.text, view.keyboard);
  return true;
}

/**
 * Execute confirmed pending mutation (called only after matching actor & valid nonce)
 */
async function executePendingConfirmation(
  client: TelegramClient,
  chatId: number,
  messageId: number,
  actor: AdminRecord,
  cfm: PendingConfirmation,
  queryId: string
): Promise<void> {
  const { actionType, payload, backCallback } = cfm;

  if (actionType === 'save_general_text') {
    const { key, value, labelFa } = payload;
    const oldVal = (loadBotConfig().general as any)[key] || '';
    updateGeneralSettings({ [key]: value } as any, actor.userId);
    recordAuditLog({
      actorId: actor.userId,
      actorRole: actor.role,
      action: `update_general_${key}`,
      section: 'general',
      oldValue: oldVal,
      newValue: value,
      result: 'success',
    });
    await notifyConfigChange(`بخش <b>تنظیمات عمومی (${escHtml(labelFa)})</b> توسط <code>${actor.userId}</code> بروزرسانی شد.`);
    await client.answerCallbackQuery(queryId, { text: '✅ تنظیمات با موفقیت ذخیره شد.' });
    const v = renderGeneralSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'save_core_field') {
    const { field, value, labelFa } = payload;
    const oldVal = (loadBotConfig() as any)[field] || '';
    saveBotConfig({ [field]: value } as any, actor.userId);
    recordAuditLog({
      actorId: actor.userId,
      actorRole: actor.role,
      action: `update_${field}`,
      section: 'general',
      oldValue: oldVal,
      newValue: value,
      result: 'success',
    });
    await notifyConfigChange(`مقدار <b>${escHtml(labelFa)}</b> توسط <code>${actor.userId}</code> تغییر یافت.`);
    await client.answerCallbackQuery(queryId, { text: '✅ ذخیره شد.' });
    const v = renderGeneralSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'save_download_setting') {
    const { key, value, labelFa } = payload;
    const oldVal = (loadBotConfig().download as any)[key];
    updateDownloadSettings({ [key]: value } as any, actor.userId);
    recordAuditLog({
      actorId: actor.userId,
      actorRole: actor.role,
      action: `update_download_${key}`,
      section: 'download',
      oldValue: String(oldVal),
      newValue: String(value),
      result: 'success',
    });
    await notifyConfigChange(`تنظیم دانلود <b>${escHtml(labelFa)}</b> از <code>${escHtml(oldVal)}</code> به <code>${escHtml(value)}</code> تغییر کرد.`);
    await client.answerCallbackQuery(queryId, { text: '✅ تنظیمات دانلود ذخیره شد.' });
    const v = renderDownloadSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'save_spotify_setting') {
    const { key, value, labelFa } = payload;
    const oldVal = (loadBotConfig().spotify as any)[key];
    updateSpotifySettings({ [key]: value } as any, actor.userId);
    recordAuditLog({
      actorId: actor.userId,
      actorRole: actor.role,
      action: `update_spotify_${key}`,
      section: 'spotify',
      oldValue: String(oldVal),
      newValue: String(value),
      result: 'success',
    });
    await notifyConfigChange(`تنظیم Spotify <b>${escHtml(labelFa)}</b> از <code>${escHtml(oldVal)}</code> به <code>${escHtml(value)}</code> تغییر کرد.`);
    await client.answerCallbackQuery(queryId, { text: '✅ تنظیمات Spotify ذخیره شد.' });
    const v = renderSpotifySettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'ban_user' || actionType === 'unban_user') {
    const banned = actionType === 'ban_user';
    setUserBannedStatus(payload.targetUserId, banned, payload.reason || null, actor.userId);
    await client.answerCallbackQuery(queryId, { text: banned ? '🚫 کاربر مسدود شد.' : '✅ مسدودیت کاربر برداشته شد.' });
    const v = renderUserProfileView(payload.targetUserId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'set_user_limit') {
    setUserDailyLimitOverride(payload.targetUserId, payload.limit, actor.userId);
    await client.answerCallbackQuery(queryId, { text: '✅ محدودیت کاربر ذخیره شد.' });
    const v = renderUserProfileView(payload.targetUserId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'block_admin' || actionType === 'unblock_admin') {
    const res = setAdminBlocked(actor.userId, payload.targetUserId, actionType === 'block_admin');
    await client.answerCallbackQuery(queryId, { text: res.message, show_alert: true });
    const v = renderSingleAdminDetailView(actor, payload.targetUserId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'remove_admin') {
    const ok = removeAdminId(payload.targetUserId, actor.userId);
    await client.answerCallbackQuery(queryId, {
      text: ok ? `✅ مدیر ${payload.targetUserId} حذف شد.` : '❌ امکان حذف این مدیر وجود ندارد.',
      show_alert: true,
    });
    const v = renderAdminsManagementView(actor);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'controlled_action') {
    const res = await executeControlledAction(actor.userId, payload.action);
    await client.answerCallbackQuery(queryId, { text: res.success ? '✅ انجام شد.' : '❌ ناموفق', show_alert: false });
    await editOrSend(client, chatId, messageId, `${res.success ? '✅' : '❌'} <b>نتیجه عملیات:</b>\n${escHtml(res.message)}`, [
      [{ text: '🔙 بازگشت', callback_data: backCallback }],
    ]);
    return;
  }

  if (actionType === 'restore_backup') {
    const res = await restoreDatabaseBackup(payload.backupId, actor.userId);
    resetConfigCaches();
    await client.answerCallbackQuery(queryId, { text: res.success ? '✅ بازیابی شد.' : '❌ خطا', show_alert: true });
    const v = renderBackupSectionView();
    await editOrSend(client, chatId, messageId, `${res.success ? '✅' : '❌'} ${escHtml(res.message)}\n\n${v.text}`, v.keyboard);
    return;
  }

  if (actionType === 'rotate_secret') {
    const res = consumeSecretRotationChallenge(payload.challengeId, actor.userId);
    await client.answerCallbackQuery(queryId, { text: res.valid ? '🔐 دستورالعمل امن صادر شد.' : '❌ منقضی شد.' });
    if (!res.valid) {
      await editOrSend(client, chatId, messageId, `❌ ${escHtml(res.error || 'خطا')}`, [[{ text: '🔙 بازگشت', callback_data: backCallback }]]);
      return;
    }
    await editOrSend(
      client,
      chatId,
      messageId,
      `🔐 <b>دستور چرخش امن برای <code>${escHtml(res.secretKey)}</code>:</b>\n━━━━━━━━━━━━━━━━━━━━\n${res.instructions}`,
      [[{ text: '🔙 بازگشت به امنیت', callback_data: 'adm:sec:security' }]]
    );
    return;
  }

  if (actionType === 'clear_ig_cookies') {
    clearInstagramCookies();
    recordAuditLog({ actorId: actor.userId, actorRole: actor.role, action: 'clear_ig_cookies', section: 'cookies', result: 'success' });
    await client.answerCallbackQuery(queryId, { text: '✅ کوکی اینستاگرام پاک شد.', show_alert: true });
    const v = renderMaintenanceToolsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }

  if (actionType === 'clear_yt_cookies') {
    clearYoutubeCookies();
    recordAuditLog({ actorId: actor.userId, actorRole: actor.role, action: 'clear_yt_cookies', section: 'cookies', result: 'success' });
    await client.answerCallbackQuery(queryId, { text: '✅ کوکی یوتیوب پاک شد.', show_alert: true });
    const v = renderMaintenanceToolsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return;
  }
}

/**
 * Handle all admin inline keyboard callback queries with strict server-side RBAC
 */
export async function handleAdminCallbackQuery(
  client: TelegramClient,
  query: any
): Promise<boolean> {
  const data = String(query.data || '');
  if (!data.startsWith('adm:')) return false;

  const chatId = query.message?.chat?.id;
  const messageId = query.message?.message_id;
  // Strictly identify user by Telegram numeric `from.id` (never username or spoofing)
  const userId = Number(query.from?.id);

  if (!Number.isSafeInteger(userId) || userId <= 0 || !chatId) {
    return true;
  }

  // Reject callbacks from stale/ancient inline messages (>24h)
  if (query.message?.date) {
    const ageSec = Math.floor(Date.now() / 1000) - Number(query.message.date);
    if (ageSec > CALLBACK_MAX_AGE_SECONDS) {
      await client.answerCallbackQuery(query.id, {
        text: '⏰ این دکمه منقضی شده است! لطفاً مجدداً /admin را ارسال کنید.',
        show_alert: true,
      });
      return true;
    }
  }

  const actor = getAdminRecord(userId);
  if (!actor || actor.isBlocked || !isUserAdmin(userId)) {
    await handleUnauthorizedAttempt(client, userId, data, 'auth', query.id);
    return true;
  }

  const reqPerm = getRequiredPermissionForCallback(data);
  if (reqPerm.ownerOnly && actor.role !== 'owner') {
    await handleUnauthorizedAttempt(client, userId, data, reqPerm.perm || 'owner', query.id);
    return true;
  }
  if (reqPerm.perm && !hasAdminPermission(userId, reqPerm.perm)) {
    await handleUnauthorizedAttempt(client, userId, data, reqPerm.perm, query.id);
    return true;
  }

  touchAdminActivity(userId);

  // One-time bound Confirmation handler
  if (data.startsWith('adm:cfm:')) {
    const nonce = data.replace('adm:cfm:', '');
    const cfm = pendingConfirmations.get(nonce);
    if (!cfm || cfm.expiresAt < Date.now() || cfm.actorId !== userId) {
      pendingConfirmations.delete(nonce);
      recordAuditLog({
        actorId: userId,
        actorRole: actor.role,
        action: `forged_or_expired_confirm:${nonce}`,
        section: 'security',
        result: 'denied',
      });
      await client.answerCallbackQuery(query.id, {
        text: '⛔️ این تأییدیه نامعتبر یا منقضی شده است.',
        show_alert: true,
      });
      return true;
    }
    if ((cfm.ownerOnly && actor.role !== 'owner') || !hasAdminPermission(userId, cfm.requiredPermission)) {
      await handleUnauthorizedAttempt(client, userId, `cfm:${cfm.actionType}`, cfm.requiredPermission, query.id);
      return true;
    }
    pendingConfirmations.delete(nonce);
    await executePendingConfirmation(client, chatId, messageId, actor, cfm, query.id);
    return true;
  }

  // Main menu & close
  if (data === 'adm:menu' || data === 'adm:refresh') {
    await client.answerCallbackQuery(query.id);
    await sendAdminDashboard(client, chatId, messageId, userId);
    return true;
  }

  if (data === 'adm:close') {
    adminSteps.delete(chatId);
    await client.answerCallbackQuery(query.id);
    if (messageId) await client.deleteMessage(chatId, messageId);
    await client.sendMessage(chatId, '✅ <b>پنل مدیریت بسته شد.</b>\nجهت باز کردن مجدد، دستور /admin را ارسال کنید.', { parse_mode: 'HTML' });
    return true;
  }

  // Section routes
  if (data === 'adm:sec:general' || data === 'adm:settings') {
    await client.answerCallbackQuery(query.id);
    const v = renderGeneralSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:download') {
    await client.answerCallbackQuery(query.id);
    const v = renderDownloadSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:spotify') {
    await client.answerCallbackQuery(query.id);
    const v = renderSpotifySettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:users') {
    await client.answerCallbackQuery(query.id);
    const v = renderUsersManagementView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:admins') {
    await client.answerCallbackQuery(query.id);
    const v = renderAdminsManagementView(actor);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:security') {
    await client.answerCallbackQuery(query.id);
    const v = renderSecuritySectionView(actor);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:server') {
    await client.answerCallbackQuery(query.id);
    const v = renderServerStatusView(actor);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:stats' || data === 'adm:stats') {
    await client.answerCallbackQuery(query.id);
    const v = renderStatsAndReportsView(getBotState());
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:backup') {
    await client.answerCallbackQuery(query.id);
    const v = renderBackupSectionView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }
  if (data === 'adm:sec:maintenance') {
    await client.answerCallbackQuery(query.id);
    const v = renderMaintenanceToolsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  // ====================
  // 1. GENERAL TOGGLES & EDITS
  // ====================
  if (data.startsWith('adm:gen:t_')) {
    const g = loadBotConfig().general;
    const map: Record<string, { field: keyof typeof g; label: string }> = {
      'adm:gen:t_bot': { field: 'botEnabled', label: 'وضعیت کلی ربات' },
      'adm:gen:t_reg': { field: 'allowNewRegistrations', label: 'ثبت‌نام کاربران جدید' },
      'adm:gen:t_dl': { field: 'downloadsServiceEnabled', label: 'سرویس دانلود' },
      'adm:gen:t_maint': { field: 'maintenanceMode', label: 'حالت تعمیرات' },
      'adm:gen:t_notify': { field: 'notifyOnChanges', label: 'اطلاع‌رسانی تغییرات' },
    };
    const item = map[data];
    if (item) {
      const oldVal = Boolean(g[item.field]);
      const nextVal = !oldVal;
      updateGeneralSettings({ [item.field]: nextVal } as any, userId);
      recordAuditLog({
        actorId: userId,
        actorRole: actor.role,
        action: `toggle_general_${item.field}`,
        section: 'general',
        oldValue: String(oldVal),
        newValue: String(nextVal),
        result: 'success',
      });
      await client.answerCallbackQuery(query.id, { text: `${item.label}: ${nextVal ? 'روشن 🟢' : 'خاموش 🔴'}` });
      await notifyConfigChange(`${item.label} به <b>${nextVal ? 'روشن' : 'خاموش'}</b> تغییر کرد.`);
      const v = renderGeneralSettingsView();
      await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    }
    return true;
  }

  if (data.startsWith('adm:gen:edit:')) {
    const target = data.replace('adm:gen:edit:', '');
    const labels: Record<string, { key: string; label: string; hint: string }> = {
      welcome: { key: 'welcomeMessage', label: 'پیام خوشامدگویی', hint: 'متن جدید را بفرستید (برای بازگشت به پیش‌فرض کلمه «پاک» را بفرستید):' },
      help: { key: 'helpMessage', label: 'متن راهنما', hint: 'متن راهنمای جدید را بفرستید (برای بازگشت به پیش‌فرض کلمه «پاک» را بفرستید):' },
      error: { key: 'errorMessage', label: 'پیام خطا', hint: 'متن پیام خطای عمومی ربات را ارسال کنید:' },
      support_msg: { key: 'supportMessage', label: 'پیام پشتیبانی', hint: 'متن پیام پشتیبانی را ارسال کنید:' },
      maint_msg: { key: 'maintenanceMessage', label: 'متن حالت تعمیرات', hint: 'پیام نمایشی هنگام روشن بودن حالت تعمیرات را ارسال کنید:' },
      notify_ch: { key: 'notifyChannelId', label: 'کانال/گروه اطلاع‌رسانی', hint: 'شناسه عددی (-100...) یا @username کانال اطلاع‌رسانی را ارسال کنید (یا «پاک» برای ارسال فقط به مالک):' },
    };
    const info = labels[target];
    if (!info) return true;
    adminSteps.set(chatId, { step: 'awaiting_general_edit', actorId: userId, data: info, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      `✏️ <b>ویرایش ${info.label}</b>\n━━━━━━━━━━━━━━━━━━━━\n${info.hint}\n\nجهت انصراف «انصراف» بفرستید.`,
      [[{ text: '❌ انصراف', callback_data: 'adm:sec:general' }]]
    );
    return true;
  }

  // ====================
  // 2. DOWNLOAD SETTINGS
  // ====================
  if (data === 'adm:dl:t_enabled') {
    const oldVal = loadBotConfig().download.enabled;
    updateDownloadSettings({ enabled: !oldVal }, userId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'toggle_download_enabled', section: 'download', oldValue: String(oldVal), newValue: String(!oldVal), result: 'success' });
    await client.answerCallbackQuery(query.id, { text: !oldVal ? '🟢 دانلود فعال شد' : '🔴 دانلود متوقف شد' });
    const v = renderDownloadSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data === 'adm:dl:cycle_fmt') {
    const order: Array<'mp4' | 'mkv' | 'mp3' | 'm4a'> = ['mp4', 'mkv', 'mp3', 'm4a'];
    const cur = loadBotConfig().download.outputFormat;
    const next = order[(order.indexOf(cur) + 1) % order.length];
    updateDownloadSettings({ outputFormat: next }, userId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'change_output_format', section: 'download', oldValue: cur, newValue: next, result: 'success' });
    await client.answerCallbackQuery(query.id, { text: `فرمت خروجی: ${next.toUpperCase()}` });
    const v = renderDownloadSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data === 'adm:dl:cycle_qual') {
    const order: Array<'best_1080' | 'best_720' | 'best_480' | 'best_360' | 'best_audio'> = [
      'best_1080',
      'best_720',
      'best_480',
      'best_360',
      'best_audio',
    ];
    const cur = loadBotConfig().download.defaultQuality;
    const next = order[(order.indexOf(cur) + 1) % order.length];
    updateDownloadSettings({ defaultQuality: next }, userId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'change_default_quality', section: 'download', oldValue: cur, newValue: next, result: 'success' });
    await client.answerCallbackQuery(query.id, { text: `کیفیت پیش‌فرض: ${next}` });
    const v = renderDownloadSettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:dl:edit:')) {
    const field = data.replace('adm:dl:edit:', '');
    await client.answerCallbackQuery(query.id);
    if (field === 'storagePath') {
      adminSteps.set(chatId, { step: 'awaiting_download_storage_path', actorId: userId, createdAt: Date.now() });
      await editOrSend(
        client,
        chatId,
        messageId,
        `📁 <b>تغییر مسیر ذخیره فایل‌ها</b>\n━━━━━━━━━━━━━━━━━━━━\nمقدار فعلی: <code>${escHtml(loadBotConfig().download.storagePath)}</code>\nمسیر جدید را ارسال کنید (فقط داخل <code>/tmp/...</code> یا <code>downloads/...</code> مجاز است):`,
        [[{ text: '❌ انصراف', callback_data: 'adm:sec:download' }]]
      );
      return true;
    }
    const settingKey = `download.${field}`;
    adminSteps.set(chatId, {
      step: 'awaiting_numeric_setting',
      actorId: userId,
      data: { settingKey, section: 'download', field, backCallback: 'adm:sec:download' },
      createdAt: Date.now(),
    });
    const curVal = (loadBotConfig().download as any)[field];
    await editOrSend(
      client,
      chatId,
      messageId,
      `✏️ <b>تغییر تنظیمات دانلود (${escHtml(field)})</b>\n━━━━━━━━━━━━━━━━━━━━\nمقدار فعلی: <code>${curVal}</code>\nلطفاً مقدار عددی جدید را ارسال فرمایید:`,
      [[{ text: '❌ انصراف', callback_data: 'adm:sec:download' }]]
    );
    return true;
  }

  if (data === 'adm:dl:clean_ask') {
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'download',
      'controlled_action',
      { action: 'clean_temp_files' },
      'آیا مطمئن هستید که می‌خواهید تمام فایل‌های موقت دانلود و کش حافظه پاکسازی شوند؟',
      'adm:sec:download'
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data === 'adm:dl:active') {
    await client.answerCallbackQuery(query.id);
    const v = renderActiveDownloadsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:dl:cancel:')) {
    const dlId = data.replace('adm:dl:cancel:', '');
    const cancelled = cancelActiveDownload(dlId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'cancel_active_download', section: 'download', newValue: dlId, result: cancelled ? 'success' : 'failed' });
    await client.answerCallbackQuery(query.id, { text: cancelled ? '🛑 دانلود لغو شد.' : 'دانلود قبلاً پایان یافته است.', show_alert: true });
    const v = renderActiveDownloadsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data === 'adm:dl:errors') {
    await client.answerCallbackQuery(query.id);
    const v = renderDownloadErrorsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  // ====================
  // 3. SPOTIFY SETTINGS
  // ====================
  if (data.startsWith('adm:sp:t_')) {
    const s = loadBotConfig().spotify;
    const map: Record<string, { field: keyof typeof s; label: string }> = {
      'adm:sp:t_enabled': { field: 'enabled', label: 'قابلیت Spotify' },
      'adm:sp:t_track': { field: 'allowTrack', label: 'دریافت آهنگ تکی' },
      'adm:sp:t_album': { field: 'allowAlbum', label: 'دریافت آلبوم' },
      'adm:sp:t_playlist': { field: 'allowPlaylist', label: 'دریافت Playlist' },
      'adm:sp:t_mp3': { field: 'preferMp3', label: 'ترجیح فرمت MP3' },
      'adm:sp:t_320': { field: 'allow320kbpsWhenAvailable', label: 'کیفیت 320kbps در صورت دسترس' },
    };
    const item = map[data];
    if (item) {
      const oldVal = Boolean(s[item.field]);
      updateSpotifySettings({ [item.field]: !oldVal } as any, userId);
      recordAuditLog({ actorId: userId, actorRole: actor.role, action: `toggle_spotify_${item.field}`, section: 'spotify', oldValue: String(oldVal), newValue: String(!oldVal), result: 'success' });
      await client.answerCallbackQuery(query.id, { text: `${item.label}: ${!oldVal ? 'فعال 🟢' : 'غیرفعال 🔴'}` });
      const v = renderSpotifySettingsView();
      await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    }
    return true;
  }

  if (data === 'adm:sp:cycle_qual') {
    const order: Array<'320kbps' | '192kbps' | '128kbps'> = ['320kbps', '192kbps', '128kbps'];
    const cur = loadBotConfig().spotify.defaultQuality;
    const next = order[(order.indexOf(cur) + 1) % order.length];
    updateSpotifySettings({ defaultQuality: next }, userId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'change_spotify_quality', section: 'spotify', oldValue: cur, newValue: next, result: 'success' });
    await client.answerCallbackQuery(query.id, { text: `کیفیت Spotify: ${next}` });
    const v = renderSpotifySettingsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:sp:edit:')) {
    const field = data.replace('adm:sp:edit:', '');
    const settingKey = `spotify.${field}`;
    const curVal = (loadBotConfig().spotify as any)[field];
    adminSteps.set(chatId, {
      step: 'awaiting_numeric_setting',
      actorId: userId,
      data: { settingKey, section: 'spotify', field, backCallback: 'adm:sec:spotify' },
      createdAt: Date.now(),
    });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      `✏️ <b>تغییر تنظیمات Spotify (${escHtml(field)})</b>\n━━━━━━━━━━━━━━━━━━━━\nمقدار فعلی: <code>${curVal}</code>\nلطفاً مقدار عددی جدید را ارسال کنید:`,
      [[{ text: '❌ انصراف', callback_data: 'adm:sec:spotify' }]]
    );
    return true;
  }

  if (data === 'adm:sp:check_conn') {
    await client.answerCallbackQuery(query.id, { text: 'در حال بررسی اتصال Spotify...' });
    const report = await buildPingConnectivityReport();
    const v = renderSpotifySettingsView(report.replace(/\n/g, ' | '));
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data === 'adm:sp:errors') {
    await client.answerCallbackQuery(query.id);
    const v = renderDownloadErrorsView('spotify');
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  // ====================
  // 4. USERS MANAGEMENT
  // ====================
  if (data === 'adm:usr:active') {
    await client.answerCallbackQuery(query.id);
    const v = renderActiveUsersListView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data === 'adm:usr:search') {
    adminSteps.set(chatId, { step: 'awaiting_user_search_id', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      '🔍 <b>جستجوی کاربر با Telegram ID</b>\n━━━━━━━━━━━━━━━━━━━━\nلطفاً شناسه عددی کاربر را ارسال کنید:',
      [[{ text: '❌ انصراف', callback_data: 'adm:sec:users' }]]
    );
    return true;
  }

  if (data.startsWith('adm:usr:view:')) {
    const targetId = Number(data.replace('adm:usr:view:', ''));
    await client.answerCallbackQuery(query.id);
    const v = renderUserProfileView(targetId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:usr:ban_ask:') || data.startsWith('adm:usr:unban_ask:')) {
    const isBan = data.startsWith('adm:usr:ban_ask:');
    const targetId = Number(data.split(':').pop());
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'users',
      isBan ? 'ban_user' : 'unban_user',
      { targetUserId: targetId, reason: isBan ? 'توسط مدیر مسدود شد' : null },
      isBan
        ? `آیا مطمئن هستید که می‌خواهید کاربر <code>${targetId}</code> را مسدود کنید؟`
        : `آیا مطمئن هستید که می‌خواهید مسدودیت کاربر <code>${targetId}</code> را بردارید؟`,
      `adm:usr:view:${targetId}`
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data.startsWith('adm:usr:limit:')) {
    const targetId = Number(data.replace('adm:usr:limit:', ''));
    adminSteps.set(chatId, { step: 'awaiting_user_limit', actorId: userId, data: { targetUserId: targetId }, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      `📅 <b>تنظیم محدودیت مصرف روزانه کاربر <code>${targetId}</code></b>\n━━━━━━━━━━━━━━━━━━━━\nیک عدد بین ۱ تا ۱۰۰۰۰ ارسال کنید، یا کلمه <b>سراسری</b> برای استفاده از محدودیت عمومی ربات:`,
      [[{ text: '❌ انصراف', callback_data: `adm:usr:view:${targetId}` }]]
    );
    return true;
  }

  if (data.startsWith('adm:usr:dm:')) {
    const targetUserId = Number(data.replace('adm:usr:dm:', ''));
    adminSteps.set(chatId, { step: 'awaiting_dm_text', actorId: userId, data: { targetUserId }, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      `✉️ <b>ارسال پیام به کاربر <code>${targetUserId}</code></b>\nلطفاً متن پیام را ارسال کنید:`,
      [[{ text: '❌ انصراف', callback_data: `adm:usr:view:${targetUserId}` }]]
    );
    return true;
  }

  // ====================
  // 5. ADMINS & RBAC MANAGEMENT
  // ====================
  if (data === 'adm:adm:add' || data === 'adm:admin_add') {
    adminSteps.set(chatId, { step: 'awaiting_new_admin_id', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      '➕ <b>افزودن مدیر جدید</b>\n━━━━━━━━━━━━━━━━━━━━\nلطفاً <b>Telegram User ID عددی</b> فرد مورد نظر را ارسال فرمایید (فقط شناسه عددی معتبر پذیرفته می‌شود):',
      [[{ text: '❌ انصراف', callback_data: 'adm:sec:admins' }]]
    );
    return true;
  }

  if (data.startsWith('adm:adm:pickrole:')) {
    const [, , , rawTarget, rawRole] = data.split(':');
    const targetId = Number(rawTarget);
    const role = rawRole as Exclude<AdminRole, 'owner'>;
    const res = upsertAdmin(userId, targetId, role);
    await client.answerCallbackQuery(query.id, { text: res.message, show_alert: true });
    const v = renderAdminsManagementView(actor);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:adm:detail:')) {
    const targetId = Number(data.replace('adm:adm:detail:', ''));
    await client.answerCallbackQuery(query.id);
    const v = renderSingleAdminDetailView(actor, targetId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:adm:role:')) {
    const [, , , rawTarget, rawRole] = data.split(':');
    const targetId = Number(rawTarget);
    const role = rawRole as Exclude<AdminRole, 'owner'>;
    const res = upsertAdmin(userId, targetId, role);
    await client.answerCallbackQuery(query.id, { text: res.message, show_alert: true });
    const v = renderSingleAdminDetailView(actor, targetId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:adm:perms:')) {
    const targetId = Number(data.replace('adm:adm:perms:', ''));
    const check = canManageTargetAdmin(actor, targetId);
    if (!check.allowed) {
      await client.answerCallbackQuery(query.id, { text: check.reason || 'غیرمجاز', show_alert: true });
      return true;
    }
    await client.answerCallbackQuery(query.id);
    const v = renderAdminPermissionsView(actor, targetId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:adm:tperm:')) {
    const [, , , rawTarget, rawPerm] = data.split(':');
    const targetId = Number(rawTarget);
    const perm = rawPerm as AdminPermission;
    const res = toggleAdminPermission(userId, targetId, perm);
    await client.answerCallbackQuery(query.id, { text: res.message, show_alert: !res.success });
    const v = renderAdminPermissionsView(actor, targetId);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:adm:block_ask:') || data.startsWith('adm:adm:unblock_ask:')) {
    if (actor.role !== 'owner') {
      await handleUnauthorizedAttempt(client, userId, data, 'admins', query.id);
      return true;
    }
    const isBlock = data.startsWith('adm:adm:block_ask:');
    const targetId = Number(data.split(':').pop());
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'admins',
      isBlock ? 'block_admin' : 'unblock_admin',
      { targetUserId: targetId },
      isBlock
        ? `آیا مطمئن هستید که می‌خواهید مدیر <code>${targetId}</code> را مسدود کنید؟`
        : `آیا می‌خواهید مسدودیت مدیر <code>${targetId}</code> برداشته شود؟`,
      `adm:adm:detail:${targetId}`,
      true
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data.startsWith('adm:adm:del_ask:')) {
    const targetId = Number(data.replace('adm:adm:del_ask:', ''));
    const check = canManageTargetAdmin(actor, targetId);
    if (!check.allowed) {
      await client.answerCallbackQuery(query.id, { text: check.reason || 'غیرمجاز', show_alert: true });
      return true;
    }
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'admins',
      'remove_admin',
      { targetUserId: targetId },
      `آیا مطمئن هستید که می‌خواهید دسترسی مدیریت کاربر <code>${targetId}</code> را به‌طور کامل حذف کنید؟`,
      `adm:adm:detail:${targetId}`
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  // ====================
  // 6. SECURITY, SECRETS & AUDIT LOGS
  // ====================
  if (data.startsWith('adm:sec_audit:')) {
    const page = parseInt(data.replace('adm:sec_audit:', ''), 10) || 0;
    await client.answerCallbackQuery(query.id);
    const v = renderAuditLogPageView(page);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data === 'adm:sec_secrets') {
    await client.answerCallbackQuery(query.id);
    const v = renderSecretsRotationMenu();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:sec_rot_ask:')) {
    const secretKey = data.replace('adm:sec_rot_ask:', '') as SecretKeyName;
    const chRes = createSecretRotationChallenge(userId, secretKey);
    if (!chRes.success || !chRes.challenge) {
      await client.answerCallbackQuery(query.id, { text: chRes.error || 'غیرمجاز', show_alert: true });
      return true;
    }
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'secrets',
      'rotate_secret',
      { challengeId: chRes.challenge.challengeId, secretKey },
      `درخواست صدور مسیر امن تغییر <code>${escHtml(secretKey)}</code> از طریق AWS Secrets Manager / SSM.\nتوجه: هیچ مقدار Secret در تلگرام ارسال نخواهد شد.`,
      'adm:sec_secrets',
      true
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  // ====================
  // 7. SERVER CONTROL & MONITORING
  // ====================
  if (data === 'adm:srv:ping') {
    await client.answerCallbackQuery(query.id, { text: 'در حال تست اتصال و APIها...' });
    const report = await buildPingConnectivityReport();
    const v = renderServerStatusView(actor, report);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  if (data === 'adm:srv:restart_bot_ask') {
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'server',
      'controlled_action',
      { action: 'restart_bot' },
      'آیا مطمئن هستید که می‌خواهید اتصال Telegram Bot به صورت کنترل‌شده Restart شود؟',
      'adm:sec:server'
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data === 'adm:srv:restart_proc_ask') {
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'server',
      'controlled_action',
      { action: 'restart_backend_process' },
      '♻️ آیا مطمئن هستید که می‌خواهید کل فرآیند Backend و ربات (تحت PM2/Docker) به صورت کنترل‌شده Restart شود؟\n(قبل از خروج یک Backup خودکار گرفته می‌شود)',
      'adm:sec:server',
      true
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data === 'adm:srv:pause_dl_ask') {
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'server',
      'controlled_action',
      { action: 'pause_downloads' },
      'آیا می‌خواهید سرویس دانلود به‌طور موقت متوقف شود؟ (ربات همچنان آنلاین می‌ماند)',
      'adm:sec:server'
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data === 'adm:srv:resume_dl') {
    const res = await executeControlledAction(userId, 'resume_downloads');
    await client.answerCallbackQuery(query.id, { text: res.message, show_alert: true });
    const v = renderServerStatusView(actor);
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  // ====================
  // 8. BACKUP & MAINTENANCE
  // ====================
  if (data === 'adm:bk:create') {
    await client.answerCallbackQuery(query.id, { text: '⏳ در حال تهیه Backup...' });
    const res = await executeControlledAction(userId, 'run_backup');
    const v = renderBackupSectionView();
    await editOrSend(client, chatId, messageId, `${res.success ? '✅' : '❌'} ${escHtml(res.message)}\n\n${v.text}`, v.keyboard);
    return true;
  }

  if (data.startsWith('adm:bk:restore_ask:')) {
    const backupId = Number(data.replace('adm:bk:restore_ask:', ''));
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(
      userId,
      'backup',
      'restore_backup',
      { backupId },
      `⚠️ آیا مطمئن هستید که می‌خواهید دیتابیس به نسخه پشتیبان <b>#${backupId}</b> بازیابی شود؟\n(قبل از بازیابی، یک کپی ایمنی از وضعیت فعلی ذخیره خواهد شد.)`,
      'adm:sec:backup'
    );
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data === 'adm:mnt:vacuum') {
    const res = await executeControlledAction(userId, 'vacuum_db');
    await client.answerCallbackQuery(query.id, { text: res.message, show_alert: true });
    const v = renderMaintenanceToolsView();
    await editOrSend(client, chatId, messageId, v.text, v.keyboard);
    return true;
  }

  // ====================
  // 9. LEGACY & COMPATIBLE MODULES (ForceJoin, Broadcast, Cookies, Webhook, Logs, DM)
  // ====================
  if (data === 'adm:forcejoin') {
    await client.answerCallbackQuery(query.id);
    const config = loadBotConfig();
    const isEnabled = config.forceJoinEnabled;
    const chListText = config.channels.length === 0
      ? '<i>هنوز هیچ کانالی برای قفل اجباری ثبت نشده است.</i>'
      : config.channels.map((ch, idx) =>
          `${idx + 1}. <b>${escHtml(ch.title || ch.username || ch.id)}</b>\n   شناسه: <code>${ch.id}</code> | لینک: <a href="${ch.url || `https://t.me/${ch.username}`}">${escHtml(ch.username || 'لینک')}</a>`
        ).join('\n\n');

    const text =
`🔒 <b>مدیریت قفل جوین اجباری کانال‌ها:</b>
━━━━━━━━━━━━━━━━━━━━
وضعیت فعلی قفل: ${isEnabled ? '🟢 <b>روشن و فعال</b>' : '🔴 <b>خاموش و غیرفعال</b>'}

📋 <b>لیست کانال‌های اسپانسر فعلی:</b>
${chListText}`;

    const keyboard = [
      [{ text: isEnabled ? '🔴 غیرفعال‌سازی قفل' : '🟢 فعال‌سازی قفل', callback_data: 'adm:fj_toggle' }],
      [
        { text: '➕ افزودن کانال جدید', callback_data: 'adm:fj_add' },
        { text: '➖ حذف کانال', callback_data: 'adm:fj_remove' },
      ],
      [{ text: '🔍 تست دسترسی ادمین ربات', callback_data: 'adm:fj_test' }],
      [{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }],
    ];
    await editOrSend(client, chatId, messageId, text, keyboard);
    return true;
  }

  if (data === 'adm:fj_toggle') {
    const config = loadBotConfig();
    const newState = !config.forceJoinEnabled;
    saveBotConfig({ forceJoinEnabled: newState }, userId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'toggle_force_join', section: 'forcejoin', oldValue: String(config.forceJoinEnabled), newValue: String(newState), result: 'success' });
    await client.answerCallbackQuery(query.id, { text: newState ? '✅ قفل جوین اجباری فعال شد.' : '⚠️ قفل جوین اجباری غیرفعال شد.' });
    query.data = 'adm:forcejoin';
    return handleAdminCallbackQuery(client, query);
  }

  if (data === 'adm:fj_add') {
    adminSteps.set(chatId, { step: 'awaiting_channel_id', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      `➕ <b>افزودن کانال جدید برای قفل جوین اجباری:</b>\n━━━━━━━━━━━━━━━━━━━━\n• یوزرنیم کانال: <code>@mychannel</code>\n• لینک کانال: <code>https://t.me/mychannel</code>\n• شناسه عددی: <code>-1001234567890</code>\n• یا فوروارد یک پیام از کانال\n\nجهت انصراف «انصراف» بفرستید.`,
      [[{ text: '❌ انصراف', callback_data: 'adm:forcejoin' }]]
    );
    return true;
  }

  if (data === 'adm:fj_remove') {
    const config = loadBotConfig();
    if (config.channels.length === 0) {
      await client.answerCallbackQuery(query.id, { text: 'کانالی برای حذف وجود ندارد!', show_alert: true });
      return true;
    }
    await client.answerCallbackQuery(query.id);
    const keyboard: any[] = config.channels.map((ch) => [
      { text: `🗑 حذف ${ch.title || ch.username || ch.id}`, callback_data: `adm:fj_del:${encodeURIComponent(ch.id)}` },
    ]);
    keyboard.push([{ text: '🔙 بازگشت', callback_data: 'adm:forcejoin' }]);
    await editOrSend(client, chatId, messageId, '👇 <b>روی کانالی که قصد حذف آن را دارید کلیک کنید:</b>', keyboard);
    return true;
  }

  if (data.startsWith('adm:fj_del:')) {
    const targetId = decodeURIComponent(data.replace('adm:fj_del:', ''));
    const config = loadBotConfig();
    const filtered = config.channels.filter((c) => c.id !== targetId);
    saveBotConfig({ channels: filtered }, userId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'remove_force_join_channel', section: 'forcejoin', oldValue: targetId, result: 'success' });
    await client.answerCallbackQuery(query.id, { text: '✅ کانال با موفقیت حذف شد.' });
    query.data = 'adm:forcejoin';
    return handleAdminCallbackQuery(client, query);
  }

  if (data === 'adm:fj_test') {
    const config = loadBotConfig();
    if (config.channels.length === 0) {
      await client.answerCallbackQuery(query.id, { text: 'کانالی برای تست وجود ندارد!', show_alert: true });
      return true;
    }
    await client.answerCallbackQuery(query.id);
    let report = '🔍 <b>نتیجه بررسی دسترسی ادمین ربات:</b>\n━━━━━━━━━━━━━━━━━━━━\n';
    let updatedAny = false;
    const repaired = [...config.channels];
    for (let i = 0; i < repaired.length; i++) {
      const ch = repaired[i];
      const res = await testChannelAccess(ch.id);
      if (res.success) {
        report += `✅ <b>${escHtml(res.chatTitle || ch.title || ch.id)}:</b> تایید شد.\n`;
        if (res.normalizedId && (ch.id !== res.normalizedId || (!ch.url && res.url))) {
          repaired[i] = { id: res.normalizedId, title: res.chatTitle || ch.title, username: res.username ?? ch.username, url: res.url || ch.url };
          updatedAny = true;
        }
      } else {
        report += `❌ <b>${escHtml(ch.title || ch.id)}:</b> ${escHtml(res.message)}\n`;
      }
    }
    if (updatedAny) saveBotConfig({ channels: repaired }, userId);
    await editOrSend(client, chatId, messageId, report, [[{ text: '🔙 بازگشت به قفل کانال‌ها', callback_data: 'adm:forcejoin' }]]);
    return true;
  }

  if (data === 'adm:broadcast') {
    await client.answerCallbackQuery(query.id);
    const usersCount = getRegisteredUsersCount();
    const text =
`📢 <b>ارسال همگانی پیام (Broadcast)</b>
━━━━━━━━━━━━━━━━━━━━
👥 تعداد کاربران مجاز: <b>${usersCount.toLocaleString('fa-IR')}</b> نفر
⚡ دارای کنترل نرخ ارسال (Rate Limiting) و مدیریت خودکار خطاهای Telegram API (429 / 403)`;
    const keyboard = [
      [
        { text: '✉️ ارسال پیام (Copy)', callback_data: 'adm:bc_copy' },
        { text: '🔄 فوروارد همگانی (Forward)', callback_data: 'adm:bc_fwd' },
      ],
      [{ text: '🔙 بازگشت به مدیریت کاربران', callback_data: 'adm:sec:users' }],
    ];
    await editOrSend(client, chatId, messageId, text, keyboard);
    return true;
  }

  if (data === 'adm:bc_copy' || data === 'adm:bc_fwd') {
    const isCopy = data === 'adm:bc_copy';
    adminSteps.set(chatId, { step: isCopy ? 'awaiting_broadcast_copy' : 'awaiting_broadcast_fwd', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      isCopy
        ? '✉️ <b>ارسال همگانی (Copy):</b>\nلطفاً پیام مورد نظر را بفرستید (پشتیبانی از متن، عکس، ویدیو، فایل):'
        : '🔄 <b>فوروارد همگانی:</b>\nلطفاً پیام مورد نظر را به همین چت فوروارد کنید:',
      [[{ text: '❌ انصراف', callback_data: 'adm:broadcast' }]]
    );
    return true;
  }

  if (data === 'adm:dm') {
    adminSteps.set(chatId, { step: 'awaiting_dm_user_id', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(
      client,
      chatId,
      messageId,
      '✉️ <b>ارسال پیام خصوصی به کاربر:</b>\nلطفاً شناسه عددی کاربر (Telegram ID) را بفرستید:',
      [[{ text: '❌ انصراف', callback_data: 'adm:sec:users' }]]
    );
    return true;
  }

  if (data === 'adm:instagram') {
    await client.answerCallbackQuery(query.id);
    const hasC = hasInstagramCookies();
    await editOrSend(
      client,
      chatId,
      messageId,
      `📷 <b>مدیریت سشن اینستاگرام</b>\n━━━━━━━━━━━━━━━━━━━━\nوضعیت: ${hasC ? '🟢 فعال (محافظت‌شده با دسترسی 600)' : '⚪ غیرفعال'}\n\n⚠️ <i>مقدار کوکی هرگز در پنل یا لاگ‌ها نمایش داده نمی‌شود و پیام ارسالی شما بلافاصله پاک می‌شود.</i>`,
      [
        [{ text: '🔑 ثبت سشن جدید', callback_data: 'adm:ig_set' }],
        ...(hasC ? [[{ text: '🗑 پاکسازی سشن', callback_data: 'adm:ig_clear' }]] : []),
        [{ text: '🔙 بازگشت', callback_data: 'adm:sec:maintenance' }],
      ]
    );
    return true;
  }

  if (data === 'adm:ig_set') {
    adminSteps.set(chatId, { step: 'awaiting_ig_session', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(client, chatId, messageId, '🔑 لطفاً مقدار سشن/کوکی اینستاگرام را بفرستید (پیام پس از ذخیره بلافاصله پاک می‌شود):', [
      [{ text: '❌ انصراف', callback_data: 'adm:instagram' }],
    ]);
    return true;
  }

  if (data === 'adm:ig_clear') {
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(userId, 'cookies', 'clear_ig_cookies', {}, 'آیا از پاکسازی سشن ذخیره‌شده اینستاگرام مطمئن هستید؟', 'adm:instagram');
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data === 'adm:youtube') {
    await client.answerCallbackQuery(query.id);
    const hasC = hasYoutubeCookies();
    await editOrSend(
      client,
      chatId,
      messageId,
      `▶️ <b>مدیریت کوکی‌های یوتیوب</b>\n━━━━━━━━━━━━━━━━━━━━\nوضعیت: ${hasC ? '🟢 فعال (محافظت‌شده با دسترسی 600)' : '⚪ غیرفعال'}\n\n⚠️ <i>کوکی هرگز در لاگ‌ها یا پنل نمایش داده نمی‌شود.</i>`,
      [
        [{ text: '🔑 ثبت کوکی جدید یوتیوب', callback_data: 'adm:yt_set' }],
        ...(hasC ? [[{ text: '🗑 پاکسازی کوکی یوتیوب', callback_data: 'adm:yt_clear' }]] : []),
        [{ text: '🔙 بازگشت', callback_data: 'adm:sec:maintenance' }],
      ]
    );
    return true;
  }

  if (data === 'adm:yt_set') {
    adminSteps.set(chatId, { step: 'awaiting_yt_cookies', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(client, chatId, messageId, '🔑 لطفاً متن کوکی یوتیوب (Netscape) را بفرستید (پیام پس از ذخیره بلافاصله پاک می‌شود):', [
      [{ text: '❌ انصراف', callback_data: 'adm:youtube' }],
    ]);
    return true;
  }

  if (data === 'adm:yt_clear') {
    await client.answerCallbackQuery(query.id);
    const c = createConfirmation(userId, 'cookies', 'clear_yt_cookies', {}, 'آیا از پاکسازی کوکی‌های یوتیوب مطمئن هستید؟', 'adm:youtube');
    await editOrSend(client, chatId, messageId, c.text, c.keyboard);
    return true;
  }

  if (data === 'adm:webhook') {
    await client.answerCallbackQuery(query.id);
    const whInfo = await getBotWebhookInfo().catch(() => null);
    const activeUrl = whInfo?.url || getBotState().webhookUrl;
    await editOrSend(
      client,
      chatId,
      messageId,
      `🌐 <b>مدیریت وب‌هوک:</b>\n━━━━━━━━━━━━━━━━━━━━\n• حالت فعلی: ${activeUrl ? '🌐 Webhook' : '⚡ Long Polling'}\n• آدرس: ${activeUrl ? `<code>${escHtml(activeUrl)}</code>` : 'ندارد'}`,
      [
        [{ text: '🔗 ثبت/تغییر وب‌هوک', callback_data: 'adm:wh_set' }],
        ...(activeUrl ? [[{ text: '🗑 حذف وب‌هوک و بازگشت به Polling', callback_data: 'adm:wh_del' }]] : []),
        [{ text: '🏓 پینگ تلگرام', callback_data: 'adm:wh_ping' }],
        [{ text: '🔙 بازگشت', callback_data: 'adm:sec:maintenance' }],
      ]
    );
    return true;
  }

  if (data === 'adm:wh_set') {
    adminSteps.set(chatId, { step: 'awaiting_webhook_url', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(client, chatId, messageId, '🔗 آدرس HTTPS وب‌هوک را ارسال کنید:', [[{ text: '❌ انصراف', callback_data: 'adm:webhook' }]]);
    return true;
  }

  if (data === 'adm:wh_del') {
    const res = await removeBotWebhook();
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'delete_webhook', section: 'maintenance', result: res.success ? 'success' : 'failed' });
    await client.answerCallbackQuery(query.id, { text: res.message, show_alert: true });
    query.data = 'adm:webhook';
    return handleAdminCallbackQuery(client, query);
  }

  if (data === 'adm:wh_ping') {
    const t0 = Date.now();
    try {
      await client.getMe();
      await client.answerCallbackQuery(query.id, { text: `🏓 پینگ: ${Date.now() - t0} میلی‌ثانیه ✅`, show_alert: true });
    } catch (e: any) {
      await client.answerCallbackQuery(query.id, { text: `❌ خطا: ${e?.message || 'ناموفق'}`, show_alert: true });
    }
    return true;
  }

  if (data === 'adm:logs') {
    await client.answerCallbackQuery(query.id);
    const logs = getBotState().logs.slice(0, 8);
    const logsText = logs.length === 0
      ? '<i>لاگی ثبت نشده است.</i>'
      : logs.map((l) => `${l.status === 'success' ? '✅' : l.status === 'error' ? '❌' : '⏳'} <b>[${l.timestamp}] ${escHtml(l.action)}</b>\n   ${escHtml(l.details)}`).join('\n\n');
    await editOrSend(client, chatId, messageId, `📜 <b>لاگ‌های زنده سیستم:</b>\n━━━━━━━━━━━━━━━━━━━━\n${logsText}`, [
      [{ text: '🔄 بروزرسانی', callback_data: 'adm:logs' }],
      [{ text: '🔙 بازگشت به سرور', callback_data: 'adm:sec:server' }],
    ]);
    return true;
  }

  if (data === 'adm:set_main_ch') {
    adminSteps.set(chatId, { step: 'awaiting_main_channel_url', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(client, chatId, messageId, '🌐 لینک کانال اصلی را ارسال کنید (https://t.me/...):', [[{ text: '❌ انصراف', callback_data: 'adm:sec:general' }]]);
    return true;
  }

  if (data === 'adm:set_support') {
    adminSteps.set(chatId, { step: 'awaiting_support_username', actorId: userId, createdAt: Date.now() });
    await client.answerCallbackQuery(query.id);
    await editOrSend(client, chatId, messageId, '👤 یوزرنیم پشتیبانی را بدون @ ارسال کنید:', [[{ text: '❌ انصراف', callback_data: 'adm:sec:general' }]]);
    return true;
  }

  await client.answerCallbackQuery(query.id).catch(() => null);
  return true;
}

/**
 * Rate-limited Broadcast helper with Telegram 429 retry_after & 403 error handling
 */
export async function runSafeBroadcast(
  client: TelegramClient,
  adminChatId: number,
  sourceMessageId: number,
  mode: 'copy' | 'forward',
  userIds: number[]
): Promise<{ total: number; successCount: number; failedCount: number; blockedCount: number }> {
  let successCount = 0;
  let failedCount = 0;
  let blockedCount = 0;
  const BATCH_SIZE = 8;

  for (let i = 0; i < userIds.length; i += BATCH_SIZE) {
    const batch = userIds.slice(i, i + BATCH_SIZE);
    const results = await Promise.allSettled(
      batch.map(async (uId) => {
        try {
          if (mode === 'copy') {
            await client.copyMessage(uId, adminChatId, sourceMessageId);
          } else {
            await client.forwardMessage(uId, adminChatId, sourceMessageId);
          }
          return 'ok';
        } catch (err: any) {
          const msg = String(err?.message || '').toLowerCase();
          if (msg.includes('too many requests') || msg.includes('retry after')) {
            const match = msg.match(/retry after (\d+)/);
            const waitMs = Math.min(10_000, ((match ? parseInt(match[1], 10) : 2) + 1) * 1000);
            await new Promise((r) => setTimeout(r, waitMs));
            if (mode === 'copy') {
              await client.copyMessage(uId, adminChatId, sourceMessageId);
            } else {
              await client.forwardMessage(uId, adminChatId, sourceMessageId);
            }
            return 'ok';
          }
          if (msg.includes('blocked') || msg.includes('deactivated') || msg.includes('not found')) {
            return 'blocked';
          }
          throw err;
        }
      })
    );

    for (const r of results) {
      if (r.status === 'fulfilled') {
        if (r.value === 'ok') successCount++;
        else {
          blockedCount++;
          failedCount++;
        }
      } else {
        failedCount++;
      }
    }

    if (i + BATCH_SIZE < userIds.length) {
      await new Promise((r) => setTimeout(r, 400));
    }
  }

  return { total: userIds.length, successCount, failedCount, blockedCount };
}

/**
 * Multi-step wizard message input handler (validates inputs + uses confirmation step)
 */
export async function handleAdminMessageStep(
  client: TelegramClient,
  msg: any
): Promise<boolean> {
  const chatId = msg.chat?.id;
  const userId = Number(msg.from?.id);
  const text = (msg.text || '').trim();

  if (!Number.isSafeInteger(userId) || userId <= 0 || !chatId) return false;
  const actor = getAdminRecord(userId);
  if (!actor || actor.isBlocked || !isUserAdmin(userId)) return false;

  const current = adminSteps.get(chatId);
  if (!current || current.actorId !== userId) return false;

  // Auto-expire idle wizard step after 10 minutes
  if (Date.now() - current.createdAt > 10 * 60_000) {
    adminSteps.delete(chatId);
    return false;
  }

  if (text === 'انصراف' || text === '/cancel' || text === '❌ انصراف') {
    adminSteps.delete(chatId);
    await client.sendMessage(chatId, '✅ <b>عملیات لغو شد.</b>', { parse_mode: 'HTML' });
    await sendAdminDashboard(client, chatId, undefined, userId);
    return true;
  }

  // 1. General Settings Edit (requires confirmation)
  if (current.step === 'awaiting_general_edit') {
    if (!hasAdminPermission(userId, 'general')) {
      adminSteps.delete(chatId);
      return true;
    }
    const { key, label } = current.data;
    if (!text) {
      await client.sendMessage(chatId, '⚠️ متن نمی‌تواند خالی باشد. لطفاً متن معتبر ارسال کنید یا «انصراف» بفرستید:', { parse_mode: 'HTML' });
      return true;
    }

    let nextValue = text;
    if (key === 'notifyChannelId') {
      if (text === 'پاک' || text === 'حذف') {
        nextValue = '';
      } else {
        const norm = normalizeChannelIdentifier(text);
        if (!norm.chatId) {
          await client.sendMessage(chatId, `❌ ${escHtml(norm.error || 'شناسه کانال نامعتبر است.')}`, { parse_mode: 'HTML' });
          return true;
        }
        nextValue = norm.chatId;
      }
    } else if ((key === 'welcomeMessage' || key === 'helpMessage') && (text === 'پاک' || text === 'حذف')) {
      nextValue = '';
    }

    if (nextValue.length > 2500) {
      await client.sendMessage(chatId, '❌ طول متن نباید بیشتر از ۲۵۰۰ کاراکتر باشد.', { parse_mode: 'HTML' });
      return true;
    }

    adminSteps.delete(chatId);
    const oldVal = (loadBotConfig().general as any)[key] || '(خالی / پیش‌فرض)';
    const c = createConfirmation(
      userId,
      'general',
      'save_general_text',
      { key, value: nextValue, labelFa: label },
      `بخش: <b>تنظیمات عمومی — ${escHtml(label)}</b>\nمقدار قبلی: <code>${escHtml(String(oldVal).slice(0, 80))}</code>\nمقدار جدید: <code>${escHtml((nextValue || '(پیش‌فرض)').slice(0, 120))}</code>`,
      'adm:sec:general'
    );
    await client.sendMessage(chatId, c.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: c.keyboard } });
    return true;
  }

  // 2. Numeric Download / Spotify Setting (validated + requires confirmation)
  if (current.step === 'awaiting_numeric_setting') {
    const { settingKey, section, field, backCallback } = current.data;
    if (!hasAdminPermission(userId, section)) {
      adminSteps.delete(chatId);
      return true;
    }
    const validation = validateNumericSetting(settingKey, text);
    if (!validation.valid) {
      await client.sendMessage(chatId, `❌ ${escHtml(validation.error)}`, { parse_mode: 'HTML' });
      return true;
    }
    adminSteps.delete(chatId);
    const cfg = loadBotConfig();
    const oldVal = section === 'spotify' ? (cfg.spotify as any)[field] : (cfg.download as any)[field];
    const c = createConfirmation(
      userId,
      section,
      section === 'spotify' ? 'save_spotify_setting' : 'save_download_setting',
      { key: field, value: validation.value, labelFa: field },
      `تغییر تنظیم <b>${escHtml(field)}</b>:\nمقدار قبلی: <code>${oldVal}</code> ➔ مقدار جدید: <code>${validation.value}</code>`,
      backCallback
    );
    await client.sendMessage(chatId, c.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: c.keyboard } });
    return true;
  }

  // 3. Download Storage Path
  if (current.step === 'awaiting_download_storage_path') {
    if (!hasAdminPermission(userId, 'download')) {
      adminSteps.delete(chatId);
      return true;
    }
    const validation = validateStoragePath(text);
    if (!validation.valid || !validation.resolved) {
      await client.sendMessage(chatId, `❌ ${escHtml(validation.error)}`, { parse_mode: 'HTML' });
      return true;
    }
    adminSteps.delete(chatId);
    const oldPath = loadBotConfig().download.storagePath;
    const c = createConfirmation(
      userId,
      'download',
      'save_download_setting',
      { key: 'storagePath', value: validation.resolved, labelFa: 'مسیر ذخیره فایل‌ها' },
      `تغییر مسیر ذخیره:\nقبلی: <code>${escHtml(oldPath)}</code>\nجدید: <code>${escHtml(validation.resolved)}</code>`,
      'adm:sec:download'
    );
    await client.sendMessage(chatId, c.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: c.keyboard } });
    return true;
  }

  // 4. User Search by Numeric ID
  if (current.step === 'awaiting_user_search_id') {
    if (!hasAdminPermission(userId, 'users')) {
      adminSteps.delete(chatId);
      return true;
    }
    const cleanId = Number(text.replace(/[^0-9]/g, ''));
    if (!Number.isSafeInteger(cleanId) || cleanId <= 0) {
      await client.sendMessage(chatId, '❌ شناسه عددی نامعتبر است. فقط ارقام Telegram User ID را ارسال کنید:', { parse_mode: 'HTML' });
      return true;
    }
    adminSteps.delete(chatId);
    const profile = getUserProfile(cleanId);
    if (!profile) {
      await client.sendMessage(chatId, `ℹ️ کاربر <code>${cleanId}</code> هنوز در دیتابیس ثبت نشده است.`, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '🔙 بازگشت', callback_data: 'adm:sec:users' }]] },
      });
      return true;
    }
    const v = renderUserProfileView(cleanId);
    await client.sendMessage(chatId, v.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: v.keyboard } });
    return true;
  }

  // 5. Per-User Daily Limit Override
  if (current.step === 'awaiting_user_limit') {
    if (!hasAdminPermission(userId, 'users')) {
      adminSteps.delete(chatId);
      return true;
    }
    const { targetUserId } = current.data;
    let nextLimit: number | null = null;
    if (text === 'سراسری' || text === 'پیش‌فرض') {
      nextLimit = null;
    } else {
      const val = validateNumericSetting('download.dailyLimitPerUser', text);
      if (!val.valid) {
        await client.sendMessage(chatId, `❌ ${escHtml(val.error)}`, { parse_mode: 'HTML' });
        return true;
      }
      nextLimit = val.value!;
    }
    adminSteps.delete(chatId);
    const c = createConfirmation(
      userId,
      'users',
      'set_user_limit',
      { targetUserId, limit: nextLimit },
      `تنظیم سقف مصرف روزانه برای کاربر <code>${targetUserId}</code>:\nمقدار جدید: <b>${nextLimit === null ? 'سراسری' : `${nextLimit} فایل`}</b>`,
      `adm:usr:view:${targetUserId}`
    );
    await client.sendMessage(chatId, c.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: c.keyboard } });
    return true;
  }

  // 6. Add New Admin (strictly numeric Telegram ID -> choose role within hierarchy)
  if (current.step === 'awaiting_new_admin_id') {
    if (!hasAdminPermission(userId, 'admins')) {
      adminSteps.delete(chatId);
      return true;
    }
    if (!/^\d{5,15}$/.test(text)) {
      await client.sendMessage(chatId, '❌ فقط شناسه عددی معتبر (Telegram User ID با ۵ تا ۱۵ رقم) پذیرفته می‌شود. از Username استفاده نکنید:', { parse_mode: 'HTML' });
      return true;
    }
    const targetAdminId = Number(text);
    const check = canManageTargetAdmin(actor, targetAdminId);
    if (!check.allowed) {
      await client.sendMessage(chatId, `⛔️ ${escHtml(check.reason)}`, { parse_mode: 'HTML' });
      adminSteps.delete(chatId);
      return true;
    }
    adminSteps.delete(chatId);

    const roleButtons: any[][] = [];
    if (ROLE_RANK[actor.role] > ROLE_RANK.super_admin) {
      roleButtons.push([{ text: '⭐ سوپر ادمین (Super Admin)', callback_data: `adm:adm:pickrole:${targetAdminId}:super_admin` }]);
    }
    if (ROLE_RANK[actor.role] > ROLE_RANK.admin) {
      roleButtons.push([{ text: '🛡 ادمین (Admin)', callback_data: `adm:adm:pickrole:${targetAdminId}:admin` }]);
    }
    if (ROLE_RANK[actor.role] > ROLE_RANK.support) {
      roleButtons.push([{ text: '🎧 پشتیبان (Support)', callback_data: `adm:adm:pickrole:${targetAdminId}:support` }]);
    }
    roleButtons.push([{ text: '❌ انصراف', callback_data: 'adm:sec:admins' }]);

    await client.sendMessage(
      chatId,
      `👤 شناسه معتبر <code>${targetAdminId}</code> دریافت شد.\n👇 لطفاً نقش این مدیر را انتخاب کنید:`,
      { parse_mode: 'HTML', reply_markup: { inline_keyboard: roleButtons } }
    );
    return true;
  }

  // 7. Force Join Add Channel
  if (current.step === 'awaiting_channel_id') {
    if (!hasAdminPermission(userId, 'forcejoin')) {
      adminSteps.delete(chatId);
      return true;
    }
    adminSteps.delete(chatId);
    const progress = await client.sendMessage(chatId, '⏳ <i>در حال بررسی دسترسی ادمین ربات در کانال...</i>', { parse_mode: 'HTML' });

    const forwardedChat =
      (msg.forward_origin?.type === 'channel' ? msg.forward_origin.chat : null) ||
      (msg.forward_from_chat?.type === 'channel' ? msg.forward_from_chat : null);

    let rawTarget = forwardedChat?.id ? String(forwardedChat.id) : text.trim();
    if (!forwardedChat) {
      const norm = normalizeChannelIdentifier(rawTarget);
      if (!norm.chatId) {
        await client.editMessageText(chatId, progress.message_id, `❌ ${escHtml(norm.error || 'شناسه کانال نامعتبر است.')}`, { parse_mode: 'HTML' });
        return true;
      }
      rawTarget = norm.chatId;
    }

    const access = await testChannelAccess(rawTarget);
    if (!access.success || !access.normalizedId) {
      await client.editMessageText(chatId, progress.message_id, `❌ ${escHtml(access.message)}`, { parse_mode: 'HTML' });
      return true;
    }

    const config = loadBotConfig();
    const newCh: RequiredChannel = {
      id: access.normalizedId,
      title: access.chatTitle || access.normalizedId,
      username: access.username || '',
      url: access.url || (access.username ? `https://t.me/${access.username}` : ''),
    };
    const filtered = config.channels.filter((c) => c.id !== newCh.id);
    filtered.push(newCh);
    saveBotConfig({ channels: filtered }, userId);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'add_force_join_channel', section: 'forcejoin', newValue: newCh.id, result: 'success' });

    if (!newCh.url) {
      adminSteps.set(chatId, { step: 'awaiting_channel_invite_url', actorId: userId, data: { channelId: newCh.id }, createdAt: Date.now() });
      await client.editMessageText(
        chatId,
        progress.message_id,
        `✅ کانال خصوصی «${escHtml(newCh.title)}» ثبت شد!\n🔗 لطفاً لینک دعوت آن (<code>https://t.me/+...</code>) را ارسال کنید:`,
        { parse_mode: 'HTML' }
      );
      return true;
    }

    await client.editMessageText(chatId, progress.message_id, `✅ <b>کانال «${escHtml(newCh.title)}» با موفقیت افزوده شد!</b>`, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🔒 مدیریت کانال‌ها', callback_data: 'adm:forcejoin' }]] },
    });
    return true;
  }

  if (current.step === 'awaiting_channel_invite_url') {
    const channelId = current.data?.channelId;
    adminSteps.delete(chatId);
    if (!text.startsWith('https://t.me/') && !text.startsWith('http://t.me/')) {
      await client.sendMessage(chatId, '❌ لینک دعوت باید با <code>https://t.me/</code> شروع شود.', { parse_mode: 'HTML' });
      return true;
    }
    const config = loadBotConfig();
    saveBotConfig({ channels: config.channels.map((c) => (c.id === channelId ? { ...c, url: text } : c)) }, userId);
    await client.sendMessage(chatId, '✅ <b>لینک دعوت کانال خصوصی ذخیره شد!</b>', { parse_mode: 'HTML' });
    return true;
  }

  // 8. Rate-Limited Broadcast (Copy & Forward)
  if (current.step === 'awaiting_broadcast_copy' || current.step === 'awaiting_broadcast_fwd') {
    if (!hasAdminPermission(userId, 'broadcast')) {
      adminSteps.delete(chatId);
      return true;
    }
    const mode = current.step === 'awaiting_broadcast_copy' ? 'copy' : 'forward';
    adminSteps.delete(chatId);

    const users = getRegisteredUsers();
    if (users.length === 0) {
      await client.sendMessage(chatId, '❌ هنوز کاربری در دیتابیس ثبت نشده است.', { parse_mode: 'HTML' });
      return true;
    }

    const statusMsg = await client.sendMessage(chatId, `🚀 <b>در حال ارسال همگانی به ${users.length} کاربر...</b>`, { parse_mode: 'HTML' });
    const stats = await runSafeBroadcast(client, chatId, msg.message_id, mode, users);

    recordAuditLog({
      actorId: userId,
      actorRole: actor.role,
      action: `broadcast_${mode}`,
      section: 'broadcast',
      newValue: `total=${stats.total},ok=${stats.successCount},fail=${stats.failedCount}`,
      result: 'success',
    });

    await client.editMessageText(
      chatId,
      statusMsg.message_id,
      `✅ <b>ارسال همگانی پایان یافت!</b>\n━━━━━━━━━━━━━━━━━━━━\n• 👥 کل کاربران: <b>${stats.total}</b>\n• 🟢 موفق: <b>${stats.successCount}</b>\n• 🔴 ناموفق / بلاک‌شده: <b>${stats.failedCount}</b>`,
      { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔙 بازگشت به پنل', callback_data: 'adm:menu' }]] } }
    );
    return true;
  }

  // 9. Cookies (auto-delete admin message containing cookie!)
  if (current.step === 'awaiting_ig_session' || current.step === 'awaiting_yt_cookies') {
    if (!hasAdminPermission(userId, 'cookies')) {
      adminSteps.delete(chatId);
      return true;
    }
    const isIg = current.step === 'awaiting_ig_session';
    adminSteps.delete(chatId);
    // Delete plaintext cookie message from chat immediately
    await client.deleteMessage(chatId, msg.message_id).catch(() => {});

    const res = isIg ? saveInstagramSession(text) : saveYoutubeCookies(text);
    recordAuditLog({
      actorId: userId,
      actorRole: actor.role,
      action: isIg ? 'update_ig_cookie' : 'update_yt_cookie',
      section: 'cookies',
      newValue: '[REDACTED]',
      result: res.success ? 'success' : 'failed',
    });
    await client.sendMessage(
      chatId,
      `${res.success ? '✅' : '❌'} ${escHtml(res.message)}\n🛡 <i>پیام حاوی کوکی جهت امنیت از تاریخچه چت حذف شد.</i>`,
      { parse_mode: 'HTML' }
    );
    await sendAdminDashboard(client, chatId, undefined, userId);
    return true;
  }

  // 10. Direct Message to User
  if (current.step === 'awaiting_dm_user_id') {
    const targetUserId = Number(text.replace(/[^0-9]/g, ''));
    if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0) {
      await client.sendMessage(chatId, '❌ شناسه عددی نامعتبر است:', { parse_mode: 'HTML' });
      return true;
    }
    adminSteps.set(chatId, { step: 'awaiting_dm_text', actorId: userId, data: { targetUserId }, createdAt: Date.now() });
    await client.sendMessage(chatId, `✍️ متن پیام برای کاربر <code>${targetUserId}</code> را ارسال کنید:`, { parse_mode: 'HTML' });
    return true;
  }

  if (current.step === 'awaiting_dm_text') {
    const targetUserId = current.data?.targetUserId;
    adminSteps.delete(chatId);
    try {
      await client.sendMessage(targetUserId, `📩 <b>پیام از طرف مدیریت ربات:</b>\n━━━━━━━━━━━━━━━━━━━━\n${escHtml(text)}`, { parse_mode: 'HTML' });
      recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'send_dm', section: 'users', newValue: `to=${targetUserId}`, result: 'success' });
      await client.sendMessage(chatId, `✅ پیام به کاربر <code>${targetUserId}</code> ارسال شد.`, { parse_mode: 'HTML' });
    } catch (e: any) {
      await client.sendMessage(chatId, `❌ خطا در ارسال: ${escHtml(e?.message || 'کاربر ربات را بلاک کرده است.')}`, { parse_mode: 'HTML' });
    }
    await sendAdminDashboard(client, chatId, undefined, userId);
    return true;
  }

  // 11. Webhook URL
  if (current.step === 'awaiting_webhook_url') {
    adminSteps.delete(chatId);
    if (!text.startsWith('https://')) {
      await client.sendMessage(chatId, '❌ آدرس وب‌هوک باید با <code>https://</code> شروع شود.', { parse_mode: 'HTML' });
      return true;
    }
    const res = await setBotWebhook(text);
    recordAuditLog({ actorId: userId, actorRole: actor.role, action: 'set_webhook', section: 'maintenance', newValue: res.success ? 'configured' : 'failed', result: res.success ? 'success' : 'failed' });
    await client.sendMessage(chatId, `${res.success ? '✅' : '❌'} ${escHtml(res.message)}`, { parse_mode: 'HTML' });
    await sendAdminDashboard(client, chatId, undefined, userId);
    return true;
  }

  // 12. Support Username & Main Channel URL (with confirmation)
  if (current.step === 'awaiting_support_username' || current.step === 'awaiting_main_channel_url') {
    const isSupport = current.step === 'awaiting_support_username';
    const nextVal = isSupport ? text.replace('@', '').trim() : text.trim();
    if (!isSupport && !nextVal.startsWith('https://t.me/') && !nextVal.startsWith('http://t.me/')) {
      await client.sendMessage(chatId, '❌ لینک کانال باید با <code>https://t.me/</code> شروع شود.', { parse_mode: 'HTML' });
      return true;
    }
    adminSteps.delete(chatId);
    const c = createConfirmation(
      userId,
      'general',
      'save_core_field',
      { field: isSupport ? 'supportUsername' : 'mainChannelUrl', value: nextVal, labelFa: isSupport ? 'آیدی پشتیبانی' : 'لینک چنل اصلی' },
      `تغییر <b>${isSupport ? 'آیدی پشتیبانی' : 'لینک چنل اصلی'}</b> به:\n<code>${escHtml(nextVal)}</code>`,
      'adm:sec:general'
    );
    await client.sendMessage(chatId, c.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: c.keyboard } });
    return true;
  }

  return false;
}
