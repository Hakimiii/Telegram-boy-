import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { formatFileSize } from './mediaParser.ts';
import { validateSafeHttpUrl } from '../utils/resilience.ts';
import { loadBotConfig } from './configManager.ts';

const execFileAsync = promisify(execFile);
const YT_DLP_PATH = path.resolve(process.cwd(), 'bin/yt-dlp');

function getSpotifyDownloadDir(): string {
  try {
    return loadBotConfig().download.storagePath || path.resolve('/tmp/downloads');
  } catch {
    return path.resolve('/tmp/downloads');
  }
}

function getYtDlpBin(): string {
  if (fs.existsSync(YT_DLP_PATH)) {
    try {
      fs.chmodSync(YT_DLP_PATH, 0o755);
    } catch {}
    return YT_DLP_PATH;
  }
  return 'yt-dlp';
}

function ensureDirectories() {
  const dir = getSpotifyDownloadDir();
  if (!fs.existsSync(dir)) {
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch {}
  }
  if (fs.existsSync(YT_DLP_PATH)) {
    try {
      fs.chmodSync(YT_DLP_PATH, 0o755);
    } catch {}
  }
}
ensureDirectories();

export interface SpotifyTrackInfo {
  url: string;
  id?: string;
  title: string;
  artist: string;
  album: string;
  year?: string;
  thumbnail: string;
  previewUrl?: string;
}

export interface SpotifyCollectionTrack {
  index: number;
  id?: string;
  title: string;
  artist: string;
  durationMs?: number;
  url: string;
}

export interface SpotifyCollectionInfo {
  type: 'album' | 'playlist';
  id: string;
  url: string;
  title: string;
  creator: string;
  thumbnail: string;
  totalTracks: number;
  tracks: SpotifyCollectionTrack[];
}

export interface SpotifyDownloadResult {
  id: string;
  filePath: string;
  fileName: string;
  fileSizeBytes: number;
  fileSizeFormatted: string;
  title: string;
  artist: string;
  album: string;
  thumbnail: string;
  isAudioPreviewOnly?: boolean;
}

/**
 * Check if a URL is a Spotify track, album, playlist or share link
 */
export function isSpotifyUrl(url: string): boolean {
  return /open\.spotify\.com\/(?:intl-[^/]+\/)?(?:track|album|playlist)\/|spotify\.link\/|spoti\.fi\//i.test(url.trim());
}

/**
 * Extract Spotify Track ID from URL
 */
export function extractSpotifyTrackId(url: string): string | null {
  const match = url.match(/(?:track)[/:]([a-zA-Z0-9]{15,30})/i);
  return match ? match[1] : null;
}

/**
 * Detect if URL is an album or playlist and extract its ID
 */
export function extractSpotifyCollectionTarget(url: string): { type: 'album' | 'playlist'; id: string } | null {
  const match = url.match(/(?:album|playlist)[/:]([a-zA-Z0-9]{15,30})/i);
  if (!match) return null;
  const typeMatch = url.match(/(album|playlist)[/:]([a-zA-Z0-9]{15,30})/i);
  if (!typeMatch) return null;
  const kind = typeMatch[1].toLowerCase() === 'playlist' ? 'playlist' : 'album';
  return { type: kind, id: typeMatch[2] };
}

/**
 * Pure parser for Spotify Embed __NEXT_DATA__ JSON (for unit tests and runtime extraction)
 */
export function parseSpotifyCollectionEmbedJson(
  nextDataJson: any,
  type: 'album' | 'playlist',
  id: string,
  cleanUrl: string
): SpotifyCollectionInfo | null {
  const entity = nextDataJson?.props?.pageProps?.state?.data?.entity;
  if (!entity || !Array.isArray(entity.trackList)) {
    return null;
  }

  const tracks: SpotifyCollectionTrack[] = entity.trackList
    .slice(0, 25)
    .map((item: any, index: number) => {
      const uri: string = String(item?.uri || '');
      const trackIdMatch = uri.match(/spotify:track:([a-zA-Z0-9]+)/);
      const trackId = trackIdMatch ? trackIdMatch[1] : undefined;
      return {
        index: index + 1,
        id: trackId,
        title: String(item?.title || `Track ${index + 1}`),
        artist: String(item?.subtitle || entity?.subtitle || 'Unknown Artist'),
        durationMs: typeof item?.duration === 'number' ? item.duration : undefined,
        url: trackId ? `https://open.spotify.com/track/${trackId}` : cleanUrl,
      };
    })
    .filter((t: SpotifyCollectionTrack) => Boolean(t.title));

  return {
    type,
    id,
    url: cleanUrl,
    title: String(entity.name || entity.title || (type === 'album' ? 'آلبوم اسپاتیفای' : 'پلی‌لیست اسپاتیفای')),
    creator: String(entity.subtitle || 'Spotify'),
    thumbnail: String(entity.coverArt?.sources?.[0]?.url || entity.images?.[0]?.url || ''),
    totalTracks: entity.trackList.length,
    tracks,
  };
}

/**
 * Resolve Spotify short URLs (like spotify.link or spoti.fi) safely
 */
async function resolveRedirectUrl(url: string): Promise<string> {
  const safeUrl = validateSafeHttpUrl(url);
  if (safeUrl.includes('spotify.link') || safeUrl.includes('spoti.fi')) {
    try {
      const resp = await fetch(safeUrl, {
        method: 'HEAD',
        redirect: 'follow',
        headers: { 'User-Agent': 'Mozilla/5.0' },
        signal: AbortSignal.timeout(12000),
      });
      if (resp.url) {
        return validateSafeHttpUrl(resp.url);
      }
    } catch (e) {
      console.warn('Failed to resolve Spotify short url:', e);
    }
  }
  return safeUrl;
}

/**
 * Extract Spotify album or playlist tracklist from official public Embed page
 */
export async function extractSpotifyCollection(rawUrl: string): Promise<SpotifyCollectionInfo | null> {
  const resolvedUrl = await resolveRedirectUrl(rawUrl.trim());
  const cleanUrl = resolvedUrl.split('?')[0];
  const target = extractSpotifyCollectionTarget(cleanUrl);
  if (!target) return null;

  try {
    const embedUrl = `https://open.spotify.com/embed/${target.type}/${target.id}`;
    const res = await fetch(embedUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      signal: AbortSignal.timeout(15000),
    });

    if (!res.ok) return null;
    const html = await res.text();
    const scriptMatch = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i);
    if (!scriptMatch || !scriptMatch[1]) return null;

    const json = JSON.parse(scriptMatch[1]);
    return parseSpotifyCollectionEmbedJson(json, target.type, target.id, cleanUrl);
  } catch (err) {
    console.warn('Spotify collection embed extraction failed:', err);
    return null;
  }
}

/**
 * Extract Spotify metadata using official Spotify embed JSON, oEmbed, and OpenGraph
 */
export async function extractSpotifyInfo(rawUrl: string): Promise<SpotifyTrackInfo> {
  const resolvedUrl = await resolveRedirectUrl(rawUrl.trim());
  const cleanUrl = resolvedUrl.split('?')[0];
  const trackId = extractSpotifyTrackId(cleanUrl);

  let title = 'قطعه اسپاتیفای';
  let artist = '';
  let album = 'Single';
  let year = '';
  let thumbnail = '';
  let previewUrl = '';

  // Strategy 1: Fetch Spotify Embed page which contains complete __NEXT_DATA__
  if (trackId) {
    try {
      const embedUrl = `https://open.spotify.com/embed/track/${trackId}`;
      const res = await fetch(embedUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9',
        },
        signal: AbortSignal.timeout(15000),
      });

      if (res.ok) {
        const html = await res.text();
        const scriptMatch = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i);
        if (scriptMatch && scriptMatch[1]) {
          const json = JSON.parse(scriptMatch[1]);
          const entity = json?.props?.pageProps?.state?.data?.entity;
          if (entity) {
            if (entity.name) title = entity.name;
            if (Array.isArray(entity.artists) && entity.artists.length > 0) {
              artist = entity.artists.map((a: any) => a.name).filter(Boolean).join(', ');
            }
            if (entity.album?.name) album = entity.album.name;
            if (entity.album?.images?.[0]?.url) thumbnail = entity.album.images[0].url;
            if (entity.audioPreview?.url) previewUrl = entity.audioPreview.url;
            if (typeof entity.releaseDate === 'string') {
              year = entity.releaseDate.slice(0, 4);
            } else if (entity.releaseDate?.isoString) {
              year = String(entity.releaseDate.isoString).slice(0, 4);
            }
          }
        }
      }
    } catch (err) {
      console.warn('Spotify embed extraction failed:', err);
    }
  }

  // Strategy 2: If artist or title is still missing, fetch oEmbed metadata
  if (!artist || !thumbnail || title === 'قطعه اسپاتیفای') {
    try {
      const oembedUrl = `https://open.spotify.com/oembed?url=${encodeURIComponent(cleanUrl)}`;
      const oembedRes = await fetch(oembedUrl, { signal: AbortSignal.timeout(12000) });
      if (oembedRes.ok) {
        const oembedData = (await oembedRes.json()) as { title?: string; thumbnail_url?: string };
        if (oembedData.title && title === 'قطعه اسپاتیفای') {
          title = oembedData.title;
        }
        if (!thumbnail && oembedData.thumbnail_url) {
          thumbnail = oembedData.thumbnail_url;
        }
      }
    } catch (err) {
      console.warn('Spotify oEmbed fetch failed:', err);
    }
  }

  // Strategy 3: Parse OpenGraph from track page
  if (!artist) {
    try {
      const pageRes = await fetch(cleanUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9',
        },
        signal: AbortSignal.timeout(15000),
      });
      if (pageRes.ok) {
        const html = await pageRes.text();
        const descMatch = html.match(/<meta property="og:description" content="([^"]+)"/i);
        if (descMatch) {
          const parts = descMatch[1].split('·').map((p) => p.trim());
          if (parts.length >= 2) {
            artist = parts[0];
            if (title === 'قطعه اسپاتیفای') title = parts[1] || title;
            year = parts[3] || parts[2] || year;
          }
        }
        const imgMatch = html.match(/<meta property="og:image" content="([^"]+)"/i);
        if (imgMatch && imgMatch[1] && !thumbnail) {
          thumbnail = imgMatch[1];
        }
      }
    } catch (err) {
      console.warn('Spotify OpenGraph scrape failed:', err);
    }
  }

  if (!artist || artist === 'Spotify') {
    artist = 'Unknown Artist';
  }

  return {
    url: cleanUrl,
    id: trackId || undefined,
    title,
    artist,
    album: album || 'Single',
    year,
    thumbnail,
    previewUrl: previewUrl || undefined,
  };
}

/**
 * Resolves and downloads audio stream for Spotify track safely via shell-free execFile
 */
export async function downloadSpotifyTrack(spotifyInfo: SpotifyTrackInfo): Promise<SpotifyDownloadResult> {
  ensureDirectories();
  const cfg = loadBotConfig().spotify;
  if (!cfg.enabled) {
    throw new Error('سرویس Spotify موقتاً توسط مدیر ربات غیرفعال شده است.');
  }

  const downloadDir = getSpotifyDownloadDir();
  const fileId = crypto.randomUUID();
  const audioFormat = cfg.preferMp3 ? 'mp3' : 'm4a';
  const audioQualityArg = cfg.allow320kbpsWhenAvailable && cfg.defaultQuality === '320kbps'
    ? '0'
    : cfg.defaultQuality === '128kbps'
    ? '5'
    : '2';
  const timeoutMs = Math.max(10, cfg.timeoutSec || 90) * 1000;
  const outputTemplate = path.join(downloadDir, `${fileId}.%(ext)s`);
  const ytDlpBin = getYtDlpBin();

  const cleanTitle = spotifyInfo.title.replace(/[^\w\s\u0600-\u06FF-]/g, ' ').replace(/\s+/g, ' ').trim();
  const cleanArtist = spotifyInfo.artist.split(',')[0].replace(/[^\w\s\u0600-\u06FF-]/g, ' ').replace(/\s+/g, ' ').trim();

  let downloadSucceeded = false;

  const searchQueries: string[] = [];
  if (cleanArtist && cleanArtist !== 'Unknown Artist' && cleanTitle) {
    searchQueries.push(`scsearch5:${cleanArtist} ${cleanTitle}`);
    searchQueries.push(`scsearch5:${cleanTitle} ${cleanArtist}`);
  }
  if (cleanTitle) {
    searchQueries.push(`scsearch5:${cleanTitle}`);
  }

  for (const query of searchQueries) {
    try {
      const args = [
        query,
        '--max-downloads', '1',
        '--ignore-errors',
        '-x',
        '--audio-format', audioFormat,
        '--audio-quality', audioQualityArg,
        '-o', outputTemplate,
        '--no-warnings',
      ];
      try {
        await execFileAsync(ytDlpBin, args, {
          timeout: timeoutMs,
          shell: false,
          maxBuffer: 5 * 1024 * 1024,
        });
      } catch {
        // yt-dlp exits with code 101 when --max-downloads limit is hit; inspect output file below
      }

      const files = fs.readdirSync(downloadDir).filter((f) => f.startsWith(fileId));
      if (files.length > 0) {
        const testFile = path.join(downloadDir, files[0]);
        const stat = fs.statSync(testFile);
        if (stat.size > 20000) {
          downloadSucceeded = true;
          break;
        }
      }
    } catch (err) {
      console.warn(`Query failed (${query}):`, err);
    }
  }

  // Emergency Fallback: If authorized public sources did not yield full audio, use official Spotify 30s preview URL
  let isAudioPreviewOnly = false;
  if (!downloadSucceeded && spotifyInfo.previewUrl) {
    try {
      const safePreview = validateSafeHttpUrl(spotifyInfo.previewUrl);
      console.log('Using official Spotify preview audio fallback...');
      const mp3Path = path.join(downloadDir, `${fileId}.mp3`);
      const resp = await fetch(safePreview, { signal: AbortSignal.timeout(Math.min(timeoutMs, 25000)) });
      if (resp.ok) {
        const buffer = Buffer.from(await resp.arrayBuffer());
        fs.writeFileSync(mp3Path, buffer);
        downloadSucceeded = true;
        isAudioPreviewOnly = true;
      }
    } catch (e) {
      console.warn('Spotify preview download fallback failed:', e);
    }
  }

  const matchingFiles = fs.readdirSync(downloadDir).filter((f) => f.startsWith(fileId));
  if (!downloadSucceeded || matchingFiles.length === 0) {
    throw new Error('فایل صوتی این قطعه از منابع مجاز در دسترس نیست. لطفاً عنوان آهنگ یا لینک ساندکلود/یوتیوب آن را ارسال فرمایید.');
  }

  const actualFileName = matchingFiles[0];
  const finalFilePath = path.join(downloadDir, actualFileName);
  const stats = fs.statSync(finalFilePath);
  const maxBytes = Math.max(5, cfg.maxFileSizeMb || 50) * 1024 * 1024;
  if (stats.size > maxBytes) {
    try { fs.unlinkSync(finalFilePath); } catch {}
    throw new Error(`حجم فایل صوتی (${formatFileSize(stats.size)}) بیشتر از سقف مجاز Spotify (${cfg.maxFileSizeMb} MB) است.`);
  }

  return {
    id: fileId,
    filePath: finalFilePath,
    fileName: actualFileName,
    fileSizeBytes: stats.size,
    fileSizeFormatted: formatFileSize(stats.size),
    title: spotifyInfo.title,
    artist: spotifyInfo.artist,
    album: spotifyInfo.album,
    thumbnail: spotifyInfo.thumbnail,
    isAudioPreviewOnly,
  };
}
