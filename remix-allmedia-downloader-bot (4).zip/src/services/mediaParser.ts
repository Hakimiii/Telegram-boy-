/**
 * Media link parser, platform identification, and format classification utilities
 */

export interface MediaPlatformInfo {
  platform: 'instagram' | 'youtube' | 'tiktok' | 'twitter' | 'facebook' | 'pinterest' | 'reddit' | 'soundcloud' | 'spotify' | 'other';
  platformNameFa: string;
  platformNameEn: string;
  icon: string;
  color: string;
  isValid: boolean;
  cleanUrl: string;
}

export interface VideoFormatOption {
  id: string;
  label: string;
  labelFa: string;
  resolution: string;
  ext: string;
  isAudioOnly?: boolean;
  approxSize?: string;
  qualityRank: number;
}

export interface IdentifiedSong {
  title: string;
  artist: string;
  album?: string;
  genre?: string;
  confidence?: 'high' | 'medium' | 'estimated';
  searchQuery?: string;
}

/**
 * Extracts URL from message text
 */
export function extractUrl(text: string): string | null {
  if (!text) return null;
  const match = text.match(/https?:\/\/[^\s]+/i);
  return match ? match[0].trim() : null;
}

/**
 * Identifies the social media platform from any URL and cleans tracking tokens
 */
export function identifyPlatform(rawUrl: string): MediaPlatformInfo {
  const url = rawUrl.trim();
  
  if (/instagram\.com\/(reel|p|tv|stories|share)\//i.test(url) || /instagram\.com/i.test(url)) {
    let clean = url;
    const instaMatch = url.match(/(?:instagram\.com\/(reel|p|tv|share)\/)([A-Za-z0-9_-]+)/i);
    if (instaMatch) {
      const type = instaMatch[1].toLowerCase() === 'p' ? 'p' : 'reel';
      clean = `https://www.instagram.com/${type}/${instaMatch[2]}/`;
    }

    return {
      platform: 'instagram',
      platformNameFa: 'اینستاگرام',
      platformNameEn: 'Instagram',
      icon: 'Instagram',
      color: '#E1306C',
      isValid: true,
      cleanUrl: clean,
    };
  }

  if (/open\.spotify\.com\/(?:intl-[^/]+\/)?(?:track|album|playlist)\/|spotify\.link\/|spoti\.fi\//i.test(url)) {
    return {
      platform: 'spotify',
      platformNameFa: 'اسپاتیفای',
      platformNameEn: 'Spotify',
      icon: 'Music',
      color: '#1DB954',
      isValid: true,
      cleanUrl: url.split('?')[0],
    };
  }

  if (/soundcloud\.com\/|on\.soundcloud\.com\//i.test(url)) {
    return {
      platform: 'soundcloud',
      platformNameFa: 'ساندکلود',
      platformNameEn: 'SoundCloud',
      icon: 'Radio',
      color: '#FF5500',
      isValid: true,
      cleanUrl: url.split('?')[0],
    };
  }

  if (/(?:youtube\.com\/(?:watch\?v=|shorts\/|v\/)|youtu\.be\/)/i.test(url)) {
    let clean = url;
    const ytShortsMatch = url.match(/(?:youtube\.com\/shorts\/)([A-Za-z0-9_-]+)/i);
    if (ytShortsMatch) {
      clean = `https://www.youtube.com/shorts/${ytShortsMatch[1]}`;
    } else {
      const ytWatchMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]+)/i);
      if (ytWatchMatch) {
        clean = `https://www.youtube.com/watch?v=${ytWatchMatch[1]}`;
      }
    }

    return {
      platform: 'youtube',
      platformNameFa: 'یوتیوب',
      platformNameEn: 'YouTube',
      icon: 'Youtube',
      color: '#FF0000',
      isValid: true,
      cleanUrl: clean,
    };
  }

  if (/tiktok\.com\//i.test(url) || /douyin\.com\//i.test(url)) {
    const clean = url.split('?')[0];
    return {
      platform: 'tiktok',
      platformNameFa: 'تیک‌تاک',
      platformNameEn: 'TikTok',
      icon: 'Share2',
      color: '#00F2FE',
      isValid: true,
      cleanUrl: clean,
    };
  }

  if (/twitter\.com\/.*\/status\//i.test(url) || /x\.com\/.*\/status\//i.test(url)) {
    const clean = url.split('?')[0];
    return {
      platform: 'twitter',
      platformNameFa: 'توییتر / ایکس',
      platformNameEn: 'Twitter (X)',
      icon: 'Twitter',
      color: '#1DA1F2',
      isValid: true,
      cleanUrl: clean,
    };
  }

  if (/facebook\.com|fb\.watch/i.test(url)) {
    return {
      platform: 'facebook',
      platformNameFa: 'فیس‌بوک',
      platformNameEn: 'Facebook',
      icon: 'Facebook',
      color: '#1877F2',
      isValid: true,
      cleanUrl: url,
    };
  }

  if (/pinterest\.com|pin\.it/i.test(url)) {
    return {
      platform: 'pinterest',
      platformNameFa: 'پینترست',
      platformNameEn: 'Pinterest',
      icon: 'Pin',
      color: '#E60023',
      isValid: true,
      cleanUrl: url,
    };
  }

  if (/reddit\.com\/r\/.*\/comments\//i.test(url) || /v\.redd\.it\//i.test(url)) {
    return {
      platform: 'reddit',
      platformNameFa: 'ردیت',
      platformNameEn: 'Reddit',
      icon: 'MessageSquare',
      color: '#FF4500',
      isValid: true,
      cleanUrl: url.split('?')[0],
    };
  }

  const isHttp = /^https?:\/\/.+/i.test(url);
  return {
    platform: 'other',
    platformNameFa: 'سایر سرویس‌ها',
    platformNameEn: 'Other Service',
    icon: 'Globe',
    color: '#6366F1',
    isValid: isHttp,
    cleanUrl: url,
  };
}

/**
 * Standardize quality format options for any video or audio
 */
export function getStandardQualityOptions(platform: string = 'other'): VideoFormatOption[] {
  if (platform === 'soundcloud') {
    return [
      {
        id: 'best_audio',
        label: '🎵 320kbps MP3 (HQ)',
        labelFa: '🎵 کیفیت عالی اورجینال (320k)',
        resolution: '320kbps',
        ext: 'mp3',
        isAudioOnly: true,
        qualityRank: 1,
      },
      {
        id: 'standard_audio',
        label: '🎧 128kbps MP3 (Standard)',
        labelFa: '🎧 کیفیت استاندارد (128k)',
        resolution: '128kbps',
        ext: 'mp3',
        isAudioOnly: true,
        qualityRank: 2,
      },
      {
        id: 'find_song',
        label: '🔍 Song Info & Lyrics',
        labelFa: '🔍 اطلاعات کامل ترک و متن',
        resolution: 'Info',
        ext: 'txt',
        qualityRank: 3,
      }
    ];
  }

  return [
    {
      id: 'best_1080',
      label: '🎬 1080p Full HD',
      labelFa: '🎬 کیفیت 1080p (فول اچ‌دی)',
      resolution: '1080p',
      ext: 'mp4',
      qualityRank: 1,
    },
    {
      id: 'best_720',
      label: '🎥 720p HD',
      labelFa: '🎥 کیفیت 720p (اچ‌دی)',
      resolution: '720p',
      ext: 'mp4',
      qualityRank: 2,
    },
    {
      id: 'best_480',
      label: '📱 480p SD',
      labelFa: '📱 کیفیت 480p (استاندارد)',
      resolution: '480p',
      ext: 'mp4',
      qualityRank: 3,
    },
    {
      id: 'best_360',
      label: '⚡ 360p Low',
      labelFa: '⚡ کیفیت 360p (کم‌حجم)',
      resolution: '360p',
      ext: 'mp4',
      qualityRank: 4,
    },
    {
      id: 'best_audio',
      label: '🎧 MP3 Audio',
      labelFa: '🎧 دانلود صوت اورجینال (MP3)',
      resolution: 'Audio',
      ext: 'mp3',
      isAudioOnly: true,
      qualityRank: 5,
    },
    {
      id: 'find_song',
      label: '🎵 تشخیص موزیک',
      labelFa: '🎵 تشخیص موزیک',
      resolution: 'Music Recognition',
      ext: 'mp3',
      qualityRank: 6,
    }
  ];
}

/**
 * Dynamically extract and classify available video & audio qualities from yt-dlp format list
 */
export function extractDynamicQualityOptions(formats: any[] | undefined, duration: number = 0, platform: string = 'youtube'): VideoFormatOption[] {
  if (!Array.isArray(formats) || formats.length === 0) {
    return getStandardQualityOptions(platform);
  }

  const videoFormats = formats.filter(f => f && f.vcodec && f.vcodec !== 'none');
  
  if (videoFormats.length === 0) {
    return getStandardQualityOptions(platform);
  }

  const options: VideoFormatOption[] = [];

  const tiers = [
    { id: 'best_1080', label: '1080p FHD', labelFa: '🎬 1080p Full HD', minH: 1080, maxH: 1440, rank: 1 },
    { id: 'best_720',  label: '720p HD',   labelFa: '🎥 720p HD',      minH: 720,  maxH: 1079, rank: 2 },
    { id: 'best_480',  label: '480p SD',   labelFa: '📱 480p SD',      minH: 480,  maxH: 719,  rank: 3 },
    { id: 'best_360',  label: '360p',      labelFa: '⚡ 360p',          minH: 360,  maxH: 479,  rank: 4 },
    { id: 'best_240',  label: '240p',      labelFa: '💾 240p',          minH: 144,  maxH: 359,  rank: 5 },
  ];

  for (const tier of tiers) {
    const matching = videoFormats.filter(f => typeof f.height === 'number' && f.height >= tier.minH && f.height <= tier.maxH);
    if (matching.length > 0) {
      let sizeBytes = 0;
      for (const m of matching) {
        if (typeof m.filesize === 'number' && m.filesize > 0) {
          sizeBytes = Math.max(sizeBytes, m.filesize);
        } else if (typeof m.filesize_approx === 'number' && m.filesize_approx > 0) {
          sizeBytes = Math.max(sizeBytes, m.filesize_approx);
        } else if (typeof m.tbr === 'number' && m.tbr > 0 && duration > 0) {
          sizeBytes = Math.max(sizeBytes, (m.tbr * 1024 / 8) * duration);
        }
      }
      const sizeStr = sizeBytes > 0 ? ` (${formatFileSize(sizeBytes)})` : '';
      options.push({
        id: tier.id,
        label: `${tier.label}${sizeStr}`,
        labelFa: `${tier.labelFa}${sizeStr}`,
        resolution: `${tier.minH}p`,
        ext: 'mp4',
        approxSize: sizeBytes > 0 ? formatFileSize(sizeBytes) : undefined,
        qualityRank: tier.rank,
      });
    }
  }

  // Audio formats
  const audioFormats = formats.filter(f => f && f.acodec && f.acodec !== 'none');
  let audioSize = 0;
  for (const a of audioFormats) {
    if (typeof a.filesize === 'number' && a.filesize > 0) {
      audioSize = Math.max(audioSize, a.filesize);
    } else if (typeof a.filesize_approx === 'number' && a.filesize_approx > 0) {
      audioSize = Math.max(audioSize, a.filesize_approx);
    } else if (typeof a.abr === 'number' && a.abr > 0 && duration > 0) {
      audioSize = Math.max(audioSize, (a.abr * 1024 / 8) * duration);
    }
  }
  const audioStr = audioSize > 0 ? ` (${formatFileSize(audioSize)})` : '';
  
  options.push({
    id: 'best_audio',
    label: `🎧 MP3 Audio${audioStr}`,
    labelFa: `🎧 فایل صوتی MP3${audioStr}`,
    resolution: 'Audio',
    ext: 'mp3',
    isAudioOnly: true,
    approxSize: audioSize > 0 ? formatFileSize(audioSize) : undefined,
    qualityRank: 6,
  });

  options.push({
    id: 'find_song',
    label: '🎵 تشخیص موزیک',
    labelFa: '🎵 تشخیص موزیک',
    resolution: 'Music Recognition',
    ext: 'mp3',
    isAudioOnly: true,
    qualityRank: 7,
  });

  if (options.filter(o => !o.isAudioOnly).length === 0) {
    return getStandardQualityOptions(platform);
  }

  return options;
}

/**
 * Convert Latin digits to Persian digits
 */
export function toPersianDigits(num: number | string): string {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(num).replace(/[0-9]/g, (w) => farsiDigits[+w]);
}

/**
 * Render visual text progress bar
 */
export function renderProgressBar(percent: number, totalBlocks: number = 10): string {
  const p = Math.max(0, Math.min(100, Math.round(percent)));
  const filledCount = Math.round((p / 100) * totalBlocks);
  const emptyCount = Math.max(0, totalBlocks - filledCount);
  return '▰'.repeat(filledCount) + '▱'.repeat(emptyCount);
}

export interface ProgressDisplayInfo {
  percent: number;
  downloadedFormatted?: string;
  totalFormatted?: string;
  speedFormatted?: string;
  etaFormatted?: string;
  title?: string;
  isSongFinder?: boolean;
  stage?: 'downloading' | 'processing' | 'uploading';
}

/**
 * Format attractive Telegram loading message with live real percent, rotating hourglass, and dynamic state descriptions
 */
export function formatDownloadLoadingText(info: ProgressDisplayInfo): string {
  const p = Math.max(0, Math.min(100, Math.round(info.percent)));
  const bar = renderProgressBar(p, 10);
  const pFa = toPersianDigits(p);

  // Rotating hourglass emoji alternating based on progress steps
  const hourglass = Math.floor(p / 10) % 2 === 0 ? '⏳' : '⌛';

  if (info.stage === 'uploading' || p >= 100) {
    return (
`📤 <b>در حال ارسال فایل به تلگرام...</b>
━━━━━━━━━━━━━━━━━━━━
${renderProgressBar(100, 10)} ۱۰۰٪

📌 <b>وضعیت:</b> 🚀 در حال بارگذاری نهایی و تحویل به چت
⚡️ لطفاً چند لحظه شکیبا باشید...`
    );
  }

  if (info.stage === 'processing' || p >= 98) {
    return (
`⚙️ <b>در حال پردازش و آماده‌سازی فایل...</b>
━━━━━━━━━━━━━━━━━━━━
${bar} ${pFa}٪

📌 <b>وضعیت:</b> ⚙️ در حال میکس و بهینه‌سازی فرمت جهت پخش روان در تلگرام...
🎬 تا لحظاتی دیگر فایل ارسال می‌شود...`
    );
  }

  // Dynamic state descriptions based on download stage
  let statusText = '';
  if (p < 15) {
    statusText = `${hourglass} در حال پردازش لینک و اتصال به سرور...`;
  } else if (p < 45) {
    statusText = `${hourglass} در حال دانلود و دریافت استریم دیتا...`;
  } else if (p < 75) {
    statusText = `${hourglass} در حال ذخیره‌سازی با بالاترین سرعت...`;
  } else {
    statusText = `${hourglass} تکمیل دریافت قطعات نهایی و هماهنگ‌سازی...`;
  }

  if (info.isSongFinder) {
    if (p < 30) statusText = `🎵 در حال آنالیز هوشمند نام و مشخصات موزیک...`;
    else if (p < 85) statusText = `${hourglass} در حال استخراج و دریافت فایل صوتی با کیفیت ۳۲۰k...`;
    else statusText = `🎶 در حال برچسب‌گذاری و نهایی‌سازی فایل صوتی...`;
  }

  const headerTitle = info.isSongFinder
    ? `${hourglass} <b>در حال تشخیص و استخراج موزیک...</b>`
    : `${hourglass} <b>در حال دانلود و پردازش مدیا...</b>`;

  const lines = [
    headerTitle,
    '━━━━━━━━━━━━━━━━━━━━',
    `${bar} ${pFa}٪`,
    '',
    `📌 <b>وضعیت:</b> ${statusText}`,
  ];

  if (info.downloadedFormatted && info.totalFormatted) {
    lines.push(`📦 <b>حجم:</b> ${info.downloadedFormatted} از ${info.totalFormatted}`);
  } else if (info.totalFormatted) {
    lines.push(`📦 <b>حجم تقریبی:</b> ${info.totalFormatted}`);
  }

  const metaParts: string[] = [];
  if (info.speedFormatted && info.speedFormatted !== 'Unknown' && info.speedFormatted !== 'Unknown B/s') {
    metaParts.push(`🚀 <b>سرعت:</b> ${info.speedFormatted}`);
  }
  if (info.etaFormatted && info.etaFormatted !== 'Unknown') {
    metaParts.push(`⏱ <b>باقیمانده:</b> ${toPersianDigits(info.etaFormatted)}`);
  }

  if (metaParts.length > 0) {
    lines.push(metaParts.join(' | '));
  }

  return lines.join('\n');
}


/**
 * Format duration seconds into mm:ss or hh:mm:ss
 */
export function formatDuration(seconds: number | undefined): string {
  if (!seconds || isNaN(seconds) || seconds <= 0) return '0:00';
  const sec = Math.floor(seconds);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
  return `${m}:${s.toString().padStart(2, '0')}`;
}

/**
 * Format bytes to human readable format (MB, GB)
 */
export function formatFileSize(bytes: number | undefined): string {
  if (!bytes || bytes <= 0) return 'نامشخص';
  const mb = bytes / (1024 * 1024);
  if (mb >= 1024) {
    return `${(mb / 1024).toFixed(1)} GB`;
  }
  return `${mb.toFixed(1)} MB`;
}

/**
 * Heuristics to extract song and artist from raw title, description, or track tags
 */
export function parseSongInfoFromText(title: string, uploader: string = ''): IdentifiedSong {
  // Check common patterns like "Artist - Title" or "Title (feat. Artist)"
  const cleaned = title.replace(/\[official.*\]|\(official.*\)|#shorts|#reels|#tiktok/gi, '').trim();

  const dashMatch = cleaned.match(/^([^-–—]+)\s*[-–—]\s*(.+)$/);
  if (dashMatch) {
    return {
      artist: dashMatch[1].trim(),
      title: dashMatch[2].trim(),
      confidence: 'medium',
      searchQuery: `${dashMatch[1].trim()} ${dashMatch[2].trim()}`,
    };
  }

  return {
    artist: uploader || 'نامشخص',
    title: cleaned || title,
    confidence: 'estimated',
    searchQuery: `${uploader} ${cleaned}`.trim(),
  };
}

/**
 * Evaluates HTTP status code from a webhook pre-flight POST test
 */
export function evaluateWebhookCheckStatus(statusCode: number): { valid: boolean; reasonFa?: string } {
  if (statusCode >= 200 && statusCode < 300) {
    return { valid: true };
  }
  if (statusCode === 301 || statusCode === 302 || statusCode === 307 || statusCode === 308) {
    return {
      valid: false,
      reasonFa: `آدرس وب‌هوک درخواست را ریدایرکت کرد (HTTP ${statusCode}). این آدرس نیاز به احراز هویت مرورگر دارد و سرور تلگرام نمی‌تواند به آن پیام بفرستد. ربات در حالت Polling فعال نگه داشته شد.`,
    };
  }
  if (statusCode === 401 || statusCode === 403) {
    return {
      valid: false,
      reasonFa: `آدرس وب‌هوک دارای قفل امنیتی است (HTTP ${statusCode} - مانند قفل Vercel Authentication). ابتدا قفل Deployment Protection را خاموش کنید. ربات در حالت Polling فعال نگه داشته شد.`,
    };
  }
  if (statusCode === 404 || statusCode === 405) {
    return {
      valid: false,
      reasonFa: `اندپوینت وب‌هوک روی این دامنه درخواست POST را پشتیبانی نمی‌کند (HTTP ${statusCode}). کدهای جدید هنوز روی آن هاست دیپلوی نشده‌اند. ربات در حالت Polling فعال نگه داشته شد.`,
    };
  }
  return {
    valid: false,
    reasonFa: `آدرس وب‌هوک پاسخ نامعتبر برگرداند (HTTP ${statusCode}). ربات در حالت Polling فعال نگه داشته شد.`,
  };
}

/**
 * Normalize channel username, numeric ID, or t.me link into a Telegram API chat_id
 */
export function normalizeChannelIdentifier(rawInput: string): {
  chatId: string;
  isInviteLink: boolean;
  inviteUrl?: string;
  error?: string;
} {
  const raw = (rawInput || '').trim();
  if (!raw) {
    return { chatId: '', isInviteLink: false, error: 'شناسه یا آیدی کانال خالی است.' };
  }

  // Private invite link (t.me/+hash or t.me/joinchat/hash)
  const inviteMatch = raw.match(/(?:https?:\/\/)?(?:t\.me|telegram\.me)\/(\+[A-Za-z0-9_-]+|joinchat\/[A-Za-z0-9_-]+)/i);
  if (inviteMatch) {
    const inviteUrl = raw.startsWith('http') ? raw : `https://t.me/${inviteMatch[1]}`;
    return {
      chatId: '',
      isInviteLink: true,
      inviteUrl,
      error: 'لینک دعوت خصوصی مستقیماً قابل بررسی نیست؛ لطفاً شناسه عددی (-100...) کانال را بفرستید یا یک پست از کانال را همینجا فوروارد کنید.',
    };
  }

  // Private channel message link: t.me/c/1234567890/5 -> -1001234567890
  const privatePostMatch = raw.match(/(?:https?:\/\/)?(?:t\.me|telegram\.me)\/c\/(\d+)(?:\/\d+)?/i);
  if (privatePostMatch) {
    return { chatId: `-100${privatePostMatch[1]}`, isInviteLink: false };
  }

  // Public channel link: t.me/mychannel or t.me/mychannel/123
  const publicUrlMatch = raw.match(/(?:https?:\/\/)?(?:t\.me|telegram\.me)\/([A-Za-z0-9_]{3,})(?:\/\d+)?\/?(?:\?.*)?$/i);
  if (publicUrlMatch) {
    return { chatId: `@${publicUrlMatch[1]}`, isInviteLink: false };
  }

  // Already a negative numeric ID (-1001234567890 or -123456)
  if (/^-\d{5,}$/.test(raw)) {
    return { chatId: raw, isInviteLink: false };
  }

  // Bare positive numeric ID missing -100 prefix
  if (/^\d{8,15}$/.test(raw)) {
    return { chatId: `-100${raw}`, isInviteLink: false };
  }

  // @username or bare username
  const usernameMatch = raw.match(/^@?([A-Za-z0-9_]{3,})$/);
  if (usernameMatch) {
    return { chatId: `@${usernameMatch[1]}`, isInviteLink: false };
  }

  return { chatId: '', isInviteLink: false, error: 'فرمت شناسه یا آیدی کانال نامعتبر است.' };
}

/**
 * Determine if Telegram getChatMember result represents an active channel/chat member
 */
export function isTelegramChatMemberStatusJoined(member: { status?: string; is_member?: boolean } | null | undefined): boolean {
  const status = member?.status;
  if (!status) return false;
  if (status === 'creator' || status === 'administrator' || status === 'member') {
    return true;
  }
  if (status === 'restricted') {
    return member?.is_member !== false;
  }
  return false;
}

/**
 * Detect whether a getChatMember error is due to bot/channel configuration rather than user absence
 */
export function isChannelAdminConfigError(errMessage: string): boolean {
  const lower = (errMessage || '').toLowerCase();
  return (
    lower.includes('member list is inaccessible') ||
    lower.includes('chat not found') ||
    lower.includes('bot was kicked') ||
    lower.includes('bot is not a member') ||
    lower.includes('not enough rights') ||
    lower.includes('have no rights') ||
    lower.includes('channel_private') ||
    lower.includes('peer_id_invalid')
  );
}

/**
 * Extract shortcode from an Instagram post/reel/tv/share URL
 */
export function extractInstagramShortcode(url: string): string | null {
  if (!url) return null;
  const match = url.match(/instagram\.com\/(?:reel|reels|p|tv|share)\/([A-Za-z0-9_-]+)/i);
  return match ? match[1] : null;
}

/**
 * Detect whether a yt-dlp error when using cookies indicates an expired/rejected cookie session
 */
export function isInstagramCookieRejectionError(errMessage: string): boolean {
  const lower = (errMessage || '').toLowerCase();
  return (
    lower.includes('jsondecodeerror') ||
    lower.includes('failed to parse json') ||
    lower.includes('expecting value') ||
    lower.includes('login_required') ||
    lower.includes('login page') ||
    lower.includes('checkpoint') ||
    lower.includes('http error 400') ||
    lower.includes('http error 401') ||
    lower.includes('http error 403')
  );
}

function decodeHtmlAndJsonUrl(raw: string): string {
  return raw
    .replace(/\\u0026/gi, '&')
    .replace(/\\\//g, '/')
    .replace(/&amp;/g, '&')
    .trim();
}

/**
 * Best-effort parser for Instagram public embed/post HTML to extract direct media URLs when yt-dlp fails
 */
export function parseInstagramEmbedHtml(html: string): {
  mediaUrls: Array<{ url: string; type: 'video' | 'photo' }>;
  caption: string;
  uploader: string;
} {
  const mediaUrls: Array<{ url: string; type: 'video' | 'photo' }> = [];
  const seen = new Set<string>();

  const pushMedia = (rawUrl: string | undefined, type: 'video' | 'photo') => {
    if (!rawUrl) return;
    const decoded = decodeHtmlAndJsonUrl(rawUrl);
    if (!/^https?:\/\//i.test(decoded)) return;
    // Ignore static CDN icons/assets
    if (decoded.includes('static.cdninstagram.com') || decoded.includes('/rsrc.php/')) return;
    if (seen.has(decoded)) return;
    seen.add(decoded);
    mediaUrls.push({ url: decoded, type });
  };

  // 1. JSON video_url / display_url entries embedded in script blocks
  for (const m of html.matchAll(/"video_url"\s*:\s*"((?:\\.|[^"\\])+)"/g)) {
    pushMedia(m[1], 'video');
  }
  if (mediaUrls.length === 0) {
    for (const m of html.matchAll(/"display_url"\s*:\s*"((?:\\.|[^"\\])+)"/g)) {
      pushMedia(m[1], 'photo');
    }
  }

  // 2. OpenGraph meta tags
  if (mediaUrls.length === 0) {
    for (const m of html.matchAll(/<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']/gi)) {
      pushMedia(m[1], 'video');
    }
    for (const m of html.matchAll(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:video(?::secure_url)?["']/gi)) {
      pushMedia(m[1], 'video');
    }
  }

  // 3. Embedded media image tag if no video found
  if (mediaUrls.length === 0) {
    for (const m of html.matchAll(/<img[^>]+class=["'][^"']*EmbeddedMediaImage[^"']*["'][^>]+src=["']([^"']+)["']/gi)) {
      pushMedia(m[1], 'photo');
    }
    for (const m of html.matchAll(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/gi)) {
      pushMedia(m[1], 'photo');
    }
  }

  const userMatch =
    html.match(/class=["'][^"']*UsernameText[^"']*["'][^>]*>([^<]+)</i) ||
    html.match(/"username"\s*:\s*"([^"]+)"/i);
  const uploader = userMatch ? userMatch[1].trim() : 'اینستاگرام';

  const captionMatch =
    html.match(/class=["'][^"']*Caption[^"']*["'][^>]*>([\s\S]*?)<\/div>/i) ||
    html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i);
  const caption = captionMatch
    ? captionMatch[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()
    : '';

  return { mediaUrls, caption, uploader };
}
