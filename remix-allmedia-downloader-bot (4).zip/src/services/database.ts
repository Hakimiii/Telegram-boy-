import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync, backup as sqliteBackup } from 'node:sqlite';

export function getDatabasePath(): string {
  return path.resolve(process.env.BOT_DB_PATH || path.join(process.cwd(), 'data', 'bot_state.db'));
}

export function getBackupsDir(): string {
  return path.resolve(process.env.BOT_BACKUPS_DIR || path.join(process.cwd(), 'backups'));
}

export interface SchemaMigration {
  version: number;
  name: string;
  sql: string;
}

const MIGRATIONS: SchemaMigration[] = [
  {
    version: 1,
    name: 'initial_core_tables',
    sql: `
      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value_json TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by INTEGER
      );

      CREATE TABLE IF NOT EXISTS admins (
        user_id INTEGER PRIMARY KEY,
        role TEXT NOT NULL CHECK(role IN ('owner', 'super_admin', 'admin', 'support')),
        permissions_json TEXT NOT NULL,
        is_blocked INTEGER NOT NULL DEFAULT 0,
        added_by INTEGER,
        last_active_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        first_name TEXT,
        username TEXT,
        joined_at TEXT NOT NULL,
        last_active_at TEXT NOT NULL,
        is_banned INTEGER NOT NULL DEFAULT 0,
        ban_reason TEXT,
        daily_limit_override INTEGER,
        total_requests INTEGER NOT NULL DEFAULT 0,
        total_downloads INTEGER NOT NULL DEFAULT 0,
        daily_date TEXT,
        daily_count INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS user_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        platform TEXT,
        url TEXT,
        action TEXT NOT NULL,
        quality_id TEXT,
        status TEXT NOT NULL,
        error_message TEXT,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_user_requests_user ON user_requests(user_id, id DESC);
      CREATE INDEX IF NOT EXISTS idx_user_requests_status ON user_requests(status, id DESC);

      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        actor_id INTEGER NOT NULL,
        actor_role TEXT,
        action TEXT NOT NULL,
        section TEXT NOT NULL,
        old_value TEXT,
        new_value TEXT,
        result TEXT NOT NULL,
        source TEXT NOT NULL DEFAULT 'telegram',
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(id DESC);

      CREATE TABLE IF NOT EXISTS backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        size_bytes INTEGER NOT NULL,
        status TEXT NOT NULL,
        created_by INTEGER,
        notes TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS alerts_history (
        alert_key TEXT PRIMARY KEY,
        last_sent_at INTEGER NOT NULL,
        count INTEGER NOT NULL DEFAULT 1
      );
    `,
  },
];

const SENSITIVE_VALUE_PATTERNS = [
  /bot[0-9]{6,14}:[A-Za-z0-9_-]{20,}/gi,
  /\b[0-9]{8,12}:AA[A-Za-z0-9_-]{20,}\b/g,
  /AIza[0-9A-Za-z_-]{30,}/g,
  /AKIA[0-9A-Z]{16}/g,
  /Bearer\s+[A-Za-z0-9._~+/=-]{8,}/gi,
  /([A-Za-z0-9_]*(?:TOKEN|SECRET|PASSWORD|PASSWD|COOKIE|SESSION_?ID|API_?KEY|ACCESS_?KEY|PRIVATE_?KEY)[A-Za-z0-9_]*)\s*[:=]\s*["']?[^\s"';]+["']?/gi,
];

const SENSITIVE_KEY_WORDS = [
  'token',
  'secret',
  'password',
  'passwd',
  'cookie',
  'sessionid',
  'session_id',
  'api_key',
  'apikey',
  'credential',
  'private_key',
];

export function redactSensitiveText(input: unknown, fieldKey: string = ''): string | null {
  if (input === undefined || input === null) return null;
  const keyLower = fieldKey.toLowerCase();
  if (SENSITIVE_KEY_WORDS.some((w) => keyLower.includes(w))) {
    return '[REDACTED]';
  }
  let text = typeof input === 'string' ? input : JSON.stringify(input);
  for (const pat of SENSITIVE_VALUE_PATTERNS) {
    text = text.replace(pat, '[REDACTED]');
  }
  if (text.length > 350) {
    text = text.slice(0, 347) + '...';
  }
  return text;
}

let dbInstance: DatabaseSync | null = null;
let openedDbPath: string | null = null;
let lastBackupAtIso: string | null = null;
let lastBackupStatus: 'success' | 'failed' | 'none' = 'none';

function ensureSecureDirectory(dirPath: string): void {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true, mode: 0o700 });
  }
  try {
    fs.chmodSync(dirPath, 0o700);
  } catch {}
}

function secureFilePermissions(filePath: string): void {
  try {
    if (fs.existsSync(filePath)) {
      fs.chmodSync(filePath, 0o600);
    }
  } catch {}
}

function runMigrations(db: DatabaseSync, dbPath: string): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const appliedRows = db.prepare('SELECT version FROM schema_migrations').all() as Array<{ version: number }>;
  const appliedVersions = new Set(appliedRows.map((r) => Number(r.version)));
  const pending = MIGRATIONS.filter((m) => !appliedVersions.has(m.version));

  if (pending.length === 0) return;

  // Create pre-migration file backup if existing DB has prior migrations
  if (appliedVersions.size > 0 && dbPath !== ':memory:' && fs.existsSync(dbPath)) {
    try {
      const backupsDir = getBackupsDir();
      ensureSecureDirectory(backupsDir);
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const preMigFile = path.join(backupsDir, `pre-migration-v${pending[0].version}-${stamp}.db`);
      try {
        db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
      } catch {}
      fs.copyFileSync(dbPath, preMigFile);
      secureFilePermissions(preMigFile);
    } catch (err) {
      console.warn('[Database] Pre-migration backup warning:', err);
    }
  }

  for (const migration of pending) {
    db.exec('BEGIN IMMEDIATE;');
    try {
      db.exec(migration.sql);
      db.prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)').run(
        migration.version,
        migration.name,
        new Date().toISOString()
      );
      db.exec('COMMIT;');
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }
  }
}

export function getDb(): DatabaseSync {
  const targetPath = getDatabasePath();
  if (dbInstance && dbInstance.isOpen && openedDbPath === targetPath) {
    return dbInstance;
  }

  if (dbInstance && dbInstance.isOpen) {
    try {
      dbInstance.close();
    } catch {}
    dbInstance = null;
  }

  if (targetPath !== ':memory:') {
    ensureSecureDirectory(path.dirname(targetPath));
  }

  const db = new DatabaseSync(targetPath, {
    timeout: 5000,
    enableForeignKeyConstraints: true,
  });

  if (targetPath !== ':memory:') {
    secureFilePermissions(targetPath);
    try {
      db.exec('PRAGMA journal_mode = WAL;');
    } catch {}
  }
  db.exec('PRAGMA synchronous = NORMAL;');
  db.exec('PRAGMA busy_timeout = 5000;');

  runMigrations(db, targetPath);

  dbInstance = db;
  openedDbPath = targetPath;
  return db;
}

export function closeDb(): void {
  if (dbInstance && dbInstance.isOpen) {
    try {
      dbInstance.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    } catch {}
    try {
      dbInstance.close();
    } catch {}
  }
  dbInstance = null;
  openedDbPath = null;
}

export function getSettingValue<T>(key: string): T | null {
  const db = getDb();
  const row = db.prepare('SELECT value_json FROM settings WHERE key = ?').get(key) as { value_json: string } | undefined;
  if (!row) return null;
  try {
    return JSON.parse(row.value_json) as T;
  } catch {
    return null;
  }
}

export function setSettingValue(key: string, value: unknown, updatedBy: number | null = null): void {
  const db = getDb();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO settings (key, value_json, updated_at, updated_by)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET
       value_json = excluded.value_json,
       updated_at = excluded.updated_at,
       updated_by = excluded.updated_by`
  ).run(key, JSON.stringify(value), now, updatedBy);
}

export interface AuditLogInput {
  actorId: number;
  actorRole?: string;
  action: string;
  section: string;
  oldValue?: unknown;
  newValue?: unknown;
  result: 'success' | 'denied' | 'failed';
  source?: string;
}

export interface AuditLogRow {
  id: number;
  actor_id: number;
  actor_role: string | null;
  action: string;
  section: string;
  old_value: string | null;
  new_value: string | null;
  result: string;
  source: string;
  created_at: string;
}

export function recordAuditLog(entry: AuditLogInput): void {
  try {
    const db = getDb();
    const safeOld = redactSensitiveText(entry.oldValue, entry.section || entry.action);
    const safeNew = redactSensitiveText(entry.newValue, entry.section || entry.action);
    db.prepare(
      `INSERT INTO audit_logs (actor_id, actor_role, action, section, old_value, new_value, result, source, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      Number(entry.actorId) || 0,
      entry.actorRole || null,
      String(entry.action).slice(0, 120),
      String(entry.section).slice(0, 80),
      safeOld,
      safeNew,
      entry.result,
      String(entry.source || 'telegram').slice(0, 64),
      new Date().toISOString()
    );
  } catch (err) {
    console.error('[AuditLog] Failed to write audit log:', err);
  }
}

export function getRecentAuditLogs(limit: number = 15, offset: number = 0): AuditLogRow[] {
  const db = getDb();
  const safeLimit = Math.max(1, Math.min(50, limit));
  const safeOffset = Math.max(0, offset);
  return db
    .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?')
    .all(safeLimit, safeOffset) as unknown as AuditLogRow[];
}

export function countUnauthorizedAttempts(windowMinutes: number = 60): number {
  const db = getDb();
  const sinceIso = new Date(Date.now() - windowMinutes * 60_000).toISOString();
  const row = db
    .prepare("SELECT COUNT(*) as cnt FROM audit_logs WHERE result = 'denied' AND created_at >= ?")
    .get(sinceIso) as { cnt: number } | undefined;
  return Number(row?.cnt || 0);
}

export interface BackupRecord {
  id: number;
  file_name: string;
  file_path: string;
  size_bytes: number;
  status: string;
  created_by: number | null;
  notes: string | null;
  created_at: string;
}

export function getLastBackupSummary(): { lastBackupAt: string | null; status: string; count: number } {
  try {
    const db = getDb();
    const row = db
      .prepare('SELECT created_at, status FROM backups ORDER BY id DESC LIMIT 1')
      .get() as { created_at: string; status: string } | undefined;
    const cntRow = db.prepare("SELECT COUNT(*) as cnt FROM backups WHERE status = 'success'").get() as
      | { cnt: number }
      | undefined;
    return {
      lastBackupAt: row?.created_at || lastBackupAtIso,
      status: row?.status || lastBackupStatus,
      count: Number(cntRow?.cnt || 0),
    };
  } catch {
    return { lastBackupAt: lastBackupAtIso, status: lastBackupStatus, count: 0 };
  }
}

export function listBackups(limit: number = 10): BackupRecord[] {
  const db = getDb();
  return db
    .prepare('SELECT * FROM backups ORDER BY id DESC LIMIT ?')
    .all(Math.max(1, Math.min(30, limit))) as unknown as BackupRecord[];
}

export async function createDatabaseBackup(
  createdBy: number | null = null,
  notes: string = 'manual'
): Promise<{ success: boolean; backup?: BackupRecord; error?: string }> {
  const db = getDb();
  const dbPath = getDatabasePath();
  if (dbPath === ':memory:') {
    return { success: false, error: 'پشتیبان‌گیری روی دیتابیس موقت حافظه پشتیبانی نمی‌شود.' };
  }

  const backupsDir = getBackupsDir();
  ensureSecureDirectory(backupsDir);

  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const fileName = `bot-backup-${stamp}.db`;
  const targetPath = path.join(backupsDir, fileName);

  try {
    await sqliteBackup(db, targetPath);
    secureFilePermissions(targetPath);

    // Integrity verification
    const verifyDb = new DatabaseSync(targetPath, { readOnly: true });
    try {
      const chk = verifyDb.prepare('PRAGMA integrity_check;').get() as { integrity_check: string } | undefined;
      if (!chk || chk.integrity_check !== 'ok') {
        throw new Error('تست سلامت فایل پشتیبان (integrity_check) ناموفق بود.');
      }
    } finally {
      verifyDb.close();
    }

    const sizeBytes = fs.statSync(targetPath).size;
    const now = new Date().toISOString();
    const res = db
      .prepare(
        `INSERT INTO backups (file_name, file_path, size_bytes, status, created_by, notes, created_at)
         VALUES (?, ?, ?, 'success', ?, ?, ?)`
      )
      .run(fileName, targetPath, sizeBytes, createdBy, notes.slice(0, 120), now);

    lastBackupAtIso = now;
    lastBackupStatus = 'success';

    // Prune old backups beyond 20 files
    try {
      const oldRows = db
        .prepare('SELECT id, file_path FROM backups ORDER BY id DESC LIMIT -1 OFFSET 20')
        .all() as Array<{ id: number; file_path: string }>;
      for (const old of oldRows) {
        if (old.file_path && fs.existsSync(old.file_path)) {
          try {
            fs.unlinkSync(old.file_path);
          } catch {}
        }
        db.prepare('DELETE FROM backups WHERE id = ?').run(old.id);
      }
    } catch {}

    const record = db
      .prepare('SELECT * FROM backups WHERE id = ?')
      .get(Number(res.lastInsertRowid)) as unknown as BackupRecord;
    return { success: true, backup: record };
  } catch (err: any) {
    lastBackupStatus = 'failed';
    try {
      db.prepare(
        `INSERT INTO backups (file_name, file_path, size_bytes, status, created_by, notes, created_at)
         VALUES (?, ?, 0, 'failed', ?, ?, ?)`
      ).run(fileName, targetPath, createdBy, String(err?.message || notes).slice(0, 120), new Date().toISOString());
    } catch {}
    return { success: false, error: err?.message || 'خطا در تهیه نسخه پشتیبان' };
  }
}

export async function restoreDatabaseBackup(
  backupId: number,
  actorId: number
): Promise<{ success: boolean; message: string }> {
  const db = getDb();
  const dbPath = getDatabasePath();
  const row = db.prepare('SELECT * FROM backups WHERE id = ?').get(backupId) as unknown as BackupRecord | undefined;
  if (!row || row.status !== 'success') {
    return { success: false, message: 'نسخه پشتیبان معتبر یافت نشد.' };
  }

  const backupsDir = getBackupsDir();
  const resolvedBackup = path.resolve(row.file_path);
  if (!resolvedBackup.startsWith(backupsDir + path.sep) || !fs.existsSync(resolvedBackup)) {
    return { success: false, message: 'فایل فیزیکی پشتیبان در سرور یافت نشد.' };
  }

  // Verify integrity before touching live database
  const testDb = new DatabaseSync(resolvedBackup, { readOnly: true });
  try {
    const chk = testDb.prepare('PRAGMA integrity_check;').get() as { integrity_check: string } | undefined;
    if (!chk || chk.integrity_check !== 'ok') {
      return { success: false, message: 'فایل پشتیبان خراب است و بازیابی لغو شد.' };
    }
  } finally {
    testDb.close();
  }

  // Take a pre-restore safety snapshot first
  await createDatabaseBackup(actorId, `pre-restore-safety-before-${backupId}`);

  closeDb();
  try {
    for (const suffix of ['', '-wal', '-shm']) {
      if (suffix && fs.existsSync(`${dbPath}${suffix}`)) {
        fs.unlinkSync(`${dbPath}${suffix}`);
      }
    }
    fs.copyFileSync(resolvedBackup, dbPath);
    secureFilePermissions(dbPath);
    getDb();
    recordAuditLog({
      actorId,
      action: 'restore_backup',
      section: 'backup',
      oldValue: null,
      newValue: `backup#${backupId}:${row.file_name}`,
      result: 'success',
    });
    return { success: true, message: `دیتابیس با موفقیت از نسخه ${row.file_name} بازیابی شد.` };
  } catch (err: any) {
    getDb();
    return { success: false, message: `خطا در بازیابی دیتابیس: ${err?.message || 'نامشخص'}` };
  }
}

export function vacuumDatabase(): { success: boolean; sizeBytes: number } {
  const db = getDb();
  const dbPath = getDatabasePath();
  db.exec('PRAGMA wal_checkpoint(TRUNCATE); VACUUM;');
  const sizeBytes = dbPath !== ':memory:' && fs.existsSync(dbPath) ? fs.statSync(dbPath).size : 0;
  return { success: true, sizeBytes };
}

export function shouldSendAlert(alertKey: string, cooldownMs: number = 15 * 60_000): boolean {
  try {
    const db = getDb();
    const now = Date.now();
    const existing = db
      .prepare('SELECT last_sent_at, count FROM alerts_history WHERE alert_key = ?')
      .get(alertKey) as { last_sent_at: number; count: number } | undefined;

    if (existing && now - Number(existing.last_sent_at) < cooldownMs) {
      return false;
    }

    db.prepare(
      `INSERT INTO alerts_history (alert_key, last_sent_at, count)
       VALUES (?, ?, 1)
       ON CONFLICT(alert_key) DO UPDATE SET
         last_sent_at = excluded.last_sent_at,
         count = count + 1`
    ).run(alertKey, now);
    return true;
  } catch {
    return true;
  }
}
