import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extractUrl,
  identifyPlatform,
  formatDuration,
  formatFileSize,
  parseSongInfoFromText,
  evaluateWebhookCheckStatus,
} from './mediaParser';

test('extractUrl finds HTTP/HTTPS URLs inside message text', () => {
  assert.equal(
    extractUrl('سلام این لینک رو دانلود کن https://open.spotify.com/track/7qiZfU4dY1lWllzX7mPBI3 ممنون'),
    'https://open.spotify.com/track/7qiZfU4dY1lWllzX7mPBI3'
  );
  assert.equal(extractUrl('بدون لینک'), null);
});

test('identifyPlatform detects Instagram, Spotify (including intl), YouTube, and TikTok', () => {
  const ig = identifyPlatform('https://www.instagram.com/reel/C8abc123/?igsh=xyz');
  assert.equal(ig.platform, 'instagram');
  assert.equal(ig.cleanUrl, 'https://www.instagram.com/reel/C8abc123/');

  const sp = identifyPlatform('https://open.spotify.com/intl-de/track/7qiZfU4dY1lWllzX7mPBI3?si=123');
  assert.equal(sp.platform, 'spotify');
  assert.equal(sp.cleanUrl, 'https://open.spotify.com/intl-de/track/7qiZfU4dY1lWllzX7mPBI3');

  const yt = identifyPlatform('https://youtu.be/dQw4w9WgXcQ?t=10');
  assert.equal(yt.platform, 'youtube');
  assert.equal(yt.cleanUrl, 'https://www.youtube.com/watch?v=dQw4w9WgXcQ');
});

test('formatDuration and formatFileSize format numbers accurately', () => {
  assert.equal(formatDuration(125), '2:05');
  assert.equal(formatDuration(3665), '1:01:05');
  assert.equal(formatFileSize(5 * 1024 * 1024), '5.0 MB');
});

test('parseSongInfoFromText splits Artist - Title patterns', () => {
  const parsed = parseSongInfoFromText('Wantons - Fada Saret (Official Audio)');
  assert.equal(parsed.artist, 'Wantons');
  assert.equal(parsed.title, 'Fada Saret');
  assert.equal(parsed.confidence, 'medium');
});

test('evaluateWebhookCheckStatus rejects 302, 401, and 405 and accepts 200', () => {
  assert.equal(evaluateWebhookCheckStatus(200).valid, true);
  assert.equal(evaluateWebhookCheckStatus(302).valid, false);
  assert.equal(evaluateWebhookCheckStatus(401).valid, false);
  assert.equal(evaluateWebhookCheckStatus(405).valid, false);
});

test('isUserAdmin accepts SUPER_ADMIN_ID 567645818 and rejects non-admin IDs', async () => {
  const { isUserAdmin, SUPER_ADMIN_ID } = await import('./configManager.ts');
  assert.equal(SUPER_ADMIN_ID, 567645818);
  assert.equal(isUserAdmin(567645818), true);
  assert.equal(isUserAdmin('567645818'), true);
  assert.equal(isUserAdmin(123456789), false);
  assert.equal(isUserAdmin('invalid_user'), false);
});

test('saveYoutubeCookies and clearYoutubeCookies correctly manage cookie files', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const cookiePath = path.resolve(process.cwd(), 'youtube_cookies.txt');
  const existing = fs.existsSync(cookiePath) ? fs.readFileSync(cookiePath, 'utf-8') : null;

  const { saveYoutubeCookies, hasYoutubeCookies, clearYoutubeCookies } = await import('./mediaDownloader.ts');
  clearYoutubeCookies();
  assert.equal(hasYoutubeCookies(), false);

  const saveRes = saveYoutubeCookies('# Netscape HTTP Cookie File\n.youtube.com\tTRUE\t/\tTRUE\t2147483647\tSID\tsample_sid\n');
  assert.equal(saveRes.success, true);
  assert.equal(hasYoutubeCookies(), true);

  if (existing) {
    saveYoutubeCookies(existing);
  } else {
    clearYoutubeCookies();
  }
});

test('extractDynamicQualityOptions filters available tiers and estimates file sizes', async () => {
  const { extractDynamicQualityOptions } = await import('./mediaParser.ts');

  const mockFormats = [
    { format_id: '18', height: 360, vcodec: 'avc1', acodec: 'mp4a', filesize: 5 * 1024 * 1024 },
    { format_id: '137', height: 1080, vcodec: 'avc1', acodec: 'none', filesize: 20 * 1024 * 1024 },
    { format_id: '140', height: undefined, vcodec: 'none', acodec: 'mp4a', filesize: 3 * 1024 * 1024 }
  ];

  const opts = extractDynamicQualityOptions(mockFormats, 60, 'youtube');
  const ids = opts.map(o => o.id);

  assert.ok(ids.includes('best_1080'), 'Should include 1080p since height 1080 is present');
  assert.ok(ids.includes('best_360'), 'Should include 360p since height 360 is present');
  assert.ok(!ids.includes('best_720'), 'Should NOT include 720p since height 720 is missing');
  assert.ok(ids.includes('best_audio'), 'Should include audio option');

  const songOpt = opts.find(o => o.id === 'find_song');
  assert.ok(songOpt, 'Should include find_song option');
  assert.equal(songOpt?.labelFa, '🎵 تشخیص موزیک', 'Label must be explicitly 🎵 تشخیص موزیک');
});

test('renderProgressBar and toPersianDigits render live progress accurately', async () => {
  const { renderProgressBar, toPersianDigits, formatDownloadLoadingText } = await import('./mediaParser.ts');

  assert.equal(toPersianDigits('65%'), '۶۵%');
  assert.equal(toPersianDigits('00:04'), '۰۰:۰۴');

  assert.equal(renderProgressBar(0, 10), '▱▱▱▱▱▱▱▱▱▱');
  assert.equal(renderProgressBar(50, 10), '▰▰▰▰▰▱▱▱▱▱');
  assert.equal(renderProgressBar(100, 10), '▰▰▰▰▰▰▰▰▰▰');

  const loadingText = formatDownloadLoadingText({
    percent: 65,
    downloadedFormatted: '6.5 MB',
    totalFormatted: '10.0 MB',
    speedFormatted: '3.2 MB/s',
    etaFormatted: '00:03',
  });

  assert.ok(loadingText.includes('۶۵٪'), 'Should contain Persian percent');
  assert.ok(loadingText.includes('▰▰▰▰▰▰▰▱▱▱'), 'Should contain progress bar');
  assert.ok(loadingText.includes('3.2 MB/s'), 'Should contain download speed');
  assert.ok(loadingText.includes('۰۰:۰۳'), 'Should contain Persian ETA');
  assert.ok(loadingText.includes('وضعیت:'), 'Should contain dynamic status line');
  assert.ok(loadingText.includes('⏳') || loadingText.includes('⌛'), 'Should contain rotating hourglass emoji');

  const songLoading = formatDownloadLoadingText({
    percent: 30,
    isSongFinder: true,
  });
  assert.ok(songLoading.includes('تشخیص و استخراج موزیک'), 'Should show song finder title');
  assert.ok(songLoading.includes('وضعیت:'), 'Should show status line in song finder');
});

test('cleanOldDownloads runs safely and extractInstagramAudio is exported', async () => {
  const { cleanOldDownloads, extractInstagramAudio } = await import('./mediaDownloader.ts');
  assert.equal(typeof cleanOldDownloads, 'function');
  assert.equal(typeof extractInstagramAudio, 'function');

  // Should run without throwing errors
  assert.doesNotThrow(() => {
    cleanOldDownloads();
  });
});

test('validateSafeHttpUrl permits public HTTP/HTTPS URLs and blocks SSRF/local/file targets', async () => {
  const { validateSafeHttpUrl } = await import('./mediaDownloader.ts');

  assert.equal(
    validateSafeHttpUrl('https://www.instagram.com/reel/C8abc123/'),
    'https://www.instagram.com/reel/C8abc123/'
  );
  assert.equal(
    validateSafeHttpUrl('http://youtu.be/dQw4w9WgXcQ'),
    'http://youtu.be/dQw4w9WgXcQ'
  );

  assert.throws(() => validateSafeHttpUrl('file:///etc/passwd'));
  assert.throws(() => validateSafeHttpUrl('http://127.0.0.1:3000/api/config'));
  assert.throws(() => validateSafeHttpUrl('http://localhost:3000'));
  assert.throws(() => validateSafeHttpUrl('http://169.254.169.254/latest/meta-data/'));
  assert.throws(() => validateSafeHttpUrl('http://10.0.0.1/admin'));
  assert.throws(() => validateSafeHttpUrl('http://192.168.1.1'));
  assert.throws(() => validateSafeHttpUrl('http://[::1]:3000'));
});

test('normalizeChannelIdentifier handles @username, URLs, private post links, numeric IDs, and invite links', async () => {
  const { normalizeChannelIdentifier } = await import('./mediaParser.ts');

  assert.equal(normalizeChannelIdentifier('@MyChannel').chatId, '@MyChannel');
  assert.equal(normalizeChannelIdentifier('MyChannel').chatId, '@MyChannel');
  assert.equal(normalizeChannelIdentifier('https://t.me/MyChannel').chatId, '@MyChannel');
  assert.equal(normalizeChannelIdentifier('https://t.me/MyChannel/42').chatId, '@MyChannel');
  assert.equal(normalizeChannelIdentifier('https://t.me/c/2123456789/15').chatId, '-1002123456789');
  assert.equal(normalizeChannelIdentifier('-1001234567890').chatId, '-1001234567890');
  assert.equal(normalizeChannelIdentifier('1234567890').chatId, '-1001234567890');

  const inv = normalizeChannelIdentifier('https://t.me/+AbCdEf123');
  assert.equal(inv.chatId, '');
  assert.equal(inv.isInviteLink, true);
  assert.ok(inv.error);
});

test('isTelegramChatMemberStatusJoined accurately classifies member vs left/kicked/restricted states', async () => {
  const { isTelegramChatMemberStatusJoined, isChannelAdminConfigError } = await import('./mediaParser.ts');

  assert.equal(isTelegramChatMemberStatusJoined({ status: 'creator' }), true);
  assert.equal(isTelegramChatMemberStatusJoined({ status: 'administrator' }), true);
  assert.equal(isTelegramChatMemberStatusJoined({ status: 'member' }), true);
  assert.equal(isTelegramChatMemberStatusJoined({ status: 'restricted', is_member: true }), true);

  assert.equal(isTelegramChatMemberStatusJoined({ status: 'restricted', is_member: false }), false);
  assert.equal(isTelegramChatMemberStatusJoined({ status: 'left' }), false);
  assert.equal(isTelegramChatMemberStatusJoined({ status: 'kicked' }), false);
  assert.equal(isTelegramChatMemberStatusJoined(null), false);

  assert.equal(isChannelAdminConfigError('Bad Request: member list is inaccessible'), true);
  assert.equal(isChannelAdminConfigError('Forbidden: bot was kicked from the channel chat'), true);
  assert.equal(isChannelAdminConfigError('Bad Request: chat not found'), true);
  assert.equal(isChannelAdminConfigError('Network timeout'), false);
});

test('extractInstagramShortcode, isInstagramCookieRejectionError, and parseInstagramEmbedHtml work accurately', async () => {
  const {
    extractInstagramShortcode,
    isInstagramCookieRejectionError,
    parseInstagramEmbedHtml,
  } = await import('./mediaParser.ts');

  assert.equal(extractInstagramShortcode('https://www.instagram.com/reel/DZ5hnsPNjRo/?igsh=abc'), 'DZ5hnsPNjRo');
  assert.equal(extractInstagramShortcode('https://instagram.com/p/C9xyz12345/'), 'C9xyz12345');
  assert.equal(extractInstagramShortcode('https://www.youtube.com/watch?v=123'), null);

  assert.equal(
    isInstagramCookieRejectionError('ERROR: [Instagram] DZ5hnsPNjRo: Failed to parse JSON (caused by JSONDecodeError("Expecting value in \'\': line 1 column 1 (char 0)"))'),
    true
  );
  assert.equal(isInstagramCookieRejectionError('HTTP Error 401: Unauthorized / login_required'), true);
  assert.equal(isInstagramCookieRejectionError('Network timeout occurred'), false);

  const videoHtml = `
    <html>
      <span class="UsernameText">demo_creator</span>
      <div class="Caption">Cool reel caption</div>
      <script>
        {"video_url":"https:\\/\\/scontent.cdninstagram.com\\/v\\/reel_1.mp4?a=1\\u0026b=2","display_url":"https:\\/\\/scontent.cdninstagram.com\\/v\\/cover.jpg"}
      </script>
      <img class="EmbeddedMediaImage" src="https://static.cdninstagram.com/rsrc.php/icon.png" />
    </html>
  `;
  const parsedVideo = parseInstagramEmbedHtml(videoHtml);
  assert.equal(parsedVideo.uploader, 'demo_creator');
  assert.equal(parsedVideo.caption, 'Cool reel caption');
  assert.equal(parsedVideo.mediaUrls.length, 1);
  assert.equal(parsedVideo.mediaUrls[0].type, 'video');
  assert.equal(parsedVideo.mediaUrls[0].url, 'https://scontent.cdninstagram.com/v/reel_1.mp4?a=1&b=2');

  const photoHtml = `
    <html>
      <img class="EmbeddedMediaImage" src="https://scontent.cdninstagram.com/v/photo_1.jpg?x=1&amp;y=2" />
    </html>
  `;
  const parsedPhoto = parseInstagramEmbedHtml(photoHtml);
  assert.equal(parsedPhoto.mediaUrls.length, 1);
  assert.equal(parsedPhoto.mediaUrls[0].type, 'photo');
  assert.equal(parsedPhoto.mediaUrls[0].url, 'https://scontent.cdninstagram.com/v/photo_1.jpg?x=1&y=2');
});

test('saveInstagramSession rejects placeholders and does not resurrect invalidated env cookies', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const cookiePath = path.resolve(process.cwd(), 'instagram_cookies.txt');
  const markerPath = path.resolve('/tmp/ig_invalid_cookie.sha256');
  const existing = fs.existsSync(cookiePath) ? fs.readFileSync(cookiePath, 'utf-8') : null;
  const existingMarker = fs.existsSync(markerPath) ? fs.readFileSync(markerPath, 'utf-8') : null;

  const {
    saveInstagramSession,
    hasInstagramCookies,
    clearInstagramCookies,
    invalidateBadInstagramCookies,
  } = await import('./mediaDownloader.ts');

  try {
    assert.equal(saveInstagramSession('your_session_id', { source: 'env' }).success, false);
    assert.equal(saveInstagramSession('short', { source: 'manual' }).success, false);

    const sampleSession = '12345678901%3AabcdefABCDEF12%3A27%3AAYcTestToken';
    assert.equal(saveInstagramSession(sampleSession, { source: 'manual' }).success, true);
    assert.equal(hasInstagramCookies(), true);

    invalidateBadInstagramCookies();
    assert.equal(hasInstagramCookies(), false);

    // Same env cookie must stay rejected and not be re-written automatically
    const envRetry = saveInstagramSession(sampleSession, { source: 'env' });
    assert.equal(envRetry.success, false);
    assert.equal(hasInstagramCookies(), false);

    // A fresh manual update clears the block and saves
    const manualFresh = saveInstagramSession('99887766554%3AfreshToken999%3A10%3AAYcFreshToken', { source: 'manual' });
    assert.equal(manualFresh.success, true);
    assert.equal(hasInstagramCookies(), true);
  } finally {
    clearInstagramCookies();
    if (existing) {
      fs.writeFileSync(cookiePath, existing, { encoding: 'utf-8', mode: 0o600 });
    }
    if (existingMarker !== null) {
      fs.writeFileSync(markerPath, existingMarker, { encoding: 'utf-8', mode: 0o600 });
    } else if (fs.existsSync(markerPath)) {
      fs.unlinkSync(markerPath);
    }
  }
});
