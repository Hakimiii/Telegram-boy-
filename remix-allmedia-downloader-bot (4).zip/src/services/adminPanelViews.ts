import {
  SUPER_ADMIN_ID,
  ALL_ADMIN_PERMISSIONS,
  PERMISSION_LABELS_FA,
  ROLE_LABELS_FA,
  ROLE_RANK,
  loadBotConfig,
  listAdmins,
  getAdminRecord,
  getUsersStatsSummary,
  getActiveUsersList,
  getUserProfile,
  getUserRequestHistory,
  getRecentDownloaderErrors,
  type AdminPermission,
  type AdminRecord,
} from './configManager.ts';
import {
  getRecentAuditLogs,
  listBackups,
  getLastBackupSummary,
  countUnauthorizedAttempts,
} from './database.ts';
import {
  getServerMetrics,
  checkServicesConnectivity,
  type ServerMetricsSnapshot,
} from './controlService.ts';
import {
  inspectSecretsStatus,
  checkSecretSecurityWarnings,
  getAwsIntegrationConfig,
} from './secretsManager.ts';
import {
  hasInstagramCookies,
  hasYoutubeCookies,
  listActiveDownloads,
} from './mediaDownloader.ts';

export function escHtml(str: unknown): string {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function formatUptimeFa(seconds: number): string {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (d > 0) return `${d} روز و ${h} ساعت و ${m} دقیقه`;
  if (h > 0) return `${h} ساعت و ${m} دقیقه و ${s} ثانیه`;
  return `${m} دقیقه و ${s} ثانیه`;
}

export function renderMainMenuView(actor: AdminRecord): { text: string; keyboard: any[][] } {
  const cfg = loadBotConfig();
  const metrics = getServerMetrics();
  const userStats = getUsersStatsSummary();

  const botStateLabel = !cfg.general.botEnabled
    ? '🔴 خاموش (توسط مدیر)'
    : cfg.general.maintenanceMode
    ? '🟡 حالت تعمیرات'
    : metrics.botActive
    ? '🟢 فعال و آماده'
    : '🟠 در حال اتصال';

  const text =
`👑 <b>پنل مدیریت حرفه‌ای Telegram-boy-</b>
━━━━━━━━━━━━━━━━━━━━
👤 <b>مدیر:</b> <code>${actor.userId}</code>
🛡 <b>نقش شما:</b> ${ROLE_LABELS_FA[actor.role]}
🤖 <b>وضعیت ربات:</b> ${botStateLabel}
📥 <b>سرویس دانلود:</b> ${metrics.downloaderEnabled ? '🟢 فعال' : '🔴 متوقف'} (${metrics.activeDownloadsCount} فعال)
🎧 <b>سرویس Spotify:</b> ${cfg.spotify.enabled ? '🟢 فعال' : '🔴 غیرفعال'}
👥 <b>کاربران:</b> ${userStats.totalUsers.toLocaleString('fa-IR')} نفر (فعال ۲۴ساعت: ${userStats.active24h.toLocaleString('fa-IR')})
💾 <b>RAM / دیسک آزاد:</b> ${metrics.ramRssMb} MB / ${metrics.diskFreeMb !== null ? `${metrics.diskFreeMb} MB` : 'نامشخص'}

👇 <i>بخش مورد نظر را انتخاب کنید:</i>`;

  const can = (p: AdminPermission) => actor.role === 'owner' || actor.permissions.includes(p);

  const keyboard: any[][] = [];
  const row1: any[] = [];
  if (can('general')) row1.push({ text: '⚙️ تنظیمات عمومی', callback_data: 'adm:sec:general' });
  if (can('download')) row1.push({ text: '🎵 مدیریت دانلود', callback_data: 'adm:sec:download' });
  if (row1.length) keyboard.push(row1);

  const row2: any[] = [];
  if (can('spotify')) row2.push({ text: '🎧 تنظیمات Spotify', callback_data: 'adm:sec:spotify' });
  if (can('users')) row2.push({ text: '👥 مدیریت کاربران', callback_data: 'adm:sec:users' });
  if (row2.length) keyboard.push(row2);

  const row3: any[] = [];
  if (can('security')) row3.push({ text: '🛡 امنیت و دسترسی', callback_data: 'adm:sec:security' });
  if (can('admins')) row3.push({ text: '👨‍💻 مدیریت مدیران', callback_data: 'adm:sec:admins' });
  if (row3.length) keyboard.push(row3);

  const row4: any[] = [];
  if (can('server')) row4.push({ text: '🖥 وضعیت سرور', callback_data: 'adm:sec:server' });
  if (can('stats')) row4.push({ text: '📊 آمار و گزارشات', callback_data: 'adm:sec:stats' });
  if (row4.length) keyboard.push(row4);

  const row5: any[] = [];
  if (can('backup')) row5.push({ text: '💾 پشتیبان‌گیری', callback_data: 'adm:sec:backup' });
  if (can('maintenance') || can('forcejoin') || can('cookies')) {
    row5.push({ text: '🔧 ابزارهای تعمیر و نگهداری', callback_data: 'adm:sec:maintenance' });
  }
  if (row5.length) keyboard.push(row5);

  keyboard.push([
    { text: '🔄 بروزرسانی پنل', callback_data: 'adm:refresh' },
    { text: '❌ بستن پنل', callback_data: 'adm:close' },
  ]);

  return { text, keyboard };
}

export function renderGeneralSettingsView(): { text: string; keyboard: any[][] } {
  const cfg = loadBotConfig();
  const g = cfg.general;

  const text =
`⚙️ <b>تنظیمات عمومی ربات</b>
━━━━━━━━━━━━━━━━━━━━
• <b>ربات (برای کاربران):</b> ${g.botEnabled ? '🟢 روشن' : '🔴 خاموش'}
• <b>ثبت‌نام کاربران جدید:</b> ${g.allowNewRegistrations ? '🟢 فعال' : '🔴 غیرفعال'}
• <b>سرویس دانلود:</b> ${g.downloadsServiceEnabled ? '🟢 فعال' : '🔴 غیرفعال'}
• <b>حالت تعمیرات:</b> ${g.maintenanceMode ? '🟡 فعال' : '⚪ غیرفعال'}
• <b>اطلاع‌رسانی تغییرات:</b> ${g.notifyOnChanges ? '🟢 فعال' : '🔴 غیرفعال'}

📢 <b>کانال/گروه اطلاع‌رسانی:</b> ${g.notifyChannelId ? `<code>${escHtml(g.notifyChannelId)}</code>` : 'فقط مالک اصلی'}
🌐 <b>لینک کانال اصلی:</b> ${cfg.mainChannelUrl ? escHtml(cfg.mainChannelUrl) : 'ثبت نشده'}
🎫 <b>آیدی پشتیبانی:</b> @${escHtml(cfg.supportUsername || 'admin')}
👋 <b>پیام خوشامدگویی:</b> ${g.welcomeMessage ? 'سفارشی ثبت شده ✅' : 'پیش‌فرض ربات'}
📖 <b>متن راهنما:</b> ${g.helpMessage ? 'سفارشی ثبت شده ✅' : 'پیش‌فرض ربات'}
⚠️ <b>پیام خطا:</b> <i>${escHtml(g.errorMessage.slice(0, 70))}</i>`;

  const keyboard = [
    [
      { text: `${g.botEnabled ? '🟢' : '🔴'} ربات: ${g.botEnabled ? 'روشن' : 'خاموش'}`, callback_data: 'adm:gen:t_bot' },
      { text: `${g.allowNewRegistrations ? '🟢' : '🔴'} ثبت‌نام جدید`, callback_data: 'adm:gen:t_reg' },
    ],
    [
      { text: `${g.downloadsServiceEnabled ? '🟢' : '🔴'} سرویس دانلود`, callback_data: 'adm:gen:t_dl' },
      { text: `${g.maintenanceMode ? '🟡' : '⚪'} حالت تعمیرات`, callback_data: 'adm:gen:t_maint' },
    ],
    [
      { text: `${g.notifyOnChanges ? '🟢' : '🔴'} اعلان تغییرات`, callback_data: 'adm:gen:t_notify' },
      { text: '🔒 قفل عضویت اجباری', callback_data: 'adm:forcejoin' },
    ],
    [
      { text: '👋 ویرایش خوشامدگویی', callback_data: 'adm:gen:edit:welcome' },
      { text: '📖 ویرایش متن راهنما', callback_data: 'adm:gen:edit:help' },
    ],
    [
      { text: '⚠️ ویرایش پیام خطا', callback_data: 'adm:gen:edit:error' },
      { text: '🎫 ویرایش پیام پشتیبانی', callback_data: 'adm:gen:edit:support_msg' },
    ],
    [
      { text: '🔧 متن حالت تعمیرات', callback_data: 'adm:gen:edit:maint_msg' },
      { text: '📢 کانال اطلاع‌رسانی', callback_data: 'adm:gen:edit:notify_ch' },
    ],
    [
      { text: '🌐 لینک کانال اصلی', callback_data: 'adm:set_main_ch' },
      { text: '👤 آیدی پشتیبانی', callback_data: 'adm:set_support' },
    ],
    [{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }],
  ];

  return { text, keyboard };
}

export function renderDownloadSettingsView(): { text: string; keyboard: any[][] } {
  const cfg = loadBotConfig();
  const d = cfg.download;
  const active = listActiveDownloads();

  const text =
`🎵 <b>مدیریت و تنظیمات دانلود</b>
━━━━━━━━━━━━━━━━━━━━
• <b>وضعیت دانلود:</b> ${d.enabled && cfg.general.downloadsServiceEnabled ? '🟢 فعال' : '🔴 غیرفعال'}
• <b>دانلودهای در حال اجرا:</b> ${active.length} مورد
• <b>حداکثر حجم فایل:</b> <code>${d.maxFileSizeMb} MB</code> (۵ تا ۲۰۰۰)
• <b>حداکثر زمان دانلود:</b> <code>${d.maxDownloadTimeSec} ثانیه</code> (۱۵ تا ۹۰۰)
• <b>تعداد دانلود همزمان:</b> <code>${d.maxConcurrentDownloads}</code> (۱ تا ۱۰)
• <b>محدودیت روزانه هر کاربر:</b> <code>${d.dailyLimitPerUser === 0 ? 'نامحدود (۰)' : `${d.dailyLimitPerUser} فایل`}</code>
• <b>فرمت خروجی پیش‌فرض:</b> <code>${d.outputFormat.toUpperCase()}</code>
• <b>کیفیت پیش‌فرض:</b> <code>${d.defaultQuality}</code>
• <b>مسیر ذخیره فایل‌ها:</b> <code>${escHtml(d.storagePath)}</code>
• <b>نگهداری فایل‌های موقت:</b> <code>${d.tempRetentionMinutes} دقیقه</code>`;

  const keyboard = [
    [
      { text: `${d.enabled ? '🟢' : '🔴'} وضعیت دانلود`, callback_data: 'adm:dl:t_enabled' },
      { text: `📦 سقف حجم (${d.maxFileSizeMb}MB)`, callback_data: 'adm:dl:edit:maxFileSizeMb' },
    ],
    [
      { text: `⏱ سقف زمان (${d.maxDownloadTimeSec}s)`, callback_data: 'adm:dl:edit:maxDownloadTimeSec' },
      { text: `⚡ همزمانی (${d.maxConcurrentDownloads})`, callback_data: 'adm:dl:edit:maxConcurrentDownloads' },
    ],
    [
      { text: `📅 محدودیت روزانه (${d.dailyLimitPerUser})`, callback_data: 'adm:dl:edit:dailyLimitPerUser' },
      { text: `🕒 نگهداری موقت (${d.tempRetentionMinutes}m)`, callback_data: 'adm:dl:edit:tempRetentionMinutes' },
    ],
    [
      { text: `🎞 فرمت خروجی: ${d.outputFormat.toUpperCase()}`, callback_data: 'adm:dl:cycle_fmt' },
      { text: `🎬 کیفیت پیش‌فرض: ${d.defaultQuality}`, callback_data: 'adm:dl:cycle_qual' },
    ],
    [
      { text: '📁 تغییر مسیر ذخیره', callback_data: 'adm:dl:edit:storagePath' },
      { text: '🧹 پاکسازی فایل‌های موقت', callback_data: 'adm:dl:clean_ask' },
    ],
    [
      { text: `⏳ دانلودهای فعال (${active.length})`, callback_data: 'adm:dl:active' },
      { text: '❌ خطاهای دانلود', callback_data: 'adm:dl:errors' },
    ],
    [{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }],
  ];

  return { text, keyboard };
}

export function renderActiveDownloadsView(): { text: string; keyboard: any[][] } {
  const active = listActiveDownloads();
  let text = `⏳ <b>وضعیت دانلودهای فعال (${active.length})</b>\n━━━━━━━━━━━━━━━━━━━━\n`;
  const keyboard: any[][] = [];

  if (active.length === 0) {
    text += '<i>در حال حاضر هیچ دانلود فعالی در صف اجرا نیست.</i>';
  } else {
    for (const item of active.slice(0, 10)) {
      const elapsedSec = Math.floor((Date.now() - item.startedAt) / 1000);
      text += `\n• 🆔 <code>${item.id}</code> | ${escHtml(item.platform)} | پیشرفت: <b>${item.percent}%</b> | زمان: ${elapsedSec}s`;
      if (item.userId) text += ` | کاربر: <code>${item.userId}</code>`;
      keyboard.push([
        { text: `🛑 لغو دانلود ${item.id} (${item.platform})`, callback_data: `adm:dl:cancel:${item.id}` },
      ]);
    }
  }

  keyboard.push([
    { text: '🔄 بروزرسانی', callback_data: 'adm:dl:active' },
    { text: '🔙 بازگشت به مدیریت دانلود', callback_data: 'adm:sec:download' },
  ]);

  return { text, keyboard };
}

export function renderDownloadErrorsView(platform?: string): { text: string; keyboard: any[][] } {
  const errors = getRecentDownloaderErrors(platform, 10);
  const title = platform === 'spotify' ? '❌ خطاهای اخیر Spotify' : '❌ خطاهای اخیر دانلودر';
  let text = `<b>${title}</b>\n━━━━━━━━━━━━━━━━━━━━\n`;

  if (errors.length === 0) {
    text += '✅ <i>هیچ خطای اخیری ثبت نشده است.</i>';
  } else {
    text += errors
      .map(
        (e, i) =>
          `${i + 1}. <b>[${escHtml(e.platform || 'unknown')}]</b> کاربر <code>${e.userId}</code>\n   🕒 ${e.createdAt.slice(0, 19).replace('T', ' ')}\n   ⚠️ <i>${escHtml((e.errorMessage || 'خطا').slice(0, 110))}</i>`
      )
      .join('\n\n');
  }

  const backTarget = platform === 'spotify' ? 'adm:sec:spotify' : 'adm:sec:download';
  const keyboard = [
    [{ text: '🔄 بروزرسانی', callback_data: platform === 'spotify' ? 'adm:sp:errors' : 'adm:dl:errors' }],
    [{ text: '🔙 بازگشت', callback_data: backTarget }],
  ];

  return { text, keyboard };
}

export function renderSpotifySettingsView(connNote?: string): { text: string; keyboard: any[][] } {
  const s = loadBotConfig().spotify;

  const text =
`🎧 <b>تنظیمات مستقل Spotify</b>
━━━━━━━━━━━━━━━━━━━━
• <b>وضعیت سرویس Spotify:</b> ${s.enabled ? '🟢 فعال' : '🔴 غیرفعال'}
• <b>دریافت آهنگ تکی (Track):</b> ${s.allowTrack ? '🟢 مجاز' : '🔴 غیرفعال'}
• <b>دریافت آلبوم (Album):</b> ${s.allowAlbum ? '🟢 مجاز' : '🔴 غیرفعال'}
• <b>دریافت پلی‌لیست (Playlist):</b> ${s.allowPlaylist ? '🟢 مجاز' : '🔴 غیرفعال'}
• <b>کیفیت پیش‌فرض:</b> <code>${s.defaultQuality}</code>
• <b>اولویت فرمت MP3:</b> ${s.preferMp3 ? '🟢 بله (MP3)' : '⚪ M4A'}
• <b>کیفیت 320kbps در صورت در دسترس بودن منبع:</b> ${s.allow320kbpsWhenAvailable ? '🟢 فعال' : '🔴 غیرفعال'}
• <b>محدودیت ترک‌های Playlist:</b> <code>${s.maxPlaylistTracks}</code> ترک
• <b>حداکثر حجم فایل:</b> <code>${s.maxFileSizeMb} MB</code>
• <b>تعداد عملیات همزمان:</b> <code>${s.maxConcurrent}</code>
• <b>زمان Timeout:</b> <code>${s.timeoutSec} ثانیه</code>
${connNote ? `\n🌐 <b>وضعیت اتصال:</b> ${escHtml(connNote)}\n` : ''}
ℹ️ <i>توجه: لینک Spotify متادیتا را دریافت می‌کند و فایل صوتی فقط از منابع مجاز و دارای دسترس‌پذیری عمومی دریافت می‌شود؛ در صورت عدم دسترسی خطای مناسب نمایش داده می‌شود.</i>`;

  const keyboard = [
    [
      { text: `${s.enabled ? '🟢' : '🔴'} سرویس Spotify`, callback_data: 'adm:sp:t_enabled' },
      { text: `${s.allowTrack ? '🟢' : '🔴'} آهنگ تکی`, callback_data: 'adm:sp:t_track' },
    ],
    [
      { text: `${s.allowAlbum ? '🟢' : '🔴'} آلبوم`, callback_data: 'adm:sp:t_album' },
      { text: `${s.allowPlaylist ? '🟢' : '🔴'} Playlist`, callback_data: 'adm:sp:t_playlist' },
    ],
    [
      { text: `${s.preferMp3 ? '🟢' : '⚪'} فرمت MP3`, callback_data: 'adm:sp:t_mp3' },
      { text: `${s.allow320kbpsWhenAvailable ? '🟢' : '🔴'} مجاز 320kbps`, callback_data: 'adm:sp:t_320' },
    ],
    [
      { text: `🎚 کیفیت: ${s.defaultQuality}`, callback_data: 'adm:sp:cycle_qual' },
      { text: `🔢 سقف Playlist (${s.maxPlaylistTracks})`, callback_data: 'adm:sp:edit:maxPlaylistTracks' },
    ],
    [
      { text: `📦 سقف حجم (${s.maxFileSizeMb}MB)`, callback_data: 'adm:sp:edit:maxFileSizeMb' },
      { text: `⚡ همزمانی (${s.maxConcurrent})`, callback_data: 'adm:sp:edit:maxConcurrent' },
    ],
    [
      { text: `⏱ Timeout (${s.timeoutSec}s)`, callback_data: 'adm:sp:edit:timeoutSec' },
      { text: '🌐 تست اتصال Spotify', callback_data: 'adm:sp:check_conn' },
    ],
    [{ text: '❌ خطاهای Spotify', callback_data: 'adm:sp:errors' }],
    [{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }],
  ];

  return { text, keyboard };
}

export function renderUsersManagementView(): { text: string; keyboard: any[][] } {
  const stats = getUsersStatsSummary();
  const cfg = loadBotConfig();

  const text =
`👥 <b>مدیریت کامل کاربران</b>
━━━━━━━━━━━━━━━━━━━━
• <b>تعداد کل کاربران:</b> ${stats.totalUsers.toLocaleString('fa-IR')} نفر
• <b>کاربران فعال (۲۴ ساعت اخیر):</b> ${stats.active24h.toLocaleString('fa-IR')} نفر
• <b>کاربران مسدودشده:</b> ${stats.bannedUsers.toLocaleString('fa-IR')} نفر
• <b>مجموع دانلودهای ثبت‌شده:</b> ${stats.totalRecordedDownloads.toLocaleString('fa-IR')} فایل
• <b>سقف دانلود روزانه سراسری:</b> ${cfg.download.dailyLimitPerUser === 0 ? 'نامحدود' : `${cfg.download.dailyLimitPerUser} فایل`}

👇 <i>عملیات مورد نظر را انتخاب کنید:</i>`;

  const keyboard = [
    [
      { text: '🔍 جستجوی کاربر با Telegram ID', callback_data: 'adm:usr:search' },
      { text: '🟢 لیست کاربران فعال', callback_data: 'adm:usr:active' },
    ],
    [
      { text: '📢 ارسال پیام همگانی (Broadcast)', callback_data: 'adm:broadcast' },
      { text: '✉️ پیام به کاربر خاص', callback_data: 'adm:dm' },
    ],
    [
      { text: '📅 مدیریت محدودیت روزانه', callback_data: 'adm:dl:edit:dailyLimitPerUser' },
      { text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' },
    ],
  ];

  return { text, keyboard };
}

export function renderActiveUsersListView(): { text: string; keyboard: any[][] } {
  const users = getActiveUsersList(48, 12);
  let text = `🟢 <b>کاربران فعال اخیر (${users.length})</b>\n━━━━━━━━━━━━━━━━━━━━\n`;
  const keyboard: any[][] = [];

  if (users.length === 0) {
    text += '<i>هیچ کاربری در ۴۸ ساعت اخیر فعال نبوده است.</i>';
  } else {
    for (const u of users) {
      const statusIcon = u.isBanned ? '🚫' : '🟢';
      const namePart = u.firstName ? ` (${escHtml(u.firstName)})` : '';
      text += `${statusIcon} <code>${u.userId}</code>${namePart} — دانلود: ${u.totalDownloads} | امروز: ${u.dailyCount}\n`;
      keyboard.push([
        {
          text: `${statusIcon} پروفایل ${u.userId}${u.firstName ? ` - ${u.firstName.slice(0, 14)}` : ''}`,
          callback_data: `adm:usr:view:${u.userId}`,
        },
      ]);
    }
  }

  keyboard.push([{ text: '🔙 بازگشت به مدیریت کاربران', callback_data: 'adm:sec:users' }]);
  return { text, keyboard };
}

export function renderUserProfileView(targetUserId: number): { text: string; keyboard: any[][] } {
  const profile = getUserProfile(targetUserId);
  const cfg = loadBotConfig();
  if (!profile) {
    return {
      text: `❌ <b>کاربر با شناسه <code>${targetUserId}</code> در دیتابیس یافت نشد.</b>`,
      keyboard: [[{ text: '🔙 بازگشت به مدیریت کاربران', callback_data: 'adm:sec:users' }]],
    };
  }

  const history = getUserRequestHistory(targetUserId, 6);
  const limitLabel =
    profile.dailyLimitOverride !== null
      ? `${profile.dailyLimitOverride} (اختصاصی)`
      : cfg.download.dailyLimitPerUser > 0
      ? `${cfg.download.dailyLimitPerUser} (سراسری)`
      : 'نامحدود';

  const historyText =
    history.length === 0
      ? '<i>درخواستی ثبت نشده است.</i>'
      : history
          .map(
            (h) =>
              `• [${h.createdAt.slice(5, 16).replace('T', ' ')}] ${escHtml(h.platform || '-')} | ${escHtml(h.action)} ➔ ${h.status === 'success' ? '✅' : h.status === 'error' ? '❌' : '⏳'}`
          )
          .join('\n');

  const text =
`👤 <b>پروفایل کاربر <code>${profile.userId}</code></b>
━━━━━━━━━━━━━━━━━━━━
• <b>نام:</b> ${escHtml(profile.firstName || 'ثبت نشده')}
• <b>وضعیت حساب:</b> ${profile.isBanned ? `🚫 مسدود (${escHtml(profile.banReason || 'بدون دلیل')})` : '🟢 فعال و مجاز'}
• <b>تاریخ عضویت:</b> ${profile.joinedAt.slice(0, 19).replace('T', ' ')}
• <b>آخرین فعالیت:</b> ${profile.lastActiveAt.slice(0, 19).replace('T', ' ')}
• <b>کل درخواست‌ها:</b> ${profile.totalRequests.toLocaleString('fa-IR')}
• <b>کل دانلودها:</b> ${profile.totalDownloads.toLocaleString('fa-IR')}
• <b>مصرف امروز / سقف:</b> ${profile.dailyCount} / ${limitLabel}

📜 <b>تاریخچه درخواست‌های اخیر:</b>
${historyText}`;

  const keyboard = [
    [
      {
        text: profile.isBanned ? '✅ رفع مسدودیت کاربر' : '🚫 مسدود کردن کاربر',
        callback_data: profile.isBanned ? `adm:usr:unban_ask:${profile.userId}` : `adm:usr:ban_ask:${profile.userId}`,
      },
      { text: '📅 تنظیم محدودیت مصرف', callback_data: `adm:usr:limit:${profile.userId}` },
    ],
    [
      { text: '✉️ ارسال پیام خصوصی', callback_data: `adm:usr:dm:${profile.userId}` },
      { text: '🔄 بروزرسانی پروفایل', callback_data: `adm:usr:view:${profile.userId}` },
    ],
    [{ text: '🔙 بازگشت به مدیریت کاربران', callback_data: 'adm:sec:users' }],
  ];

  return { text, keyboard };
}

export function renderAdminsManagementView(actor: AdminRecord): { text: string; keyboard: any[][] } {
  const admins = listAdmins();
  let listText = '';
  const keyboard: any[][] = [];

  for (const a of admins) {
    const statusIcon = a.isBlocked ? '🚫 مسدود' : '🟢 فعال';
    const lastSeen = a.lastActiveAt ? a.lastActiveAt.slice(0, 16).replace('T', ' ') : 'هنوز ثبت نشده';
    listText += `\n• <code>${a.userId}</code> — <b>${ROLE_LABELS_FA[a.role]}</b> | ${statusIcon}\n  🕒 آخرین فعالیت: ${lastSeen} | مجوزها: ${a.permissions.length} بخش`;
    if (a.userId !== SUPER_ADMIN_ID && (actor.role === 'owner' || ROLE_RANK[actor.role] > ROLE_RANK[a.role])) {
      keyboard.push([
        { text: `⚙️ مدیریت ${a.userId} (${a.role})`, callback_data: `adm:adm:detail:${a.userId}` },
      ]);
    }
  }

  const text =
`👨‍💻 <b>مدیریت مدیران و سطوح دسترسی (RBAC)</b>
━━━━━━━━━━━━━━━━━━━━
🛡 شناسایی مدیران فقط بر اساس <b>Telegram User ID عددی</b> انجام می‌شود (نه Username).
${listText}`;

  keyboard.unshift([{ text: '➕ اضافه کردن مدیر جدید', callback_data: 'adm:adm:add' }]);
  keyboard.push([{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }]);

  return { text, keyboard };
}

export function renderSingleAdminDetailView(actor: AdminRecord, targetUserId: number): { text: string; keyboard: any[][] } {
  const target = getAdminRecord(targetUserId);
  if (!target) {
    return {
      text: '❌ مدیر مورد نظر یافت نشد.',
      keyboard: [[{ text: '🔙 بازگشت', callback_data: 'adm:sec:admins' }]],
    };
  }

  const text =
`👨‍💻 <b>مدیریت ادمین <code>${target.userId}</code></b>
━━━━━━━━━━━━━━━━━━━━
• <b>نقش فعلی:</b> ${ROLE_LABELS_FA[target.role]}
• <b>وضعیت:</b> ${target.isBlocked ? '🚫 مسدودشده' : '🟢 فعال'}
• <b>تاریخ ثبت:</b> ${target.createdAt.slice(0, 16).replace('T', ' ')}
• <b>آخرین فعالیت:</b> ${target.lastActiveAt ? target.lastActiveAt.slice(0, 16).replace('T', ' ') : 'نامشخص'}

🔐 <b>مجوزهای دسترسی بخش‌ها:</b>
${ALL_ADMIN_PERMISSIONS.map((p) => `${target.permissions.includes(p) ? '✅' : '⬜'} ${PERMISSION_LABELS_FA[p]}`).join('\n')}`;

  const keyboard: any[][] = [];

  if (actor.role === 'owner') {
    keyboard.push([
      { text: '⭐ ارتقا/تغییر به Super Admin', callback_data: `adm:adm:role:${target.userId}:super_admin` },
    ]);
    keyboard.push([
      { text: '🛡 تغییر به Admin', callback_data: `adm:adm:role:${target.userId}:admin` },
      { text: '🎧 تغییر به Support', callback_data: `adm:adm:role:${target.userId}:support` },
    ]);
    keyboard.push([
      {
        text: target.isBlocked ? '🟢 رفع مسدودیت مدیر' : '🚫 مسدود کردن مدیر',
        callback_data: target.isBlocked ? `adm:adm:unblock_ask:${target.userId}` : `adm:adm:block_ask:${target.userId}`,
      },
      { text: '🗑 حذف مدیر', callback_data: `adm:adm:del_ask:${target.userId}` },
    ]);
  } else {
    keyboard.push([
      { text: '🛡 تغییر به Admin', callback_data: `adm:adm:role:${target.userId}:admin` },
      { text: '🎧 تغییر به Support', callback_data: `adm:adm:role:${target.userId}:support` },
    ]);
    keyboard.push([
      { text: '🗑 حذف مدیر', callback_data: `adm:adm:del_ask:${target.userId}` },
    ]);
  }

  keyboard.push([{ text: '🔐 ویرایش مجوز هر بخش', callback_data: `adm:adm:perms:${target.userId}` }]);
  keyboard.push([{ text: '🔙 بازگشت به لیست مدیران', callback_data: 'adm:sec:admins' }]);

  return { text, keyboard };
}

export function renderAdminPermissionsView(actor: AdminRecord, targetUserId: number): { text: string; keyboard: any[][] } {
  const target = getAdminRecord(targetUserId);
  if (!target) {
    return {
      text: '❌ مدیر یافت نشد.',
      keyboard: [[{ text: '🔙 بازگشت', callback_data: 'adm:sec:admins' }]],
    };
  }

  const text =
`🔐 <b>تعیین مجوزهای بخش برای <code>${target.userId}</code></b>
━━━━━━━━━━━━━━━━━━━━
روی هر بخش کلیک کنید تا دسترسی آن برای این مدیر فعال یا غیرفعال شود:`;

  const keyboard: any[][] = [];
  const editablePerms = actor.role === 'owner'
    ? ALL_ADMIN_PERMISSIONS
    : ALL_ADMIN_PERMISSIONS.filter((p) => p !== 'secrets' && p !== 'admins');

  for (let i = 0; i < editablePerms.length; i += 2) {
    const p1 = editablePerms[i];
    const row: any[] = [
      {
        text: `${target.permissions.includes(p1) ? '✅' : '⬜'} ${PERMISSION_LABELS_FA[p1]}`,
        callback_data: `adm:adm:tperm:${target.userId}:${p1}`,
      },
    ];
    if (editablePerms[i + 1]) {
      const p2 = editablePerms[i + 1];
      row.push({
        text: `${target.permissions.includes(p2) ? '✅' : '⬜'} ${PERMISSION_LABELS_FA[p2]}`,
        callback_data: `adm:adm:tperm:${target.userId}:${p2}`,
      });
    }
    keyboard.push(row);
  }

  keyboard.push([{ text: '🔙 بازگشت به جزئیات مدیر', callback_data: `adm:adm:detail:${target.userId}` }]);
  return { text, keyboard };
}

export function renderSecuritySectionView(actor: AdminRecord): { text: string; keyboard: any[][] } {
  const secrets = inspectSecretsStatus();
  const warnings = checkSecretSecurityWarnings();
  const awsCfg = getAwsIntegrationConfig();
  const unauth1h = countUnauthorizedAttempts(60);
  const unauth24h = countUnauthorizedAttempts(24 * 60);
  const lastBk = getLastBackupSummary();
  const audits = getRecentAuditLogs(5, 0);

  const secretsSummary = secrets
    .map((s) => `• <b>${escHtml(s.labelFa)}:</b> ${s.maskedDisplay}`)
    .join('\n');

  const warningsSummary =
    warnings.length === 0
      ? '✅ هیچ هشدار امنیتی فعالی وجود ندارد.'
      : warnings.map((w) => `⚠️ ${escHtml(w)}`).join('\n');

  const recentAuditSummary =
    audits.length === 0
      ? '<i>تغییری ثبت نشده است.</i>'
      : audits
          .map(
            (a) =>
              `• [${a.created_at.slice(11, 19)}] <code>${a.actor_id}</code> ➔ ${escHtml(a.action)} (${a.result})`
          )
          .join('\n');

  const text =
`🛡 <b>مرکز امنیت و مدیریت اطلاعات محرمانه</b>
━━━━━━━━━━━━━━━━━━━━
• <b>احراز هویت مدیران:</b> 🟢 مبتنی بر Telegram Numeric ID + RBAC + انقضای Callback
• <b>منبع Secretها:</b> ${awsCfg.provider === 'aws_secrets_manager' ? 'AWS Secrets Manager' : awsCfg.provider === 'aws_ssm' ? 'AWS SSM Parameter Store' : 'متغیرهای محیطی امن سرور (.env)'}
• <b>تلاش‌های ورود غیرمجاز (۱ساعت / ۲۴ساعت):</b> ${unauth1h} / ${unauth24h}
• <b>وضعیت آخرین Backup:</b> ${lastBk.lastBackupAt ? `${lastBk.status === 'success' ? '🟢' : '🔴'} ${lastBk.lastBackupAt.slice(0, 19).replace('T', ' ')}` : '⚪ هنوز گرفته نشده'}

🔑 <b>وضعیت کلیدها و Secretها (هرگز متن ساده نمایش داده نمی‌شود):</b>
${secretsSummary}

🚨 <b>هشدارهای امنیتی:</b>
${warningsSummary}

📜 <b>خلاصه آخرین تغییرات مدیریتی (Audit Log):</b>
${recentAuditSummary}`;

  const keyboard: any[][] = [
    [
      { text: '📜 گزارش کامل Audit Log', callback_data: 'adm:sec_audit:0' },
      { text: '🌐 تست اتصال APIها', callback_data: 'adm:srv:ping' },
    ],
  ];

  if (actor.role === 'owner') {
    keyboard.push([{ text: '🔄 چرخش امن Secret (فقط مالک)', callback_data: 'adm:sec_secrets' }]);
  }

  keyboard.push([{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }]);
  return { text, keyboard };
}

export function renderSecretsRotationMenu(): { text: string; keyboard: any[][] } {
  const secrets = inspectSecretsStatus();
  const text =
`🔐 <b>مسیر امن تغییر و چرخش Secretها</b>
━━━━━━━━━━━━━━━━━━━━
⚠️ <b>اصل امنیتی:</b> برای جلوگیری از نشت اطلاعات، مقادیر Secret هرگز از طریق چت تلگرام دریافت، ذخیره یا نمایش داده نمی‌شوند.
با انتخاب هر مورد و تأیید مجدد مالک اصلی، دستور امن چرخش در AWS Secrets Manager / SSM Parameter Store با احراز هویت یک‌بارمصرف صادر می‌شود:`;

  const keyboard: any[][] = secrets.map((s) => [
    { text: `🔄 چرخش ${s.labelFa} (${s.isConfigured ? 'فعال' : 'خالی'})`, callback_data: `adm:sec_rot_ask:${s.key}` },
  ]);
  keyboard.push([{ text: '🔙 بازگشت به امنیت و دسترسی', callback_data: 'adm:sec:security' }]);
  return { text, keyboard };
}

export function renderAuditLogPageView(page: number): { text: string; keyboard: any[][] } {
  const pageSize = 8;
  const safePage = Math.max(0, page);
  const logs = getRecentAuditLogs(pageSize, safePage * pageSize);

  let text = `📜 <b>گزارش ممیزی فعالیت مدیران (Audit Log) — صفحه ${safePage + 1}</b>\n━━━━━━━━━━━━━━━━━━━━\n`;
  if (logs.length === 0) {
    text += '<i>موردی در این صفحه ثبت نشده است.</i>';
  } else {
    text += logs
      .map((l) => {
        const icon = l.result === 'success' ? '✅' : l.result === 'denied' ? '⛔️' : '❌';
        const diff =
          l.old_value || l.new_value
            ? `\n   تغییر: <code>${escHtml(l.old_value || '-')}</code> ➔ <code>${escHtml(l.new_value || '-')}</code>`
            : '';
        return `${icon} <b>${escHtml(l.action)}</b> [${escHtml(l.section)}]\n   👤 <code>${l.actor_id}</code> (${escHtml(l.actor_role || 'guest')}) | 🕒 ${l.created_at.slice(0, 19).replace('T', ' ')}${diff}`;
      })
      .join('\n\n');
  }

  const navRow: any[] = [];
  if (safePage > 0) navRow.push({ text: '⬅️ صفحه قبل', callback_data: `adm:sec_audit:${safePage - 1}` });
  if (logs.length === pageSize) navRow.push({ text: '➡️ صفحه بعد', callback_data: `adm:sec_audit:${safePage + 1}` });

  const keyboard: any[][] = [];
  if (navRow.length) keyboard.push(navRow);
  keyboard.push([{ text: '🔙 بازگشت به امنیت و دسترسی', callback_data: 'adm:sec:security' }]);
  return { text, keyboard };
}

export function renderServerStatusView(
  actor: AdminRecord,
  connectivityNote?: string,
  mOverride?: ServerMetricsSnapshot
): { text: string; keyboard: any[][] } {
  const m = mOverride || getServerMetrics();

  const text =
`🖥 <b>وضعیت سرور و کنترل سرویس‌ها</b>
━━━━━━━━━━━━━━━━━━━━
• <b>Telegram Bot:</b> ${m.botActive ? '🟢 آنلاین' : '🔴 آفلاین'} (${m.botMode})
• <b>Backend Internal API:</b> ${m.backendApiActive ? '🟢 فعال (Localhost)' : '⚪ غیرفعال'}
• <b>Downloader Service:</b> ${m.downloaderEnabled ? '🟢 فعال' : '🔴 متوقف'} (${m.activeDownloadsCount}/${m.maxConcurrentDownloads} فعال، ${m.queuedDownloadsCount} در صف)
• <b>Spotify Service:</b> ${m.spotifyEnabled ? '🟢 فعال' : '🔴 غیرفعال'}
• <b>درخواست‌های در حال پردازش:</b> ${m.inFlightRequests}

💻 <b>منابع سیستم (EC2 / Container):</b>
• <b>مصرف RAM فرآیند:</b> ${m.ramRssMb} MB RSS (Heap: ${m.ramHeapMb} MB)
• <b>حافظه کل سیستم:</b> ${m.osFreeMemMb} MB آزاد از ${m.osTotalMemMb} MB (${m.osMemUsedPercent}% مصرف)
• <b>مصرف CPU (Load 1m):</b> ${m.cpuLoad1m} روی ${m.cpuCores} هسته
• <b>فضای دیسک آزاد:</b> ${m.diskFreeMb !== null ? `${m.diskFreeMb} MB از ${m.diskTotalMb} MB` : 'نامشخص'} (${m.tempDirFilesCount} فایل موقت / ${m.tempDirSizeMb} MB)
• <b>زمان روشن بودن (Uptime):</b> ${formatUptimeFa(m.uptimeSeconds)}
• <b>آخرین Restart:</b> <code>${m.lastRestartAt.slice(0, 19).replace('T', ' ')} UTC</code>
• <b>خطاهای ۲۴ ساعت اخیر:</b> ${m.recentErrorsCount} | <b>تلاش غیرمجاز ۱ساعت:</b> ${m.unauthorizedAttempts1h}
${m.lastBotError ? `• <b>آخرین خطای ربات:</b> <code>${escHtml(m.lastBotError.slice(0, 100))}</code>\n` : ''}${connectivityNote ? `\n🌐 <b>بررسی سلامت و اینترنت:</b>\n${connectivityNote}` : ''}`;

  const keyboard: any[][] = [
    [
      { text: '🔄 Restart کنترل‌شده Bot', callback_data: 'adm:srv:restart_bot_ask' },
      {
        text: m.downloaderEnabled ? '⏸ توقف سرویس دانلود' : '▶️ اجرای سرویس دانلود',
        callback_data: m.downloaderEnabled ? 'adm:srv:pause_dl_ask' : 'adm:srv:resume_dl',
      },
    ],
    [
      { text: '🩺 بررسی سلامت و پینگ', callback_data: 'adm:srv:ping' },
      { text: '📜 آخرین لاگ‌ها', callback_data: 'adm:logs' },
    ],
    [
      { text: '❌ خطاهای اخیر', callback_data: 'adm:dl:errors' },
      { text: '🔄 بروزرسانی وضعیت', callback_data: 'adm:sec:server' },
    ],
  ];

  if (actor.role === 'owner') {
    keyboard.push([
      { text: '♻️ Restart کامل سرویس (PM2/Backend)', callback_data: 'adm:srv:restart_proc_ask' },
    ]);
  }

  keyboard.push([{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }]);
  return { text, keyboard };
}

export function renderStatsAndReportsView(runtimeStats: {
  totalRequests: number;
  totalDownloads: number;
  uptimeSeconds: number;
  lastError: string | null;
}): { text: string; keyboard: any[][] } {
  const userStats = getUsersStatsSummary();
  const cfg = loadBotConfig();
  const recentErrors = getRecentDownloaderErrors(undefined, 5);

  const text =
`📊 <b>آمار جامع و گزارشات ربات</b>
━━━━━━━━━━━━━━━━━━━━
• <b>کاربران ثبت‌شده در دیتابیس:</b> ${userStats.totalUsers.toLocaleString('fa-IR')} نفر
• <b>کاربران فعال ۲۴ساعت:</b> ${userStats.active24h.toLocaleString('fa-IR')} نفر
• <b>کاربران مسدود:</b> ${userStats.bannedUsers.toLocaleString('fa-IR')} نفر
• <b>کل دانلودهای موفق (تاریخچه):</b> ${userStats.totalRecordedDownloads.toLocaleString('fa-IR')}
• <b>کل دانلودهای نشست فعلی:</b> ${runtimeStats.totalDownloads.toLocaleString('fa-IR')}
• <b>کل درخواست‌های نشست فعلی:</b> ${runtimeStats.totalRequests.toLocaleString('fa-IR')}
• <b>کانال‌های قفل اجباری:</b> ${cfg.channels.length} کانال (${cfg.forceJoinEnabled ? 'فعال 🟢' : 'غیرفعال 🔴'})
• <b>مدت فعالیت (Uptime):</b> ${formatUptimeFa(runtimeStats.uptimeSeconds)}

⚠️ <b>خلاصه خطاهای اخیر (${recentErrors.length}):</b>
${recentErrors.length === 0 ? '✅ بدون خطای اخیر' : recentErrors.map((e) => `• [${escHtml(e.platform || '-')}] ${escHtml((e.errorMessage || '').slice(0, 65))}`).join('\n')}`;

  const keyboard = [
    [
      { text: '📜 مشاهده لاگ‌های زنده', callback_data: 'adm:logs' },
      { text: '🛡 گزارش Audit Log', callback_data: 'adm:sec_audit:0' },
    ],
    [
      { text: '❌ جزئیات خطاهای دانلود', callback_data: 'adm:dl:errors' },
      { text: '🔄 بروزرسانی آمار', callback_data: 'adm:sec:stats' },
    ],
    [{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }],
  ];

  return { text, keyboard };
}

export function renderBackupSectionView(): { text: string; keyboard: any[][] } {
  const summary = getLastBackupSummary();
  const backups = listBackups(8);

  let listText = '';
  const keyboard: any[][] = [
    [{ text: '💾 تهیه نسخه پشتیبان جدید (Backup Now)', callback_data: 'adm:bk:create' }],
  ];

  if (backups.length === 0) {
    listText = '<i>هنوز نسخه پشتیبانی در دیتابیس ثبت نشده است.</i>';
  } else {
    listText = backups
      .map(
        (b) =>
          `• <b>#${b.id}</b> <code>${escHtml(b.file_name)}</code>\n  📦 ${(b.size_bytes / 1024).toFixed(1)} KB | ${b.status === 'success' ? '🟢 سالم' : '🔴 ناموفق'} | ${b.created_at.slice(0, 19).replace('T', ' ')}`
      )
      .join('\n');

    for (const b of backups.filter((x) => x.status === 'success').slice(0, 4)) {
      keyboard.push([
        { text: `♻️ بازیابی نسخه #${b.id} (${b.created_at.slice(5, 16).replace('T', ' ')})`, callback_data: `adm:bk:restore_ask:${b.id}` },
      ]);
    }
  }

  const text =
`💾 <b>مدیریت پشتیبان‌گیری و بازیابی (SQLite WAL)</b>
━━━━━━━━━━━━━━━━━━━━
• <b>تعداد کل Backupهای سالم:</b> ${summary.count}
• <b>آخرین Backup:</b> ${summary.lastBackupAt ? `<code>${summary.lastBackupAt.slice(0, 19).replace('T', ' ')}</code>` : 'ندارد'}

📋 <b>لیست آخرین نسخه‌های پشتیبان:</b>
${listText}`;

  keyboard.push([
    { text: '🔄 بروزرسانی', callback_data: 'adm:sec:backup' },
    { text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' },
  ]);

  return { text, keyboard };
}

export function renderMaintenanceToolsView(): { text: string; keyboard: any[][] } {
  const cfg = loadBotConfig();
  const text =
`🔧 <b>ابزارهای تعمیر، نگهداری و یکپارچه‌سازی</b>
━━━━━━━━━━━━━━━━━━━━
• <b>قفل جوین اجباری:</b> ${cfg.forceJoinEnabled ? `🟢 فعال (${cfg.channels.length} کانال)` : '🔴 غیرفعال'}
• <b>کوکی اینستاگرام:</b> ${hasInstagramCookies() ? '🟢 فعال' : '⚪ پیش‌فرض عمومی'}
• <b>کوکی یوتیوب:</b> ${hasYoutubeCookies() ? '🟢 فعال' : '⚪ پیش‌فرض عمومی'}

👇 <i>ابزار مورد نظر را انتخاب کنید:</i>`;

  const keyboard = [
    [
      { text: '🔒 قفل کانال‌ها (جوین اجباری)', callback_data: 'adm:forcejoin' },
      { text: '🌐 مدیریت وب‌هوک', callback_data: 'adm:webhook' },
    ],
    [
      { text: '📷 کوکی اینستاگرام', callback_data: 'adm:instagram' },
      { text: '▶️ کوکی یوتیوب', callback_data: 'adm:youtube' },
    ],
    [
      { text: '🧹 پاکسازی فایل‌های موقت', callback_data: 'adm:dl:clean_ask' },
      { text: '🗜 بهینه‌سازی دیتابیس (Vacuum)', callback_data: 'adm:mnt:vacuum' },
    ],
    [{ text: '↩️ بازگشت به منوی اصلی', callback_data: 'adm:menu' }],
  ];

  return { text, keyboard };
}

export async function buildPingConnectivityReport(): Promise<string> {
  const c = await checkServicesConnectivity();
  return [
    `• اینترنت سرور: ${c.internetOk ? '🟢 متصل' : '🔴 قطع'}`,
    `• Telegram API: ${c.telegramOk ? `🟢 متصل (${c.telegramLatencyMs}ms)` : '🔴 ناموفق'}`,
    `• Spotify Embed/oEmbed: ${c.spotifyOk ? `🟢 متصل (${c.spotifyLatencyMs}ms)` : '🔴 خطا'}`,
    `• Secret Provider: ${escHtml(c.awsStatus)}`,
  ].join('\n');
}
