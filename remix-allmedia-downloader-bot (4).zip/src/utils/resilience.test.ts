import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { AddressInfo } from 'node:net';
import {
  AsyncSemaphore,
  SlidingWindowRateLimiter,
  calculateBackoffMs,
  isPermanentTelegramAuthError,
  acquirePidLock,
  releasePidLock,
} from './resilience.ts';
import {
  extractSpotifyCollectionTarget,
  parseSpotifyCollectionEmbedJson,
} from '../services/spotifyResolver.ts';
import { createInternalApiApp } from '../api/httpServer.ts';

test('AsyncSemaphore enforces max concurrency limit and drains queued tasks', async () => {
  const sem = new AsyncSemaphore(2);
  let active = 0;
  let maxSeen = 0;

  const task = async (delayMs: number, value: number) => {
    return sem.run(async () => {
      active++;
      maxSeen = Math.max(maxSeen, active);
      await new Promise((r) => setTimeout(r, delayMs));
      active--;
      return value;
    });
  };

  const results = await Promise.all([task(20, 1), task(20, 2), task(10, 3), task(10, 4)]);
  assert.deepEqual(results, [1, 2, 3, 4]);
  assert.equal(maxSeen, 2);
  assert.equal(sem.active, 0);
  assert.equal(sem.pending, 0);
});

test('SlidingWindowRateLimiter throttles bursts and recovers after window expires', () => {
  const limiter = new SlidingWindowRateLimiter(3, 10_000);
  const t0 = 1_000_000;

  assert.equal(limiter.check('user1', t0).allowed, true);
  assert.equal(limiter.check('user1', t0 + 100).allowed, true);
  assert.equal(limiter.check('user1', t0 + 200).allowed, true);

  const blocked = limiter.check('user1', t0 + 300);
  assert.equal(blocked.allowed, false);
  assert.ok(blocked.retryAfterMs >= 9000);

  // Other users are unaffected
  assert.equal(limiter.check('user2', t0 + 300).allowed, true);

  // After window passes, user1 is allowed again
  assert.equal(limiter.check('user1', t0 + 10_100).allowed, true);
});

test('calculateBackoffMs grows exponentially, applies jitter, and caps at maxMs', () => {
  assert.equal(calculateBackoffMs(1, 2000, 60000, () => 0), 2000);
  assert.equal(calculateBackoffMs(2, 2000, 60000, () => 0), 4000);
  assert.equal(calculateBackoffMs(3, 2000, 60000, () => 0), 8000);
  assert.equal(calculateBackoffMs(10, 2000, 60000, () => 1), 60000);
});

test('isPermanentTelegramAuthError distinguishes invalid tokens from transient errors', () => {
  assert.equal(isPermanentTelegramAuthError('401 Unauthorized'), true);
  assert.equal(isPermanentTelegramAuthError('Not Found'), true);
  assert.equal(isPermanentTelegramAuthError('fetch failed: ECONNRESET'), false);
  assert.equal(isPermanentTelegramAuthError('terminated by other getUpdates request'), false);
});

test('acquirePidLock rejects duplicate live PID and replaces stale dead PID', () => {
  const lockPath = path.join(os.tmpdir(), `telegram-boy-test-${Date.now()}.lock`);
  try {
    // Write a stale non-existent PID
    fs.writeFileSync(lockPath, '99999999\n');
    assert.equal(acquirePidLock(lockPath), true);
    assert.equal(fs.readFileSync(lockPath, 'utf-8').trim(), String(process.pid));

    // Simulate another live process holding the lock (use PID 1 / init which exists on Linux)
    fs.writeFileSync(lockPath, '1\n');
    assert.equal(acquirePidLock(lockPath), false);

    // Cleanup lock owned by current process
    fs.writeFileSync(lockPath, `${process.pid}\n`);
    releasePidLock(lockPath);
    assert.equal(fs.existsSync(lockPath), false);
  } finally {
    try { fs.unlinkSync(lockPath); } catch {}
  }
});

test('Spotify collection target & embed JSON parser extract album/playlist tracks cleanly', () => {
  const albumTarget = extractSpotifyCollectionTarget('https://open.spotify.com/album/4aawyAB9vmqN3uQ7FjRGTy?si=abc');
  assert.deepEqual(albumTarget, { type: 'album', id: '4aawyAB9vmqN3uQ7FjRGTy' });

  const playlistTarget = extractSpotifyCollectionTarget('https://open.spotify.com/intl-fa/playlist/37i9dQZF1DXcBWIGoYBM5M');
  assert.deepEqual(playlistTarget, { type: 'playlist', id: '37i9dQZF1DXcBWIGoYBM5M' });

  assert.equal(extractSpotifyCollectionTarget('https://open.spotify.com/track/7qiZfU4dY1lWllzX7mPBI3'), null);

  const mockNextData = {
    props: {
      pageProps: {
        state: {
          data: {
            entity: {
              name: 'Test Album',
              subtitle: 'Test Artist',
              trackList: [
                { title: 'Song One', subtitle: 'Artist A', uri: 'spotify:track:1111111111111111111111', duration: 180000 },
                { title: 'Song Two', subtitle: 'Artist B', uri: 'spotify:track:2222222222222222222222', duration: 200000 },
              ],
            },
          },
        },
      },
    },
  };

  const parsed = parseSpotifyCollectionEmbedJson(
    mockNextData,
    'album',
    '4aawyAB9vmqN3uQ7FjRGTy',
    'https://open.spotify.com/album/4aawyAB9vmqN3uQ7FjRGTy'
  );
  assert.ok(parsed);
  assert.equal(parsed?.title, 'Test Album');
  assert.equal(parsed?.tracks.length, 2);
  assert.equal(parsed?.tracks[0].url, 'https://open.spotify.com/track/1111111111111111111111');
});

test('Internal HTTP API enforces ADMIN_API_KEY, exposes /health, and removes /api/bot/simulate', async () => {
  const prevKey = process.env.ADMIN_API_KEY;
  delete process.env.ADMIN_API_KEY;

  const app = createInternalApiApp();
  const server = await new Promise<import('node:http').Server>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });

  try {
    const { port } = server.address() as AddressInfo;
    const base = `http://127.0.0.1:${port}`;

    const rootRes = await fetch(`${base}/`);
    assert.equal(rootRes.status, 200);
    const rootJson: any = await rootRes.json();
    assert.equal(rootJson.status, 'ok');
    assert.equal(rootJson.service, 'telegram-boy-bot');

    const healthRes = await fetch(`${base}/health`);
    assert.equal(healthRes.status, 200);
    const healthJson: any = await healthRes.json();
    assert.equal(healthJson.status, 'ok');

    // Without ADMIN_API_KEY configured, admin routes fail closed (403)
    const noKeyRes = await fetch(`${base}/api/config`);
    assert.equal(noKeyRes.status, 403);

    // With ADMIN_API_KEY configured, wrong key returns 401 and valid key returns 200
    process.env.ADMIN_API_KEY = 'super-secret-test-key';
    const badKeyRes = await fetch(`${base}/api/config`, {
      headers: { 'x-admin-api-key': 'wrong' },
    });
    assert.equal(badKeyRes.status, 401);

    const goodKeyRes = await fetch(`${base}/api/config`, {
      headers: { 'x-admin-api-key': 'super-secret-test-key' },
    });
    assert.equal(goodKeyRes.status, 200);

    // Webhook rejects requests without valid secret header
    const whRes = await fetch(`${base}/api/telegram/webhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ update_id: 1 }),
    });
    assert.equal(whRes.status, 403);

    // Website simulation endpoint is completely gone
    const simRes = await fetch(`${base}/api/bot/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: '/start' }),
    });
    assert.equal(simRes.status, 404);
  } finally {
    if (prevKey === undefined) delete process.env.ADMIN_API_KEY;
    else process.env.ADMIN_API_KEY = prevKey;
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});
