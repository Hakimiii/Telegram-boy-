import fs from 'node:fs';
import path from 'node:path';

/**
 * Validates that a URL is strictly public HTTP/HTTPS (prevents SSRF and protocol injection)
 */
export function validateSafeHttpUrl(rawUrl: string): string {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    throw new Error('آدرس لینک نامعتبر است.');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('فقط لینک‌های http و https پشتیبانی می‌شوند.');
  }

  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    !host ||
    host === 'localhost' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.startsWith('127.') ||
    host.startsWith('10.') ||
    host.startsWith('192.168.') ||
    host.startsWith('169.254.') ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(host) ||
    host.startsWith('fc') ||
    host.startsWith('fd') ||
    host.startsWith('fe80')
  ) {
    throw new Error('دسترسی به آدرس‌های شبکه داخلی مجاز نیست.');
  }

  return parsed.toString();
}

/**
 * Exponential backoff with full/partial jitter for resilient network retries
 */
export function calculateBackoffMs(
  attempt: number,
  baseMs: number = 2000,
  maxMs: number = 60000,
  randomFn: () => number = Math.random
): number {
  const safeAttempt = Math.max(1, Math.floor(attempt));
  const exp = Math.min(maxMs, baseMs * Math.pow(2, safeAttempt - 1));
  const jitter = Math.floor(exp * 0.25 * Math.max(0, Math.min(1, randomFn())));
  return Math.min(maxMs, exp + jitter);
}

/**
 * Detect permanent Telegram Bot Token / Auth errors where retrying forever is pointless
 */
export function isPermanentTelegramAuthError(errMessage: string): boolean {
  const lower = (errMessage || '').toLowerCase();
  return (
    lower.includes('401') ||
    lower.includes('unauthorized') ||
    lower.includes('token is invalid') ||
    lower.includes('not found')
  );
}

/**
 * Bounded async semaphore to cap concurrent heavy subprocesses (yt-dlp / ffmpeg)
 */
export class AsyncSemaphore {
  private readonly maxConcurrent: number;
  private activeCount = 0;
  private readonly waitQueue: Array<() => void> = [];

  constructor(maxConcurrent: number = 3) {
    this.maxConcurrent = Math.max(1, Math.floor(maxConcurrent));
  }

  get active(): number {
    return this.activeCount;
  }

  get pending(): number {
    return this.waitQueue.length;
  }

  async acquire(): Promise<() => void> {
    if (this.activeCount < this.maxConcurrent) {
      this.activeCount++;
      return this.createReleaser();
    }

    return new Promise<() => void>((resolve) => {
      this.waitQueue.push(() => {
        this.activeCount++;
        resolve(this.createReleaser());
      });
    });
  }

  private createReleaser(): () => void {
    let released = false;
    return () => {
      if (released) return;
      released = true;
      this.activeCount = Math.max(0, this.activeCount - 1);
      const next = this.waitQueue.shift();
      if (next) next();
    };
  }

  async run<T>(fn: () => Promise<T>): Promise<T> {
    const release = await this.acquire();
    try {
      return await fn();
    } finally {
      release();
    }
  }
}

/**
 * In-memory sliding-window rate limiter (used for both per-user Telegram anti-spam and HTTP endpoints)
 */
export class SlidingWindowRateLimiter {
  private readonly maxRequests: number;
  private readonly windowMs: number;
  private readonly hits = new Map<string, number[]>();

  constructor(maxRequests: number = 10, windowMs: number = 30_000) {
    this.maxRequests = Math.max(1, maxRequests);
    this.windowMs = Math.max(1000, windowMs);
  }

  check(key: string, now: number = Date.now()): { allowed: boolean; retryAfterMs: number } {
    const cutoff = now - this.windowMs;
    const timestamps = (this.hits.get(key) || []).filter((ts) => ts > cutoff);

    if (timestamps.length >= this.maxRequests) {
      const oldest = timestamps[0];
      const retryAfterMs = Math.max(1000, oldest + this.windowMs - now);
      this.hits.set(key, timestamps);
      return { allowed: false, retryAfterMs };
    }

    timestamps.push(now);
    this.hits.set(key, timestamps);

    if (this.hits.size > 5000) {
      this.prune(now);
    }

    return { allowed: true, retryAfterMs: 0 };
  }

  prune(now: number = Date.now()): void {
    const cutoff = now - this.windowMs;
    for (const [key, timestamps] of this.hits.entries()) {
      const active = timestamps.filter((ts) => ts > cutoff);
      if (active.length === 0) {
        this.hits.delete(key);
      } else {
        this.hits.set(key, active);
      }
    }
  }
}

export function isProcessRunning(pid: number): boolean {
  if (!Number.isSafeInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (err: any) {
    // EPERM means the process exists even if owned by another user
    return err?.code === 'EPERM';
  }
}

export function getDefaultPidLockPath(): string {
  return path.resolve(process.env.PID_LOCK_FILE || '/tmp/telegram-boy.lock');
}

/**
 * Acquire an exclusive PID lockfile to prevent duplicate bot polling instances
 */
export function acquirePidLock(lockFilePath: string = getDefaultPidLockPath()): boolean {
  const dir = path.dirname(lockFilePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (fs.existsSync(lockFilePath)) {
    try {
      const content = fs.readFileSync(lockFilePath, 'utf-8').trim();
      const existingPid = parseInt(content, 10);
      if (existingPid && existingPid !== process.pid && isProcessRunning(existingPid)) {
        return false;
      }
      // Stale lockfile from crashed process
      fs.unlinkSync(lockFilePath);
    } catch {
      try {
        fs.unlinkSync(lockFilePath);
      } catch {}
    }
  }

  try {
    fs.writeFileSync(lockFilePath, `${process.pid}\n`, { flag: 'wx', mode: 0o600 });
    return true;
  } catch {
    return false;
  }
}

export function releasePidLock(lockFilePath: string = getDefaultPidLockPath()): void {
  try {
    if (!fs.existsSync(lockFilePath)) return;
    const content = fs.readFileSync(lockFilePath, 'utf-8').trim();
    const existingPid = parseInt(content, 10);
    if (!existingPid || existingPid === process.pid) {
      fs.unlinkSync(lockFilePath);
    }
  } catch {}
}
