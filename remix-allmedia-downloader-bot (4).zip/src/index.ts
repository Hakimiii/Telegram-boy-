import dotenv from 'dotenv';
dotenv.config();

import type { Server } from 'node:http';
import {
  ensureYtDlpExecutable,
  saveInstagramSession,
  hasInstagramCookies,
  saveYoutubeCookies,
  hasYoutubeCookies,
} from './services/mediaDownloader.ts';
import { startTelegramBot, stopTelegramBot } from './bot/telegramBot.ts';
import { startInternalHttpServer } from './api/httpServer.ts';
import { getDb, closeDb } from './services/database.ts';
import { loadBotConfig } from './services/configManager.ts';
import { startAdminHealthMonitor, stopAdminHealthMonitor } from './services/controlService.ts';
import {
  acquirePidLock,
  releasePidLock,
  getDefaultPidLockPath,
  calculateBackoffMs,
} from './utils/resilience.ts';

let httpServer: Server | null = null;
let retryTimer: NodeJS.Timeout | null = null;
let shuttingDown = false;

process.on('uncaughtException', (err) => {
  console.error('[Process Uncaught Exception]:', err);
});

process.on('unhandledRejection', (reason) => {
  console.error('[Process Unhandled Rejection]:', reason);
});

async function initTelegramBotWithRetry(attempt: number = 1): Promise<void> {
  if (shuttingDown) return;

  const token = (process.env.TELEGRAM_BOT_TOKEN || '').trim();
  if (!token) {
    console.error('[Telegram Bot] Missing TELEGRAM_BOT_TOKEN environment variable. Bot polling will not start.');
    return;
  }

  try {
    const res = await startTelegramBot(token);
    console.log('[Telegram Bot Initialization]:', res.message);

    if (!res.success && !res.permanentError && !shuttingDown) {
      const delay = calculateBackoffMs(attempt, 5000, 60_000);
      console.warn(`[Telegram Bot] Transient init failure, retrying in ${Math.round(delay / 1000)}s...`);
      retryTimer = setTimeout(() => {
        void initTelegramBotWithRetry(attempt + 1);
      }, delay);
      retryTimer.unref?.();
    } else if (res.permanentError) {
      console.error('[Telegram Bot] Permanent token/auth error detected. Fix TELEGRAM_BOT_TOKEN in .env and restart.');
    }
  } catch (err) {
    if (shuttingDown) return;
    const delay = calculateBackoffMs(attempt, 5000, 60_000);
    console.error(`[Telegram Bot] Init threw error, retrying in ${Math.round(delay / 1000)}s:`, err);
    retryTimer = setTimeout(() => {
      void initTelegramBotWithRetry(attempt + 1);
    }, delay);
    retryTimer.unref?.();
  }
}

function gracefulShutdown(signal: string): void {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[Process] Received ${signal}. Starting graceful shutdown...`);

  if (retryTimer) {
    clearTimeout(retryTimer);
    retryTimer = null;
  }

  try {
    stopAdminHealthMonitor();
  } catch {}

  try {
    stopTelegramBot();
  } catch (err) {
    console.error('[Shutdown] Error stopping Telegram bot:', err);
  }

  try {
    closeDb();
  } catch {}

  releasePidLock();

  const forceExitTimer = setTimeout(() => {
    console.warn('[Shutdown] Timed out waiting for HTTP connections to close; exiting.');
    process.exit(0);
  }, 5000);
  forceExitTimer.unref?.();

  if (httpServer) {
    httpServer.close(() => {
      clearTimeout(forceExitTimer);
      console.log('[Shutdown] Clean exit complete.');
      process.exit(0);
    });
  } else {
    clearTimeout(forceExitTimer);
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('exit', () => {
  try { closeDb(); } catch {}
  releasePidLock();
});

async function bootstrap() {
  if (!acquirePidLock()) {
    console.error(`[Startup Error] Another bot instance is already running (lockfile active at ${getDefaultPidLockPath()}). Exiting to avoid 409 Polling conflict.`);
    process.exit(1);
  }

  // Initialize persistent SQLite database (WAL + auto-migration + legacy JSON import)
  try {
    getDb();
    loadBotConfig();
  } catch (dbErr) {
    console.error('[Startup Warning] Database initialization error:', dbErr);
  }

  if (process.env.DISABLE_HTTP_API !== 'true') {
    const started = await startInternalHttpServer();
    httpServer = started.server;
  } else {
    console.log('[Startup] Internal HTTP API disabled via DISABLE_HTTP_API=true');
  }

  if (process.env.INSTAGRAM_SESSION_ID && !hasInstagramCookies()) {
    saveInstagramSession(process.env.INSTAGRAM_SESSION_ID, { source: 'env' });
  }
  if (process.env.YOUTUBE_COOKIES && !hasYoutubeCookies()) {
    saveYoutubeCookies(process.env.YOUTUBE_COOKIES);
  }

  void ensureYtDlpExecutable();
  startAdminHealthMonitor();
  await initTelegramBotWithRetry();
}

void bootstrap();
