import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import type { Server } from 'node:http';
import {
  extractMediaInfo,
  downloadMedia,
  saveInstagramSession,
  hasInstagramCookies,
  identifySongFromMedia,
  saveYoutubeCookies,
  hasYoutubeCookies,
  clearYoutubeCookies,
} from '../services/mediaDownloader.ts';
import {
  startTelegramBot,
  getBotState,
  testChannelAccess,
  handleWebhookUpdate,
  setBotWebhook,
  removeBotWebhook,
  getBotWebhookInfo,
  verifyWebhookSecret,
} from '../bot/telegramBot.ts';
import { loadBotConfig, saveBotConfig, SUPER_ADMIN_ID } from '../services/configManager.ts';
import { setHttpApiRunning } from '../services/controlService.ts';
import { SlidingWindowRateLimiter, validateSafeHttpUrl } from '../utils/resilience.ts';

export function requireStrictAdminKey(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) {
  const configuredKey = (process.env.ADMIN_API_KEY || '').trim();
  if (!configuredKey) {
    return res.status(403).json({
      success: false,
      error: 'دسترسی به API مدیریتی غیرفعال است (ADMIN_API_KEY تنظیم نشده است).',
    });
  }

  const provided = req.header('x-admin-api-key') || '';
  const a = Buffer.from(provided, 'utf8');
  const b = Buffer.from(configuredKey, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ success: false, error: 'دسترسی غیرمجاز' });
  }
  next();
}

export function createInternalApiApp(): express.Express {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });

  app.use(express.json({ limit: '512kb' }));

  const limiter = new SlidingWindowRateLimiter(30, 60_000);
  const mediaRateLimiter = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const check = limiter.check(`${ip}:${req.path}`);
    if (!check.allowed) {
      return res.status(429).json({ error: 'تعداد درخواست‌ها بیش از حد مجاز است.' });
    }
    next();
  };

  // Healthcheck endpoint for Cloud Run / PM2 / Docker / systemd monitoring
  app.get(['/', '/health', '/api/ping'], (_req, res) => {
    const state = getBotState();
    res.json({
      status: 'ok',
      service: 'telegram-boy-bot',
      uptime: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
      botActive: state.isActive,
      isWebhookMode: state.isWebhookMode,
      memoryRssMb: Number((process.memoryUsage().rss / 1024 / 1024).toFixed(1)),
    });
  });

  // Telegram Webhook endpoint (verifies Telegram secret_token)
  app.post('/api/telegram/webhook', async (req, res) => {
    const secretHeader = req.header('x-telegram-bot-api-secret-token');
    if (!verifyWebhookSecret(secretHeader)) {
      return res.status(403).send('Forbidden');
    }
    res.status(200).send('OK');
    try {
      if (req.body && req.body.update_id !== 0) {
        await handleWebhookUpdate(req.body);
      }
    } catch (err) {
      console.error('Webhook processing error:', err);
    }
  });

  // Temporary file download endpoint (only used if APP_URL is configured for files >50MB)
  app.get('/api/media/file/:id', (req, res) => {
    try {
      const fileId = req.params.id;
      if (!/^[a-zA-Z0-9-]{8,64}$/.test(fileId)) {
        return res.status(400).json({ error: 'شناسه فایل نامعتبر است.' });
      }

      const downloadDir = path.resolve('/tmp/downloads');
      if (!fs.existsSync(downloadDir)) {
        return res.status(404).json({ error: 'فایل یافت نشد.' });
      }

      const files = fs.readdirSync(downloadDir);
      const targetFile = files.find((f) => f.startsWith(fileId) && !f.endsWith('.info.json'));
      if (!targetFile) {
        return res.status(404).json({ error: 'فایل مورد نظر منقضی شده یا یافت نشد.' });
      }

      const fullPath = path.resolve(downloadDir, targetFile);
      if (!fullPath.startsWith(downloadDir + path.sep)) {
        return res.status(403).json({ error: 'دسترسی غیرمجاز' });
      }

      const stat = fs.statSync(fullPath);
      const ext = path.extname(targetFile).toLowerCase();
      const isAudio = ext === '.mp3' || ext === '.m4a';
      const safeFilename = path.basename(targetFile).replace(/[^a-zA-Z0-9._-]/g, '_');

      res.setHeader('Content-Length', stat.size);
      res.setHeader('Content-Type', isAudio ? 'audio/mpeg' : 'video/mp4');
      res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"`);

      fs.createReadStream(fullPath).pipe(res);
    } catch (err) {
      console.error('File stream error:', err);
      res.status(500).json({ error: 'خطا در استریم فایل' });
    }
  });

  // Strict ADMIN_API_KEY protected internal management routes
  app.get('/api/bot/status', requireStrictAdminKey, (_req, res) => {
    const state = getBotState();
    res.json({
      ...state,
      hasInstagramCookies: hasInstagramCookies(),
      hasYoutubeCookies: hasYoutubeCookies(),
    });
  });

  app.get('/api/config', requireStrictAdminKey, (_req, res) => {
    res.json(loadBotConfig());
  });

  app.post('/api/config', requireStrictAdminKey, (req, res) => {
    try {
      const body = req.body || {};
      const sanitized: any = {};

      if (typeof body.forceJoinEnabled === 'boolean') {
        sanitized.forceJoinEnabled = body.forceJoinEnabled;
      }
      if (typeof body.mainChannelUrl === 'string' && body.mainChannelUrl.length <= 300) {
        sanitized.mainChannelUrl = body.mainChannelUrl.trim();
      }
      if (typeof body.supportUsername === 'string' && body.supportUsername.length <= 100) {
        sanitized.supportUsername = body.supportUsername.replace('@', '').trim();
      }
      if (Array.isArray(body.channels)) {
        sanitized.channels = body.channels
          .filter((c: any) => c && typeof c.id === 'string' && c.id.trim().length > 0 && c.id.length <= 128)
          .slice(0, 20)
          .map((c: any) => ({
            id: String(c.id).trim(),
            title: String(c.title || c.id).slice(0, 120),
            username: String(c.username || '').slice(0, 100),
            url: String(c.url || '').slice(0, 300),
          }));
      }
      if (Array.isArray(body.adminIds)) {
        const validIds = body.adminIds
          .map((id: any) => Number(id))
          .filter((id: number) => Number.isSafeInteger(id) && id > 0);
        if (!validIds.includes(SUPER_ADMIN_ID)) validIds.push(SUPER_ADMIN_ID);
        sanitized.adminIds = Array.from(new Set(validIds));
      }

      const updated = saveBotConfig(sanitized);
      res.json({ success: true, config: updated, message: 'تنظیمات با موفقیت ذخیره شد.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'خطا در ذخیره تنظیمات' });
    }
  });

  app.post('/api/admin/channels/test', requireStrictAdminKey, async (req, res) => {
    const { channelId } = req.body || {};
    if (!channelId || typeof channelId !== 'string') {
      return res.status(400).json({ success: false, message: 'شناسه کانال ارسال نشده است.' });
    }
    const result = await testChannelAccess(channelId);
    res.json(result);
  });

  app.post('/api/settings/instagram', requireStrictAdminKey, (req, res) => {
    const { sessionId } = req.body || {};
    const result = saveInstagramSession(typeof sessionId === 'string' ? sessionId : '');
    res.json(result);
  });

  app.post('/api/settings/youtube', requireStrictAdminKey, (req, res) => {
    const { cookies } = req.body || {};
    const result = saveYoutubeCookies(typeof cookies === 'string' ? cookies : '');
    res.json(result);
  });

  app.delete('/api/settings/youtube', requireStrictAdminKey, (_req, res) => {
    clearYoutubeCookies();
    res.json({ success: true, message: 'کوکی‌های یوتیوب با موفقیت پاک شدند.' });
  });

  app.post('/api/bot/restart', requireStrictAdminKey, async (req, res) => {
    const { token } = req.body || {};
    const result = await startTelegramBot(typeof token === 'string' && token.trim() ? token.trim() : undefined);
    res.json(result);
  });

  app.get('/api/bot/webhook', requireStrictAdminKey, async (_req, res) => {
    try {
      const info = await getBotWebhookInfo();
      res.json(info);
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'خطا در دریافت اطلاعات وب‌هوک' });
    }
  });

  app.post('/api/bot/webhook/set', requireStrictAdminKey, async (req, res) => {
    try {
      const { webhookUrl } = req.body || {};
      if (!webhookUrl || typeof webhookUrl !== 'string' || !webhookUrl.startsWith('https://')) {
        return res.status(400).json({ success: false, message: 'آدرس وب‌هوک نامعتبر است (باید با https:// شروع شود).' });
      }
      const result = await setBotWebhook(validateSafeHttpUrl(webhookUrl));
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ success: false, message: err?.message || 'خطا در تنظیم وب‌هوک' });
    }
  });

  app.post('/api/bot/webhook/delete', requireStrictAdminKey, async (_req, res) => {
    try {
      const result = await removeBotWebhook();
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ success: false, message: err?.message || 'خطا در حذف وب‌هوک' });
    }
  });

  app.post('/api/media/info', requireStrictAdminKey, mediaRateLimiter, async (req, res) => {
    try {
      const { url } = req.body || {};
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'آدرس URL ارسال نشده است.' });
      }
      const safeUrl = validateSafeHttpUrl(url);
      const info = await extractMediaInfo(safeUrl);
      res.json(info);
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'خطا در استخراج اطلاعات ویدیو' });
    }
  });

  app.post('/api/media/identify-song', requireStrictAdminKey, mediaRateLimiter, async (req, res) => {
    try {
      const { url } = req.body || {};
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'آدرس URL ارسال نشده است.' });
      }
      const safeUrl = validateSafeHttpUrl(url);
      const mediaInfo = await extractMediaInfo(safeUrl);
      const song = await identifySongFromMedia(safeUrl, mediaInfo);
      res.json({ success: true, song, mediaInfo });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'خطا در تشخیص موزیک' });
    }
  });

  app.post('/api/media/download', requireStrictAdminKey, mediaRateLimiter, async (req, res) => {
    try {
      const { url, qualityId } = req.body || {};
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'آدرس URL ارسال نشده است.' });
      }
      const safeUrl = validateSafeHttpUrl(url);
      const safeQuality = typeof qualityId === 'string' ? qualityId.slice(0, 32) : 'best_720';
      const download = await downloadMedia(safeUrl, safeQuality);
      res.json({
        success: true,
        id: download.id,
        fileName: download.fileName,
        fileSize: download.fileSizeFormatted,
        fileSizeBytes: download.fileSizeBytes,
        mimeType: download.mimeType,
        downloadUrl: `/api/media/file/${download.id}`,
      });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'خطا در دانلود فایل ویدیو' });
    }
  });

  return app;
}

export function startInternalHttpServer(): Promise<{ server: Server; host: string; port: number }> {
  const app = createInternalApiApp();
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const host = (process.env.API_HOST || process.env.HOST || '0.0.0.0').trim();

  return new Promise((resolve) => {
    const server = app.listen(port, host, () => {
      setHttpApiRunning(true);
      console.log(`[Internal API] Listening on http://${host}:${port}`);
      resolve({ server, host, port });
    });
    server.on('close', () => {
      setHttpApiRunning(false);
    });
  });
}
