import fs, { openAsBlob } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {
  extractUrl,
  identifyPlatform,
  evaluateWebhookCheckStatus,
  formatDownloadLoadingText,
  normalizeChannelIdentifier,
  isTelegramChatMemberStatusJoined,
  isChannelAdminConfigError,
  type IdentifiedSong,
} from '../services/mediaParser.ts';
import {
  ensureYtDlpExecutable,
  extractMediaInfo,
  getCachedMediaInfo,
  downloadMedia,
  identifySongFromMedia,
  downloadInstagramPost,
  extractInstagramAudio,
  getDownloadQueueStats,
  type DownloadProgress,
} from '../services/mediaDownloader.ts';
import {
  loadBotConfig,
  isUserAdmin,
  upsertUserActivity,
  getUserProfile,
  checkUserDailyQuota,
  incrementUserDownloadCount,
  recordUserRequestLog,
  touchAdminActivity,
  flushBotUsersSync,
  type RequiredChannel,
} from '../services/configManager.ts';
import { recordAuditLog } from '../services/database.ts';
import {
  registerBotControlBridge,
  notifyOwnerAlert,
  isHttpApiRunningFlag,
} from '../services/controlService.ts';
import {
  extractSpotifyInfo,
  extractSpotifyCollection,
  extractSpotifyCollectionTarget,
  downloadSpotifyTrack,
  type SpotifyCollectionTrack,
} from '../services/spotifyResolver.ts';
import { sendAdminDashboard, handleAdminCallbackQuery, handleAdminMessageStep } from '../services/adminPanel.ts';
import {
  SlidingWindowRateLimiter,
  calculateBackoffMs,
  isPermanentTelegramAuthError,
} from '../utils/resilience.ts';

export interface BotActivityLog {
  id: string;
  timestamp: string;
  userId?: number | string;
  userName?: string;
  action: string;
  platform?: string;
  details: string;
  status: 'pending' | 'success' | 'error';
}

export interface BotState {
  isActive: boolean;
  botInfo: {
    id?: number;
    username?: string;
    first_name?: string;
  } | null;
  startTime: number;
  totalRequests: number;
  totalDownloads: number;
  uniqueUsers: Set<number | string>;
  lastError: string | null;
  logs: BotActivityLog[];
  isWebhookMode: boolean;
  webhookUrl: string | null;
}

const state: BotState = {
  isActive: false,
  botInfo: null,
  startTime: Date.now(),
  totalRequests: 0,
  totalDownloads: 0,
  uniqueUsers: new Set(),
  lastError: null,
  logs: [],
  isWebhookMode: false,
  webhookUrl: null,
};

export function escapeHtml(str: any): string {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

interface PendingRequestItem {
  url: string;
  title: string;
  uploader: string;
  duration: string;
  platform: string;
  createdAt: number;
  localFilePath?: string;
  tracks?: SpotifyCollectionTrack[];
}

const PENDING_FILE_PROJECT = path.resolve(process.cwd(), 'bot_pending_requests.json');
const PENDING_FILE_TMP = path.resolve('/tmp/bot_pending_requests.json');
const pendingRequests = new Map<string, PendingRequestItem>();

function loadPendingRequests() {
  try {
    let raw = '';
    if (fs.existsSync(PENDING_FILE_PROJECT)) {
      raw = fs.readFileSync(PENDING_FILE_PROJECT, 'utf-8');
    } else if (fs.existsSync(PENDING_FILE_TMP)) {
      raw = fs.readFileSync(PENDING_FILE_TMP, 'utf-8');
    }
    if (raw) {
      const data = JSON.parse(raw);
      const now = Date.now();
      for (const [k, v] of Object.entries(data)) {
        const item = v as PendingRequestItem;
        if (now - (item.createdAt || 0) < 48 * 3600 * 1000) {
          pendingRequests.set(k, item);
        }
      }
    }
  } catch (err) {
    console.warn('Could not load pending requests cache:', err);
  }
}

let pendingSaveTimer: NodeJS.Timeout | null = null;
function pruneExpiredPendingRequests() {
  const now = Date.now();
  for (const [k, item] of pendingRequests.entries()) {
    if (now - (item.createdAt || 0) > 48 * 3600 * 1000) {
      pendingRequests.delete(k);
    }
  }
}

function savePendingRequests() {
  if (pendingSaveTimer) clearTimeout(pendingSaveTimer);
  pendingSaveTimer = setTimeout(async () => {
    pendingSaveTimer = null;
    try {
      pruneExpiredPendingRequests();
      const obj = Object.fromEntries(pendingRequests.entries());
      const jsonStr = JSON.stringify(obj);
      await fs.promises.writeFile(PENDING_FILE_PROJECT, jsonStr, 'utf-8');
      await fs.promises.writeFile(PENDING_FILE_TMP, jsonStr, 'utf-8').catch(() => {});
    } catch (err) {
      console.warn('Could not save pending requests cache:', err);
    }
  }, 500);
  pendingSaveTimer.unref?.();
}

export function flushPendingRequestsSync(): void {
  if (pendingSaveTimer) {
    clearTimeout(pendingSaveTimer);
    pendingSaveTimer = null;
  }
  try {
    pruneExpiredPendingRequests();
    const jsonStr = JSON.stringify(Object.fromEntries(pendingRequests.entries()));
    fs.writeFileSync(PENDING_FILE_PROJECT, jsonStr, 'utf-8');
    try {
      fs.writeFileSync(PENDING_FILE_TMP, jsonStr, 'utf-8');
    } catch {}
  } catch (err) {
    console.warn('Could not flush pending requests synchronously:', err);
  }
}

loadPendingRequests();

export function addLog(
  action: string,
  details: string,
  status: 'pending' | 'success' | 'error' = 'success',
  userId?: number | string,
  userName?: string,
  platform?: string
) {
  const log: BotActivityLog = {
    id: Math.random().toString(36).substring(2, 9),
    timestamp: new Date().toLocaleTimeString('fa-IR'),
    userId,
    userName,
    action,
    platform,
    details,
    status,
  };
  state.logs.unshift(log);
  if (state.logs.length > 60) {
    state.logs.pop();
  }
}

let pollingAbortController: AbortController | null = null;
let currentToken = (process.env.TELEGRAM_BOT_TOKEN || '').trim();
let activeClient: TelegramClient | null = null;

export function getWebhookSecretToken(token: string = currentToken): string {
  return crypto.createHash('sha256').update(`${token}:wh-secret`).digest('hex').slice(0, 32);
}

export function verifyWebhookSecret(headerVal?: string): boolean {
  if (!headerVal || typeof headerVal !== 'string' || !currentToken) return false;
  const expected = getWebhookSecretToken(currentToken);
  const a = Buffer.from(headerVal, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// Deduplication and anti-spam rate limiting
const processedMessageKeys = new Map<string, number>();
const processedUpdateIds = new Set<number>();
const pendingBlockedMessages = new Map<string, { msg: any; savedAt: number }>();
const userRateLimiter = new SlidingWindowRateLimiter(10, 30_000);
const rateLimitNoticeSent = new Map<string, number>();

// Polling watchdog to auto-recover if polling hangs or stops
let lastPollActivityTime = Date.now();
let watchdogTimer: NodeJS.Timeout | null = null;
let activePollGeneration = 0;
let isShuttingDown = false;
let inFlightMessagesCount = 0;

function ensureBotBridgeRegistered() {
  registerBotControlBridge({
    sendMessage: async (targetChatId, htmlText) => {
      const cli = activeClient || (currentToken ? new TelegramClient(currentToken) : null);
      if (!cli) throw new Error('Telegram client unavailable');
      await cli.sendMessage(targetChatId, htmlText, { parse_mode: 'HTML' });
    },
    getBotRuntimeSummary: () => ({
      isActive: state.isActive,
      isWebhookMode: state.isWebhookMode,
      botUsername: state.botInfo?.username,
      totalRequests: state.totalRequests,
      totalDownloads: state.totalDownloads,
      lastError: state.lastError,
      inFlightMessages: inFlightMessagesCount,
    }),
    restartBotConnection: async () => {
      const res = await startTelegramBot(currentToken || undefined);
      return { success: res.success, message: res.message };
    },
    flushStateSync: () => {
      flushPendingRequestsSync();
      flushBotUsersSync();
    },
    getHttpApiRunning: () => isHttpApiRunningFlag(),
  });
}
ensureBotBridgeRegistered();

function abortableSleep(ms: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) return Promise.resolve();
  return new Promise((resolve) => {
    const onAbort = () => {
      clearTimeout(timer);
      resolve();
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

function ensurePollingWatchdog(client: TelegramClient) {
  if (watchdogTimer) return;
  watchdogTimer = setInterval(() => {
    if (isShuttingDown || !state.isActive || state.isWebhookMode) return;
    const diff = Date.now() - lastPollActivityTime;
    if (diff > 90_000) {
      console.warn(`[Bot Watchdog] No polling activity detected for ${Math.round(diff / 1000)}s! Auto-restarting polling loop...`);
      addLog('بازیابی خودکار اتصال', 'واچ‌داگ عدم دریافت طولانی را شناسایی و اتصال را رفرش کرد.', 'pending');
      lastPollActivityTime = Date.now();
      if (pollingAbortController) {
        try { pollingAbortController.abort(); } catch {}
        pollingAbortController = null;
      }
      startPollingLoop(client);
    }
  }, 20_000);
  watchdogTimer.unref?.();
}

export function getBotState() {
  return {
    isActive: state.isActive,
    botInfo: state.botInfo,
    startTime: state.startTime,
    uptimeSeconds: Math.floor((Date.now() - state.startTime) / 1000),
    totalRequests: state.totalRequests,
    totalDownloads: state.totalDownloads,
    uniqueUsersCount: state.uniqueUsers.size,
    lastError: state.lastError,
    logs: state.logs,
    tokenMasked: currentToken ? `${currentToken.slice(0, 8)}...${currentToken.slice(-4)}` : 'None',
    isWebhookMode: state.isWebhookMode,
    webhookUrl: state.webhookUrl,
    downloadQueue: getDownloadQueueStats(),
  };
}

/**
 * Native Telegram API Client with timeouts, transient retry handling, and resilient HTML parse_mode
 */
export class TelegramClient {
  private token: string;
  private baseUrl: string;

  constructor(token: string) {
    this.token = token;
    this.baseUrl = `https://api.telegram.org/bot${token}`;
  }

  async callApi(endpoint: string, payload: any, isFormData: boolean = false): Promise<any> {
    const url = `${this.baseUrl}/${endpoint}`;
    const timeoutMs = isFormData ? 180_000 : 30_000;
    const maxAttempts = isFormData ? 1 : 3;

    let lastErr: any;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const options: RequestInit = {
          method: 'POST',
          signal: AbortSignal.timeout(timeoutMs),
        };

        if (isFormData) {
          options.body = payload;
        } else {
          options.headers = { 'Content-Type': 'application/json' };
          options.body = JSON.stringify(payload);
        }

        const response = await fetch(url, options);
        const data: any = await response.json();
        if (!data.ok) {
          const retryAfterSec = Number(data?.parameters?.retry_after || 0);
          const err = new Error(data.description || `Telegram API Error: ${response.status} ${response.statusText}`);
          if ((response.status === 429 || response.status >= 500) && attempt < maxAttempts) {
            const waitMs = retryAfterSec > 0 ? Math.min(retryAfterSec * 1000, 15_000) : calculateBackoffMs(attempt, 800, 5000);
            await abortableSleep(waitMs);
            continue;
          }
          throw err;
        }
        return data.result;
      } catch (err: any) {
        lastErr = err;
        const msg = String(err?.message || '').toLowerCase();
        const isClientError =
          msg.includes('bad request') ||
          msg.includes('unauthorized') ||
          msg.includes('forbidden') ||
          msg.includes('not found') ||
          msg.includes('conflict');

        if (isClientError || attempt >= maxAttempts) {
          throw err;
        }
        await abortableSleep(calculateBackoffMs(attempt, 800, 4000));
      }
    }
    throw lastErr;
  }

  async getMe() {
    return this.callApi('getMe', {});
  }

  async getChat(chatId: number | string) {
    return this.callApi('getChat', { chat_id: chatId });
  }

  async sendMessage(chatId: number | string, text: string, extra: any = {}) {
    return this.callApi('sendMessage', {
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      ...extra,
    });
  }

  async copyMessage(chatId: number | string, fromChatId: number | string, messageId: number, extra: any = {}) {
    return this.callApi('copyMessage', {
      chat_id: chatId,
      from_chat_id: fromChatId,
      message_id: messageId,
      ...extra,
    });
  }

  async forwardMessage(chatId: number | string, fromChatId: number | string, messageId: number) {
    return this.callApi('forwardMessage', {
      chat_id: chatId,
      from_chat_id: fromChatId,
      message_id: messageId,
    });
  }

  async deleteMessage(chatId: number | string, messageId: number) {
    try {
      return await this.callApi('deleteMessage', {
        chat_id: chatId,
        message_id: messageId,
      });
    } catch {
      return null;
    }
  }

  async editMessageText(chatId: number | string, messageId: number, text: string, extra: any = {}) {
    return this.callApi('editMessageText', {
      chat_id: chatId,
      message_id: messageId,
      text,
      parse_mode: 'HTML',
      ...extra,
    });
  }

  async sendPhoto(chatId: number | string, photoUrl: string, extra: any = {}) {
    return this.callApi('sendPhoto', {
      chat_id: chatId,
      photo: photoUrl,
      parse_mode: 'HTML',
      ...extra,
    });
  }

  async sendChatAction(chatId: number | string, action: 'typing' | 'upload_photo' | 'upload_video' | 'upload_audio' | 'upload_document') {
    try {
      return await this.callApi('sendChatAction', { chat_id: chatId, action });
    } catch {
      return null;
    }
  }

  async sendPhotoFile(chatId: number | string, filePath: string, caption: string, replyMarkup?: any) {
    const formData = new FormData();
    formData.append('chat_id', String(chatId));
    formData.append('caption', caption);
    formData.append('parse_mode', 'HTML');
    if (replyMarkup) formData.append('reply_markup', JSON.stringify(replyMarkup));

    const fileName = path.basename(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
    const blob = await openAsBlob(filePath, { type: mime });
    formData.append('photo', blob, fileName);

    return this.callApi('sendPhoto', formData, true);
  }

  async sendMediaGroup(chatId: number | string, items: { filePath: string; type: 'video' | 'photo' }[], caption?: string) {
    const formData = new FormData();
    formData.append('chat_id', String(chatId));

    const slice = items.slice(0, 10);
    const blobs = await Promise.all(
      slice.map((item) => {
        const ext = path.extname(item.filePath).toLowerCase();
        const mime = item.type === 'video' ? 'video/mp4' : ext === '.png' ? 'image/png' : 'image/jpeg';
        return openAsBlob(item.filePath, { type: mime });
      })
    );

    const mediaList = slice.map((item, idx) => {
      const attachKey = `file${idx}`;
      const fileName = path.basename(item.filePath);
      formData.append(attachKey, blobs[idx], fileName);

      return {
        type: item.type,
        media: `attach://${attachKey}`,
        caption: idx === 0 && caption ? caption : undefined,
        parse_mode: idx === 0 && caption ? 'HTML' : undefined,
      };
    });

    formData.append('media', JSON.stringify(mediaList));
    return this.callApi('sendMediaGroup', formData, true);
  }

  async answerCallbackQuery(callbackQueryId: string, extra: any = {}) {
    try {
      return await this.callApi('answerCallbackQuery', {
        callback_query_id: callbackQueryId,
        ...extra,
      });
    } catch {
      return null;
    }
  }

  async sendDocumentFile(chatId: number | string, filePath: string, caption: string, replyMarkup?: any) {
    const formData = new FormData();
    formData.append('chat_id', String(chatId));
    formData.append('caption', caption);
    formData.append('parse_mode', 'HTML');
    if (replyMarkup) formData.append('reply_markup', JSON.stringify(replyMarkup));

    const fileName = path.basename(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const mime = ext === '.mp4' ? 'video/mp4' : ext === '.mp3' ? 'audio/mpeg' : ext === '.webm' ? 'video/webm' : 'application/octet-stream';
    const blob = await openAsBlob(filePath, { type: mime });
    formData.append('document', blob, fileName);

    return this.callApi('sendDocument', formData, true);
  }

  async sendVideoFile(chatId: number | string, filePath: string, caption: string, replyMarkup?: any) {
    try {
      const formData = new FormData();
      formData.append('chat_id', String(chatId));
      formData.append('caption', caption);
      formData.append('parse_mode', 'HTML');
      formData.append('supports_streaming', 'true');
      if (replyMarkup) formData.append('reply_markup', JSON.stringify(replyMarkup));

      const fileName = path.basename(filePath);
      const ext = path.extname(filePath).toLowerCase();
      const mime = ext === '.webm' ? 'video/webm' : ext === '.mkv' ? 'video/x-matroska' : 'video/mp4';
      const blob = await openAsBlob(filePath, { type: mime });
      formData.append('video', blob, fileName);

      return await this.callApi('sendVideo', formData, true);
    } catch (err) {
      console.warn('[TelegramClient] sendVideo failed, falling back to sendDocument:', err);
      return this.sendDocumentFile(chatId, filePath, caption, replyMarkup);
    }
  }

  async sendAudioFile(chatId: number | string, filePath: string, caption: string, title?: string, performer?: string, replyMarkup?: any) {
    try {
      const formData = new FormData();
      formData.append('chat_id', String(chatId));
      formData.append('caption', caption);
      formData.append('parse_mode', 'HTML');
      if (title) formData.append('title', title.slice(0, 64));
      if (performer) formData.append('performer', performer.slice(0, 64));
      if (replyMarkup) formData.append('reply_markup', JSON.stringify(replyMarkup));

      const fileName = path.basename(filePath);
      const ext = path.extname(filePath).toLowerCase();
      const mime = ext === '.m4a' ? 'audio/mp4' : 'audio/mpeg';
      const blob = await openAsBlob(filePath, { type: mime });
      formData.append('audio', blob, fileName);

      return await this.callApi('sendAudio', formData, true);
    } catch (err) {
      console.warn('[TelegramClient] sendAudio failed, falling back to sendDocument:', err);
      return this.sendDocumentFile(chatId, filePath, caption, replyMarkup);
    }
  }

  async getChatMember(chatId: number | string, userId: number | string) {
    return this.callApi('getChatMember', {
      chat_id: chatId,
      user_id: userId,
    });
  }

  async getUpdates(offset: number, timeout: number = 25, signal?: AbortSignal) {
    const url = `${this.baseUrl}/getUpdates`;
    const timeoutSignal = AbortSignal.timeout((timeout + 15) * 1000);
    const combinedSignal = signal ? AbortSignal.any([signal, timeoutSignal]) : timeoutSignal;

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        offset,
        timeout,
        allowed_updates: ['message', 'callback_query'],
      }),
      signal: combinedSignal,
    });
    const data: any = await response.json();
    if (!data.ok) {
      const prefix = data.error_code ? `${data.error_code} ` : '';
      throw new Error(`${prefix}${data.description || 'Failed to fetch updates'}`);
    }
    return data.result;
  }

  async setWebhook(url: string) {
    return this.callApi('setWebhook', {
      url,
      allowed_updates: ['message', 'callback_query'],
      drop_pending_updates: false,
      secret_token: getWebhookSecretToken(this.token),
    });
  }

  async deleteWebhook(dropPendingUpdates: boolean = false) {
    return this.callApi('deleteWebhook', {
      drop_pending_updates: dropPendingUpdates,
    });
  }

  async getWebhookInfo() {
    return this.callApi('getWebhookInfo', {});
  }

  async getFile(fileId: string) {
    return this.callApi('getFile', { file_id: fileId });
  }

  getFileDownloadUrl(filePath: string): string {
    return `https://api.telegram.org/file/bot${this.token}/${filePath}`;
  }

  async pinChatMessage(chatId: number | string, messageId: number, disableNotification: boolean = true) {
    return this.callApi('pinChatMessage', {
      chat_id: chatId,
      message_id: messageId,
      disable_notification: disableNotification,
    });
  }
}

/**
 * Standard persistent Reply Keyboard
 */
function getPersistentReplyKeyboard(userId?: number | string) {
  const keyboard: any[] = [
    [{ text: '☕️ قهوه مهمونم کن' }, { text: '📖 آموزش استفاده' }],
    [{ text: '💡 ارسال پیشنهادات' }],
    [{ text: '📊 آمار من' }, { text: '🎫 پشتیبانی' }],
    [{ text: '🌐 زبان / Language' }],
  ];

  if (userId && isUserAdmin(userId)) {
    keyboard.unshift([{ text: '👑 پنل مدیریت ربات (ادمین)' }]);
  }

  return {
    keyboard,
    resize_keyboard: true,
    is_persistent: true,
  };
}

/**
 * Standard action buttons under messages
 */
function getMessageActionButtons() {
  const config = loadBotConfig();
  const botUsername = state.botInfo?.username;
  const row: any[] = [];
  if (botUsername) {
    row.push({ text: '➕ افزودن ربات به گروه', url: `https://t.me/${botUsername}?startgroup=true` });
  }
  if (config.mainChannelUrl && config.mainChannelUrl.startsWith('http')) {
    row.push({ text: '📢 چنل اصلی ↗️', url: config.mainChannelUrl });
  }
  return row.length > 0 ? [row] : [];
}

/**
 * Test if the bot can access a channel AND verify bot has Administrator permissions
 */
export async function testChannelAccess(channelId: string): Promise<{
  success: boolean;
  message: string;
  chatTitle?: string;
  normalizedId?: string;
  username?: string;
  url?: string;
}> {
  try {
    if (!currentToken) {
      return { success: false, message: 'توکن ربات تنظیم نشده است.' };
    }
    const norm = normalizeChannelIdentifier(channelId);
    if (!norm.chatId) {
      return {
        success: false,
        message: norm.error || 'شناسه یا آیدی کانال نامعتبر است.',
      };
    }

    const client = activeClient || new TelegramClient(currentToken);
    const chat = await client.getChat(norm.chatId);

    const botId = state.botInfo?.id || (await client.getMe()).id;
    let botMember: any = null;
    try {
      botMember = await client.getChatMember(chat.id, botId);
    } catch (memberErr: any) {
      return {
        success: false,
        message: `ربات در کانال «${chat.title || norm.chatId}» ادمین نیست! لطفاً ربات را در بخش Administrators کانال اضافه کنید (${memberErr?.message || 'بدون دسترسی'}).`,
      };
    }

    const botStatus = botMember?.status;
    if (botStatus !== 'administrator' && botStatus !== 'creator') {
      return {
        success: false,
        message: `ربات در کانال «${chat.title || norm.chatId}» ادمین نیست (وضعیت فعلی: ${botStatus || 'نامشخص'}). برای بررسی عضویت کاربران، ربات حتماً باید ادمین کانال باشد.`,
      };
    }

    let resolvedUrl = chat.username ? `https://t.me/${chat.username}` : (chat.invite_link || '');
    if (!resolvedUrl) {
      try {
        const exported = await client.callApi('exportChatInviteLink', { chat_id: chat.id });
        if (typeof exported === 'string' && exported.startsWith('http')) {
          resolvedUrl = exported;
        }
      } catch {}
    }

    return {
      success: true,
      message: `دسترسی ادمین ربات در کانال «${chat.title || norm.chatId}» تایید شد.`,
      chatTitle: chat.title || norm.chatId,
      normalizedId: String(chat.id),
      username: chat.username || '',
      url: resolvedUrl,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `خطا در دسترسی به کانال: ${err?.message || 'ربات را در کانال ادمین کنید.'}`,
    };
  }
}

/**
 * Verify if user is member of all mandatory channels (Force Subscribe)
 */
async function checkUserMembership(client: TelegramClient, userId: number | string): Promise<{
  isMember: boolean;
  pendingChannels: RequiredChannel[];
  configErrorChannels: RequiredChannel[];
}> {
  if (isUserAdmin(userId)) {
    return { isMember: true, pendingChannels: [], configErrorChannels: [] };
  }

  const config = loadBotConfig();
  if (!config.forceJoinEnabled || !config.channels || config.channels.length === 0) {
    return { isMember: true, pendingChannels: [], configErrorChannels: [] };
  }

  const numericUserId = Number(userId);
  const targetUser = Number.isSafeInteger(numericUserId) && numericUserId > 0 ? numericUserId : userId;

  const checks = await Promise.all(
    config.channels.map(async (channel): Promise<{ channel: RequiredChannel; status: 'joined' | 'not_joined' | 'config_error' }> => {
      const candidates: string[] = [];
      const norm = normalizeChannelIdentifier(channel.id);
      if (norm.chatId) candidates.push(norm.chatId);
      else if (channel.id?.trim()) candidates.push(channel.id.trim());

      if (channel.username) {
        const atUser = `@${channel.username.replace(/^@/, '').trim()}`;
        if (atUser.length > 1 && !candidates.includes(atUser)) {
          candidates.push(atUser);
        }
      }

      if (candidates.length === 0) {
        return { channel, status: 'config_error' };
      }

      let lastErrMsg = '';
      for (const chatTarget of candidates) {
        try {
          const member = await client.getChatMember(chatTarget, targetUser);
          if (isTelegramChatMemberStatusJoined(member)) {
            return { channel, status: 'joined' };
          }
          return { channel, status: 'not_joined' };
        } catch (err: any) {
          lastErrMsg = String(err?.message || err || '');
          if (!isChannelAdminConfigError(lastErrMsg)) {
            await abortableSleep(250);
            try {
              const retryMember = await client.getChatMember(chatTarget, targetUser);
              if (isTelegramChatMemberStatusJoined(retryMember)) {
                return { channel, status: 'joined' };
              }
              return { channel, status: 'not_joined' };
            } catch (retryErr: any) {
              lastErrMsg = String(retryErr?.message || retryErr || '');
            }
          }
        }
      }

      if (isChannelAdminConfigError(lastErrMsg)) {
        console.warn(`[ForceJoin] Bot/channel access error for ${channel.id}: ${lastErrMsg}`);
        addLog('خطای پیکربندی کانال اجباری', `ربات در کانال ${channel.title || channel.id} ادمین نیست یا شناسه نامعتبر است (${lastErrMsg})`, 'error', userId);
        return { channel, status: 'config_error' };
      }

      return { channel, status: 'not_joined' };
    })
  );

  const pendingChannels = checks.filter((c) => c.status === 'not_joined').map((c) => c.channel);
  const configErrorChannels = checks.filter((c) => c.status === 'config_error').map((c) => c.channel);

  return {
    isMember: pendingChannels.length === 0,
    pendingChannels,
    configErrorChannels,
  };
}

function buildForceJoinPayload(pendingChannels: RequiredChannel[]) {
  const buttons: any[] = [];
  const channelNames: string[] = [];

  for (const ch of pendingChannels) {
    const cleanUser = ch.username ? ch.username.replace(/^@/, '').trim() : '';
    const url = (ch.url && ch.url.startsWith('http'))
      ? ch.url
      : cleanUser
      ? `https://t.me/${cleanUser}`
      : undefined;
    const label = ch.title || (cleanUser ? `@${cleanUser}` : ch.id);
    channelNames.push(`• <b>${escapeHtml(label)}</b>`);
    if (url) {
      buttons.push([{ text: `📢 عضویت در ${label}`, url }]);
    }
  }
  buttons.push([{ text: '✅ تایید و بررسی مجدد عضویت', callback_data: 'verify_sub' }]);

  const text =
`🔒 <b>برای استفاده از ربات، عضویت در کانال‌های زیر الزامی است!</b>
━━━━━━━━━━━━━━━━━━━━
${channelNames.join('\n')}

برای فعال‌سازی و دانلود نامحدود، لطفاً ابتدا در کانال‌های بالا عضو شده و سپس دکمه <b>«✅ تایید و بررسی مجدد عضویت»</b> را لمس کنید:`;

  return {
    text,
    reply_markup: { inline_keyboard: buttons },
  };
}

async function sendForceJoinNotice(client: TelegramClient, chatId: number | string, pendingChannels: RequiredChannel[]) {
  const payload = buildForceJoinPayload(pendingChannels);
  await client.sendMessage(chatId, payload.text, {
    parse_mode: 'HTML',
    reply_markup: payload.reply_markup,
  });
}

async function sendStartMessage(client: TelegramClient, chatId: number | string, userName: string, userId?: number | string) {
  const cfg = loadBotConfig();
  const customWelcome = (cfg.general.welcomeMessage || '').trim();
  const startMsg = customWelcome
    ? customWelcome.replace(/\{name\}|\{user\}/gi, escapeHtml(userName))
    : `✨ <b>به ربات دانلودر چندمنظوره و موزیک‌یاب خوش آمدید</b> ✨
━━━━━━━━━━━━━━━━━━━━

سلام <b>${escapeHtml(userName)}</b> عزیز ✋
اینجا می‌توانید ویدیو و موزیک موردعلاقه‌تان را سریع، ساده و با بالاترین کیفیت دانلود کنید 🚀

📥 <b>امکانات پیشرفته ربات:</b>

📷 <b>اینستاگرام (Instagram)</b>
└ ریلز، پست‌ها، اسلایدی + همراه با کپشن کامل + دکمه استخراج صدای ویدیو (MP3) ⚡

🟢 <b>اسپاتیفای (Spotify)</b>
└ دانلود مستقیم آهنگ و نمایش ترک‌های آلبوم/پلی‌لیست با کیفیت اورجینال MP3 🎵

📻 <b>ساندکلود (SoundCloud)</b>
└ استخراج و دریافت فایل صوتی با کیفیت استودیویی

▶️ <b>یوتیوب (YouTube & Shorts)</b>
└ کیفیت‌های 360p تا 1080p FHD و صوت MP3

🎵 <b>تیک‌تاک (TikTok)</b>
└ دانلود ویدیوها بدون واترمارک + صوت اورجینال

✖️ <b>توییتر / X و پینترست</b>
└ ویدیوها و تصاویر با بالاترین رزولوشن

🌐 <b>دانلودر همه‌سایت‌ها</b>
└ پشتیبانی از بیش از ۱۰۰۰ سایت ویدیویی و پلتفرم آنلاین 🔥

━━━━━━━━━━━━━━━━━━━━
🐸 <b>همین حالا شروع کنید! کافیست لینک ویدیو یا موزیک را ارسال کنید 👇</b>`;

  await client.sendMessage(chatId, startMsg, {
    parse_mode: 'HTML',
    reply_markup: getPersistentReplyKeyboard(userId ?? chatId),
  });
}

async function deliverSpotifyTrack(
  client: TelegramClient,
  chatId: number | string,
  trackUrl: string,
  progressMsgId: number,
  userId: number | string,
  userName: string
) {
  const cfg = loadBotConfig();
  try {
    const spotifyInfo = await extractSpotifyInfo(trackUrl);

    await client.editMessageText(
      chatId,
      progressMsgId,
      formatDownloadLoadingText({ percent: 45, stage: 'downloading', isSongFinder: true }),
      { parse_mode: 'HTML' }
    ).catch(() => {});

    await ensureYtDlpExecutable();
    const result = await downloadSpotifyTrack(spotifyInfo);
    state.totalDownloads++;
    incrementUserDownloadCount(userId);
    recordUserRequestLog({
      userId,
      platform: 'spotify',
      url: trackUrl,
      action: 'spotify_track',
      qualityId: cfg.spotify.defaultQuality,
      status: 'success',
    });

    await client.editMessageText(
      chatId,
      progressMsgId,
      formatDownloadLoadingText({ percent: 100, stage: 'uploading', isSongFinder: true }),
      { parse_mode: 'HTML' }
    ).catch(() => {});

    const botUsername = state.botInfo?.username || 'Bot';
    const qualityLabel = cfg.spotify.defaultQuality || '320kbps';
    const previewNote = result.isAudioPreviewOnly ? '\n⚠️ <i>نسخه پیش‌نمایش ۳۰ ثانیه‌ای اسپاتیفای</i>' : '';
    const audioCaption =
`🎵 <b>${escapeHtml(spotifyInfo.title)}</b>
👤 <b>هنرمند:</b> ${escapeHtml(spotifyInfo.artist)}
${spotifyInfo.album ? `💿 <b>آلبوم:</b> ${escapeHtml(spotifyInfo.album)}\n` : ''}📦 <b>حجم:</b> ${result.fileSizeFormatted}
⚡ <b>کیفیت:</b> ${escapeHtml(qualityLabel)}${previewNote}
🔗 @${botUsername}`;

    const actionButtons = { inline_keyboard: getMessageActionButtons() };

    await client.sendAudioFile(
      chatId,
      result.filePath,
      audioCaption,
      spotifyInfo.title,
      spotifyInfo.artist,
      actionButtons.inline_keyboard.length > 0 ? actionButtons : undefined
    );

    await client.deleteMessage(chatId, progressMsgId);
    addLog('دانلود اسپاتیفای موفق', `${spotifyInfo.artist} - ${spotifyInfo.title}`, 'success', userId, userName, 'spotify');
  } catch (err: any) {
    console.error('Spotify download error:', err);
    addLog('خطا در دانلود اسپاتیفای', err?.message || 'خطا', 'error', userId, userName, 'spotify');
    recordUserRequestLog({
      userId,
      platform: 'spotify',
      url: trackUrl,
      action: 'spotify_track',
      status: 'error',
      errorMessage: err?.message || 'Spotify error',
    });
    const customErr = (cfg.general.errorMessage || '').trim();
    const errText = customErr
      ? `❌ <b>${escapeHtml(customErr)}</b>`
      : '❌ <b>متاسفانه در دریافت این قطعه اسپاتیفای خطایی رخ داد.</b>\nلطفاً لینک را بررسی کرده و مجدد تلاش کنید.';
    await client.editMessageText(
      chatId,
      progressMsgId,
      errText,
      { parse_mode: 'HTML' }
    ).catch(() => {});
  }
}

/**
 * Handle incoming user message
 */
async function handleIncomingMessage(client: TelegramClient, msg: any) {
  inFlightMessagesCount++;
  try {
    const chatId = msg.chat?.id;
    const messageId = msg.message_id;
    const text = (msg.text || '').trim();
    const userName = msg.from?.first_name || 'کاربر';
    const userId = Number(msg.from?.id || chatId);

    if (!chatId || !messageId) return;

    const msgKey = `${chatId}_${messageId}`;
    if (processedMessageKeys.has(msgKey)) {
      return;
    }
    processedMessageKeys.set(msgKey, Date.now());
    if (processedMessageKeys.size > 2000) {
      const cutoff = Date.now() - 3_600_000;
      for (const [k, v] of processedMessageKeys) {
        if (v < cutoff) processedMessageKeys.delete(k);
      }
    }

    state.totalRequests++;
    state.uniqueUsers.add(userId);
    const activityRes = upsertUserActivity(userId, {
      firstName: msg.from?.first_name,
      username: msg.from?.username,
    });
    const isAdminActor = isUserAdmin(userId);
    if (isAdminActor) {
      touchAdminActivity(userId);
    }

    // Per-user ban enforcement (never applies to admins)
    if (!isAdminActor && activityRes.profile?.isBanned) {
      const reason = activityRes.profile.banReason
        ? `\n📝 دلیل: ${escapeHtml(activityRes.profile.banReason)}`
        : '';
      await client.sendMessage(
        chatId,
        `🚫 <b>حساب شما موقتاً از استفاده از ربات مسدود شده است.</b>${reason}`,
        { parse_mode: 'HTML' }
      ).catch(() => {});
      return;
    }

    // Per-user anti-spam rate limiting (admins exempted)
    if (!isAdminActor) {
      const rl = userRateLimiter.check(String(userId));
      if (!rl.allowed) {
        const now = Date.now();
        const lastWarn = rateLimitNoticeSent.get(String(userId)) || 0;
        if (now - lastWarn > 15_000) {
          rateLimitNoticeSent.set(String(userId), now);
          await client.sendMessage(
            chatId,
            `⏳ <b>لطفاً کمی صبر کنید!</b>\nتعداد درخواست‌های شما در لحظه بیش از حد مجاز است. لطفاً ${Math.ceil(rl.retryAfterMs / 1000)} ثانیه دیگر مجدد تلاش کنید.`,
            { parse_mode: 'HTML' }
          ).catch(() => {});
        }
        return;
      }
    }

    // 1. If admin is currently in an interactive input step
    if (isAdminActor) {
      const handledStep = await handleAdminMessageStep(client, msg);
      if (handledStep) return;
    }

    // 2. Admin Panel Command / Button Check (strictly verify msg.from.id server-side)
    const cleanCmd = text.toLowerCase().trim();
    const isAdminCommand =
      cleanCmd === '/admin' ||
      cleanCmd === 'admin' ||
      cleanCmd.startsWith('/admin@') ||
      cleanCmd === '/panel' ||
      cleanCmd === 'panel' ||
      cleanCmd.startsWith('/panel@') ||
      text === '👑 پنل مدیریت ربات (ادمین)' ||
      text === 'پنل مدیریت' ||
      text === 'پنل ادمین';

    if (isAdminCommand) {
      if (isAdminActor) {
        await sendAdminDashboard(client, chatId, undefined, userId);
        return;
      } else {
        recordAuditLog({
          actorId: userId,
          action: 'unauthorized_admin_command',
          section: 'security',
          newValue: text.slice(0, 60),
          result: 'denied',
        });
        addLog('تلاش غیرمجاز پنل مدیریت', `کاربر ${userName} (${userId}) قصد باز کردن /admin داشت`, 'error', userId, userName);
        await client.sendMessage(
          chatId,
          `⛔️ <b>دسترسی غیرمجاز!</b>\nاین بخش اختصاصی است و فقط توسط مدیران ربات قابل دسترسی می‌باشد.\n\n🆔 شناسه کاربری شما: <code>${userId}</code>`,
          { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) }
        );
        return;
      }
    }

    const config = loadBotConfig();

    // 3. New user registration disabled guard
    if (!activityRes.allowed && !isAdminActor) {
      await client.sendMessage(
        chatId,
        '⏸ <b>عضویت کاربران جدید در حال حاضر موقتاً غیرفعال شده است.</b>\nلطفاً بعداً مجدداً تلاش کنید.',
        { parse_mode: 'HTML' }
      ).catch(() => {});
      return;
    }

    // 4. Bot temporarily disabled or Maintenance Mode guard (admins exempted)
    if (!isAdminActor && (!config.general.botEnabled || config.general.maintenanceMode)) {
      const maintText = (config.general.maintenanceMessage || '').trim()
        || '🛠 <b>ربات موقتاً جهت نگهداری و بروزرسانی در دسترس نیست.</b>\nلطفاً ساعاتی دیگر مجدداً تلاش فرمایید.';
      await client.sendMessage(chatId, maintText, { parse_mode: 'HTML' }).catch(() => {});
      return;
    }

    // Check persistent reply buttons
    if (text === '📖 آموزش استفاده') {
      const customHelp = (config.general.helpMessage || '').trim();
      const helpText = customHelp ||
`📖 <b>آموزش استفاده سریع از ربات:</b>
━━━━━━━━━━━━━━━━━━━━
1️⃣ لینک هر ویدیو یا آهنگ از <b>اینستاگرام، اسپاتیفای، یوتیوب، ساندکلود یا تیک‌تاک</b> را کپی کنید.
2️⃣ لینک را به همین صفحه بفرستید.
3️⃣ برای اینستاگرام و اسپاتیفای فایل فوراً همراه با کپشن ارسال می‌شود. برای یوتیوب کیفیت دلخواه را انتخاب کنید!

⚡ بدون افت کیفیت و بدون نیاز به فیلترشکن برای دانلود فایل‌ها!`;
      await client.sendMessage(chatId, helpText, { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) });
      return;
    }

    if (text === '☕️ قهوه مهمونم کن') {
      await client.sendMessage(chatId, '❤️ <b>از محبت و حمایت شما سپاسگزاریم!</b>\nبرای حمایت از توسعه ربات، آن را به دوستان و گروه‌های خود معرفی کنید.', { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) });
      return;
    }

    if (text === '💡 ارسال پیشنهادات') {
      await client.sendMessage(chatId, '💡 <b>ارسال پیشنهادات:</b>\nهر ایده یا قابلیتی که مایلید به ربات اضافه شود را برای ما بنویسید تا بررسی گردد.', { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) });
      return;
    }

    if (text === '📊 آمار من') {
      const profile = activityRes.profile || getUserProfile(userId);
      const quota = checkUserDailyQuota(userId);
      const quotaLine = quota.limit > 0 ? `${quota.usedToday} از ${quota.limit}` : `${quota.usedToday} (نامحدود)`;
      await client.sendMessage(
        chatId,
        `📊 <b>مشخصات حساب کاربری:</b>\n🆔 شناسه کاربری: <code>${userId}</code>\n👤 نام: ${escapeHtml(userName)}\n📥 دانلودهای شما: <b>${profile?.totalDownloads ?? 0}</b>\n📆 سهمیه امروز: <b>${quotaLine}</b>`,
        { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) }
      );
      return;
    }

    if (text === '🎫 پشتیبانی') {
      const customSupport = (config.general.supportMessage || '').trim();
      const supText = customSupport
        ? `${customSupport}\n\n🆔 @${escapeHtml(config.supportUsername || 'admin')}`
        : `🎫 <b>ارتباط با پشتیبانی:</b>\nدر صورت بروز هرگونه مشکل یا سوال، با آیدی پشتیبانی در ارتباط باشید:\n@${escapeHtml(config.supportUsername || 'admin')}`;
      await client.sendMessage(chatId, supText, { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) });
      return;
    }

    if (text === '🌐 زبان / Language') {
      await client.sendMessage(chatId, '🌐 زبان فعال ربات: <b>فارسی (Persian) 🇮🇷</b>', { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) });
      return;
    }

    // Mandatory Channel Join Check (Force Subscribe)
    const membership = await checkUserMembership(client, userId);
    if (!membership.isMember) {
      if (text && !text.startsWith('/start')) {
        pendingBlockedMessages.set(String(userId), { msg, savedAt: Date.now() });
        if (pendingBlockedMessages.size > 1000) {
          const cutoff = Date.now() - 15 * 60_000;
          for (const [k, v] of pendingBlockedMessages) {
            if (v.savedAt < cutoff) pendingBlockedMessages.delete(k);
          }
        }
      }
      addLog('قفل جوین اجباری', `کاربر ${userName} هنوز در کانال‌ها عضو نشده است`, 'pending', userId, userName);
      await sendForceJoinNotice(client, chatId, membership.pendingChannels);
      return;
    }

    // Command: /start & /help
    if (text.startsWith('/start')) {
      addLog('دستور /start', `کاربر ${userName} ربات را استارت کرد`, 'success', userId, userName);
      await sendStartMessage(client, chatId, userName, userId);
      return;
    }

    if (text.startsWith('/help')) {
      const customHelp = (config.general.helpMessage || '').trim();
      if (customHelp) {
        await client.sendMessage(chatId, customHelp, { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) });
      } else {
        await sendStartMessage(client, chatId, userName, userId);
      }
      return;
    }

    // URL Extraction
    const extractedUrl = extractUrl(text);
    if (!extractedUrl) {
      await client.sendMessage(
        chatId,
`⚠️ <b>لطفاً یک لینک معتبر از شبکه‌های اجتماعی یا موزیک ارسال کنید.</b>
━━━━━━━━━━━━━━━━━━━━
نمونه‌های پشتیبانی شده:
• <b>اینستاگرام:</b> https://www.instagram.com/reel/... یا /p/...
• <b>یوتیوب:</b> https://youtu.be/... یا /watch?v=...
• <b>اسپاتیفای:</b> https://open.spotify.com/track/...
• <b>ساندکلود:</b> https://soundcloud.com/...
• <b>تیک‌تاک:</b> https://vm.tiktok.com/...`,
        { parse_mode: 'HTML', reply_markup: getPersistentReplyKeyboard(userId) }
      );
      return;
    }

    // Download Service global switch check
    if (!config.general.downloadsServiceEnabled || !config.download.enabled) {
      await client.sendMessage(
        chatId,
        '⏸ <b>سرویس دانلود فایل موقتاً توسط مدیریت متوقف شده است.</b>\nلطفاً ساعاتی دیگر مجدداً تلاش کنید.',
        { parse_mode: 'HTML' }
      );
      return;
    }

    const platformInfo = identifyPlatform(extractedUrl);
    addLog('دریافت لینک', `دریافت لینک از ${platformInfo.platformNameFa}`, 'pending', userId, userName, platformInfo.platform);
    client.sendChatAction(chatId, 'typing').catch(() => {});

    // 1. INSTAGRAM FLOW
    if (platformInfo.platform === 'instagram') {
      const quota = checkUserDailyQuota(userId);
      if (!quota.allowed) {
        await client.sendMessage(
          chatId,
          `⚠️ <b>سهمیه دانلود روزانه شما به پایان رسیده است.</b>\n(${quota.usedToday} از ${quota.limit} دانلود مجاز امروز)`,
          { parse_mode: 'HTML' }
        );
        return;
      }

      const initialText = formatDownloadLoadingText({
        percent: 5,
        stage: 'downloading',
      });
      const progressMsg = await client.sendMessage(chatId, initialText, { parse_mode: 'HTML' });

      let lastEditTime = Date.now();
      let lastPercent = 5;

      const onIgProgress = async (prog: DownloadProgress) => {
        const now = Date.now();
        const currentP = Math.floor(prog.percent);
        if (now - lastEditTime < 1400 && currentP !== 100) return;
        if (currentP === lastPercent && currentP !== 100) return;
        lastEditTime = now;
        lastPercent = currentP;

        const progressText = formatDownloadLoadingText({
          percent: prog.percent,
          downloadedFormatted: prog.downloadedFormatted,
          totalFormatted: prog.totalFormatted,
          speedFormatted: prog.speedFormatted,
          etaFormatted: prog.etaFormatted,
          stage: prog.stage,
        });

        try {
          await client.editMessageText(chatId, progressMsg.message_id, progressText, { parse_mode: 'HTML' });
        } catch {}
      };

      try {
        const igResult = await downloadInstagramPost(extractedUrl, onIgProgress, userId);
        state.totalDownloads++;
        incrementUserDownloadCount(userId);
        recordUserRequestLog({
          userId,
          platform: 'instagram',
          url: extractedUrl,
          action: 'instagram_post',
          status: 'success',
        });

        try {
          await client.editMessageText(
            chatId,
            progressMsg.message_id,
            formatDownloadLoadingText({ percent: 100, stage: 'uploading' }),
            { parse_mode: 'HTML' }
          );
        } catch {}

        const botUsername = state.botInfo?.username || 'Bot';
        const cleanCaption = igResult.caption.trim();
        const truncatedCaption = cleanCaption.length > 700 ? cleanCaption.slice(0, 700) + '...' : cleanCaption;

        const fullCaption =
`📷 <b>پست اینستاگرام</b>
━━━━━━━━━━━━━━━━━━━━
${escapeHtml(truncatedCaption || igResult.title || 'رسانه اینستاگرام')}

👤 <b>صفحه / سازنده:</b> ${escapeHtml(igResult.uploader)}
🔗 @${botUsername}`;

        const shortHash = crypto.createHash('md5').update(extractedUrl).digest('hex').slice(0, 10);
        const reqKey = `${chatId}_${shortHash}`;

        const firstVideoItem = igResult.items.find((item) => item.type === 'video');
        pendingRequests.set(reqKey, {
          url: extractedUrl,
          title: igResult.title || truncatedCaption || 'Instagram Audio',
          uploader: igResult.uploader,
          duration: '0',
          platform: 'instagram',
          createdAt: Date.now(),
          localFilePath: firstVideoItem?.filePath,
        });
        savePendingRequests();

        const customIgKeyboard: any[] = [];
        if (firstVideoItem) {
          customIgKeyboard.push([
            { text: '🎵 استخراج صدای ویدیو (MP3 320k)', callback_data: `dl_ig_audio:${reqKey}` }
          ]);
        }
        customIgKeyboard.push(...getMessageActionButtons());
        const actionButtons = customIgKeyboard.length > 0 ? { inline_keyboard: customIgKeyboard } : undefined;

        if (igResult.items.length === 1) {
          const singleItem = igResult.items[0];
          client.sendChatAction(chatId, singleItem.type === 'video' ? 'upload_video' : 'upload_photo').catch(() => {});
          if (singleItem.type === 'video') {
            await client.sendVideoFile(chatId, singleItem.filePath, fullCaption, actionButtons);
          } else {
            await client.sendPhotoFile(chatId, singleItem.filePath, fullCaption, actionButtons);
          }
        } else if (igResult.items.length > 1) {
          await client.sendMediaGroup(chatId, igResult.items, fullCaption);
          await client.sendMessage(chatId, '👆 <b>تمام اسلایدهای این پست با موفقیت ارسال شد.</b>', {
            parse_mode: 'HTML',
            reply_markup: actionButtons,
          });
        }

        await client.deleteMessage(chatId, progressMsg.message_id);
        addLog('دانلود اینستاگرام موفق', `${igResult.uploader} (${igResult.items.length} فایل)`, 'success', userId, userName, 'instagram');
      } catch (err: any) {
        console.error('Instagram auto-download error:', err);
        const errMsg = err?.message || '';
        const isAudienceRestricted = errMsg.includes('not available to everyone') || errMsg.includes('certain audiences');
        const isLoginRequired = isAudienceRestricted || errMsg.includes('login page') || errMsg.includes('cookies');

        addLog('خطا در دانلود اینستاگرام', isAudienceRestricted ? 'محدودیت اینستاگرام' : isLoginRequired ? 'نیاز به سشن' : errMsg, 'error', userId, userName, 'instagram');
        recordUserRequestLog({
          userId,
          platform: 'instagram',
          url: extractedUrl,
          action: 'instagram_post',
          status: 'error',
          errorMessage: errMsg,
        });

        if (isAudienceRestricted || isLoginRequired) {
          await client.editMessageText(
            chatId,
            progressMsg.message_id,
            `⚠️ <b>محدودیت دسترسی اینستاگرام (Audience Restricted)</b>\n\nاین پست دارای محدودیت سنی یا منطقه‌ای است.\n\n🔑 <b>راه حل مدیر ربات:</b> در تلگرام وارد <b>/admin ➔ 📷 کوکی‌ها</b> شوید و مقدار <code>sessionid</code> معتبر را ثبت کنید.`,
            { parse_mode: 'HTML' }
          );
        } else {
          const customErr = (config.general.errorMessage || '').trim();
          await client.editMessageText(
            chatId,
            progressMsg.message_id,
            customErr
              ? `❌ <b>${escapeHtml(customErr)}</b>`
              : '❌ <b>متاسفانه در استخراج فایل‌های این پست اینستاگرام خطایی رخ داد.</b>\nلطفاً لینک را بررسی کرده یا مجدد تلاش فرمایید.',
            { parse_mode: 'HTML' }
          );
        }
      }
      return;
    }

    // 2. SPOTIFY FLOW (Track, Album, or Playlist)
    if (platformInfo.platform === 'spotify') {
      if (!config.spotify.enabled) {
        await client.sendMessage(
          chatId,
          '🟢 <b>بخش دانلود از اسپاتیفای موقتاً توسط مدیریت غیرفعال شده است.</b>',
          { parse_mode: 'HTML' }
        );
        return;
      }

      const collectionTarget = extractSpotifyCollectionTarget(extractedUrl);
      if (collectionTarget) {
        if (
          (collectionTarget.type === 'album' && !config.spotify.allowAlbum) ||
          (collectionTarget.type === 'playlist' && !config.spotify.allowPlaylist)
        ) {
          await client.sendMessage(
            chatId,
            `⚠️ <b>دانلود ${collectionTarget.type === 'album' ? 'آلبوم' : 'پلی‌لیست'} اسپاتیفای در حال حاضر توسط مدیریت محدود شده است.</b>`,
            { parse_mode: 'HTML' }
          );
          return;
        }

        const statusMsg = await client.sendMessage(chatId, '🟢 <b>در حال دریافت لیست ترک‌های اسپاتیفای...</b>', { parse_mode: 'HTML' });
        const collection = await extractSpotifyCollection(extractedUrl);

        if (!collection || collection.tracks.length === 0) {
          await client.editMessageText(
            chatId,
            statusMsg.message_id,
            '⚠️ <b>امکان استخراج ترک‌های این آلبوم/پلی‌لیست وجود نداشت.</b>\nلطفاً لینک مستقیم هر آهنگ (<code>open.spotify.com/track/...</code>) را ارسال کنید.',
            { parse_mode: 'HTML' }
          );
          return;
        }

        const maxTracks = Math.max(1, Math.min(30, config.spotify.maxPlaylistTracks || 15));
        const limitedTracks = collection.tracks.slice(0, maxTracks);

        const shortHash = crypto.createHash('md5').update(extractedUrl).digest('hex').slice(0, 10);
        const reqKey = `${chatId}_${shortHash}`;
        pendingRequests.set(reqKey, {
          url: extractedUrl,
          title: collection.title,
          uploader: collection.creator,
          duration: String(collection.totalTracks),
          platform: 'spotify',
          createdAt: Date.now(),
          tracks: limitedTracks,
        });
        savePendingRequests();

        const trackButtons = limitedTracks.map((t, idx) => [
          {
            text: `🎵 ${idx + 1}. ${t.title.slice(0, 28)} — ${t.artist.slice(0, 18)}`,
            callback_data: `sp:${reqKey}:${idx}`,
          },
        ]);
        trackButtons.push(...getMessageActionButtons());

        const typeFa = collection.type === 'playlist' ? 'پلی‌لیست' : 'آلبوم';
        const textMsg =
`🟢 <b>${typeFa} اسپاتیفای: ${escapeHtml(collection.title)}</b>
━━━━━━━━━━━━━━━━━━━━
👤 <b>سازنده / هنرمند:</b> ${escapeHtml(collection.creator)}
🎶 <b>تعداد کل ترک‌ها:</b> ${collection.totalTracks} (نمایش ${limitedTracks.length} ترک)

👇 <i>روی هر آهنگ کلیک کنید تا دانلود و ارسال شود:</i>`;

        await client.editMessageText(chatId, statusMsg.message_id, textMsg, {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: trackButtons },
        });
        return;
      }

      if (!config.spotify.allowTrack) {
        await client.sendMessage(
          chatId,
          '⚠️ <b>دانلود تک‌آهنگ اسپاتیفای در حال حاضر غیرفعال است.</b>',
          { parse_mode: 'HTML' }
        );
        return;
      }

      const quota = checkUserDailyQuota(userId);
      if (!quota.allowed) {
        await client.sendMessage(
          chatId,
          `⚠️ <b>سهمیه دانلود روزانه شما به پایان رسیده است.</b>\n(${quota.usedToday} از ${quota.limit} دانلود مجاز امروز)`,
          { parse_mode: 'HTML' }
        );
        return;
      }

      const queueStats = getDownloadQueueStats();
      const queuePos = queueStats.active + queueStats.pending + 1;
      const queueMsgText =
`درخواست شما در صف قرار گرفت 🟢
━━━━━━━━━━━━━━━━━━━━
📍 <b>موقعیت در صف: ${queuePos}</b>
🔄 به زودی آهنگ شما آماده می‌شود...`;

      const queueMsg = await client.sendMessage(chatId, queueMsgText, { parse_mode: 'HTML' });
      await deliverSpotifyTrack(client, chatId, extractedUrl, queueMsg.message_id, userId, userName);
      return;
    }

  // 3. YOUTUBE / SOUNDCLOUD / TIKTOK / OTHER FLOW (Quality selector)
  let statusMsg: any = null;
  let timerDone = false;
  const cached = getCachedMediaInfo(extractedUrl);

  const statusTimer = setTimeout(async () => {
    if (!timerDone) {
      try {
        statusMsg = await client.sendMessage(
          chatId,
          `🔍 <b>در حال آنالیز و دریافت لینک از ${escapeHtml(platformInfo.platformNameFa)}...</b> لطفاً کمی صبر کنید.`,
          { parse_mode: 'HTML' }
        );
      } catch {}
    }
  }, 500);

  try {
    const info = cached || await extractMediaInfo(extractedUrl);
    timerDone = true;
    clearTimeout(statusTimer);

    const shortHash = crypto.createHash('md5').update(extractedUrl).digest('hex').slice(0, 10);
    const reqKey = `${chatId}_${shortHash}`;

    pendingRequests.set(reqKey, {
      url: extractedUrl,
      title: info.title,
      uploader: info.uploader,
      duration: info.durationFormatted,
      platform: platformInfo.platform,
      createdAt: Date.now(),
    });
    savePendingRequests();

    let caption = '';
    const keyboard: any[] = [];
    const botUsername = state.botInfo?.username || 'Bot';

    if (platformInfo.platform === 'soundcloud') {
      caption =
`🎵 <b>${escapeHtml(info.title.slice(0, 100))}</b>

👤 <b>هنرمند:</b> ${escapeHtml(info.artist || info.uploader)}
${info.album ? `💿 <b>آلبوم:</b> ${escapeHtml(info.album)}\n` : ''}${info.genre ? `🎚 <b>سبک موزیک:</b> ${escapeHtml(info.genre)}\n` : ''}⏱ <b>مدت زمان:</b> ${escapeHtml(info.durationFormatted)}
🌐 <b>سرویس:</b> ساندکلود (SoundCloud)

👇 <b>کیفیت مورد نظر جهت دانلود را انتخاب کنید:</b>`;

      keyboard.push(
        [{ text: '🎵 دانلود کیفیت عالی (320kbps MP3)', callback_data: `dl:${reqKey}:best_audio` }],
        [{ text: '🎧 دانلود کیفیت سبک (128kbps)', callback_data: `dl:${reqKey}:standard_audio` }]
      );
    } else {
      const viewsFormatted = info.viewCount ? new Intl.NumberFormat('fa-IR').format(info.viewCount) : null;
      caption =
`🎬 <b>پیش‌نمایش ویدیو ${escapeHtml(platformInfo.platformNameFa)}</b>
━━━━━━━━━━━━━━━━━━━━
📌 <b>عنوان:</b> ${escapeHtml(info.title.slice(0, 120))}

👤 <b>صفحه / کانال:</b> ${escapeHtml(info.uploader)}
⏱ <b>مدت زمان:</b> ${escapeHtml(info.durationFormatted)}${viewsFormatted ? `\n👁 <b>تعداد بازدید:</b> ${viewsFormatted}` : ''}
🔗 @${botUsername}

👇 <b>کیفیت‌های موجود برای این ویدیو:</b>`;

      const videoFormats = info.availableFormats.filter((f) => !f.isAudioOnly);
      for (let i = 0; i < videoFormats.length; i += 2) {
        const row = [
          { text: videoFormats[i].labelFa || videoFormats[i].label, callback_data: `dl:${reqKey}:${videoFormats[i].id}` }
        ];
        if (videoFormats[i + 1]) {
          row.push({
            text: videoFormats[i + 1].labelFa || videoFormats[i + 1].label,
            callback_data: `dl:${reqKey}:${videoFormats[i + 1].id}`
          });
        }
        keyboard.push(row);
      }

      const audioFormats = info.availableFormats.filter((f) => f.isAudioOnly);
      for (const af of audioFormats) {
        keyboard.push([
          { text: af.labelFa || af.label, callback_data: `dl:${reqKey}:${af.id}` }
        ]);
      }
    }

    keyboard.push(...getMessageActionButtons());

    if (statusMsg) {
      await client.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
    }

    let sentPreview = false;
    if (info.thumbnail && info.thumbnail.startsWith('http')) {
      try {
        await client.sendPhoto(chatId, info.thumbnail, {
          caption,
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: keyboard },
        });
        sentPreview = true;
      } catch (photoErr) {
        console.warn('[TelegramBot] sendPhoto preview failed, fallback to text message:', photoErr);
      }
    }

    if (!sentPreview) {
      await client.sendMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: keyboard },
      });
    }
    addLog('آنالیز لینک موفق', `${info.title} (${platformInfo.platformNameFa})`, 'success', userId, userName, platformInfo.platform);
  } catch (err: any) {
    timerDone = true;
    clearTimeout(statusTimer);
    console.error('Media info extraction error:', err);
    addLog('خطا در دریافت اطلاعات', err?.message || 'خطا', 'error', userId, userName, platformInfo.platform);
    const errorText = `❌ <b>متاسفانه در دریافت اطلاعات این لینک خطایی رخ داد.</b>\nلطفاً از عمومی بودن ویدیو و صحت لینک اطمینان حاصل فرمایید.`;
    if (statusMsg) {
      await client.editMessageText(chatId, statusMsg.message_id, errorText, { parse_mode: 'HTML' }).catch(() => {});
    } else {
      await client.sendMessage(chatId, errorText, { parse_mode: 'HTML' }).catch(() => {});
    }
  }
  } finally {
    inFlightMessagesCount = Math.max(0, inFlightMessagesCount - 1);
  }
}

/**
 * Handle callback query
 */
async function handleCallbackQuery(client: TelegramClient, query: any) {
  const data = query.data || '';
  const chatId = query.message?.chat?.id;
  const userName = query.from?.first_name || 'کاربر';
  const userId = Number(query.from?.id || chatId);

  if (!chatId) return;

  // Handle In-Bot Admin Panel Callbacks (RBAC & nonce checks happen server-side inside handleAdminCallbackQuery)
  if (data.startsWith('adm:')) {
    const handledAdmin = await handleAdminCallbackQuery(client, query);
    if (handledAdmin) return;
  }

  const isAdminActor = isUserAdmin(userId);
  const profile = !isAdminActor ? getUserProfile(userId) : null;
  if (!isAdminActor && profile?.isBanned) {
    await client.answerCallbackQuery(query.id, {
      text: '🚫 حساب شما مسدود شده است.',
      show_alert: true,
    });
    return;
  }

  const cfg = loadBotConfig();
  if (!isAdminActor && (!cfg.general.botEnabled || cfg.general.maintenanceMode)) {
    await client.answerCallbackQuery(query.id, {
      text: '🛠 ربات موقتاً در حالت نگهداری قرار دارد.',
      show_alert: true,
    });
    return;
  }

  // Per-user anti-spam check for non-admins
  if (!isAdminActor) {
    const rl = userRateLimiter.check(String(userId));
    if (!rl.allowed) {
      await client.answerCallbackQuery(query.id, {
        text: `⏳ لطفاً ${Math.ceil(rl.retryAfterMs / 1000)} ثانیه صبر کنید.`,
        show_alert: false,
      });
      return;
    }
  }

  // Handle Force Subscribe Verification Button
  if (data === 'verify_sub') {
    const membership = await checkUserMembership(client, userId);
    if (membership.isMember) {
      await client.answerCallbackQuery(query.id, {
        text: '✅ عضویت شما تایید شد! هم‌اکنون می‌توانید از ربات استفاده کنید.',
        show_alert: true,
      });
      if (query.message?.message_id) {
        await client.deleteMessage(chatId, query.message.message_id).catch(() => {});
      }

      const pendingEntry = pendingBlockedMessages.get(String(userId));
      pendingBlockedMessages.delete(String(userId));
      if (pendingEntry && Date.now() - pendingEntry.savedAt < 15 * 60_000) {
        const blockedMsg = pendingEntry.msg;
        const blockedKey = `${blockedMsg.chat?.id}_${blockedMsg.message_id}`;
        processedMessageKeys.delete(blockedKey);
        await handleIncomingMessage(client, blockedMsg);
      } else {
        await sendStartMessage(client, chatId, userName, userId);
      }
    } else {
      const missingNames = membership.pendingChannels
        .map((c) => c.title || (c.username ? `@${c.username}` : c.id))
        .slice(0, 3)
        .join('، ');
      await client.answerCallbackQuery(query.id, {
        text: `❌ شما هنوز در ${missingNames || 'تمام کانال‌ها'} عضو نشده‌اید! لطفاً ابتدا عضو شوید.`,
        show_alert: true,
      });
      if (query.message?.message_id) {
        const payload = buildForceJoinPayload(membership.pendingChannels);
        await client.editMessageText(chatId, query.message.message_id, payload.text, {
          parse_mode: 'HTML',
          reply_markup: payload.reply_markup,
        }).catch(() => {});
      }
    }
    return;
  }

  // Handle Spotify Collection Track Button
  if (data.startsWith('sp:')) {
    if (!cfg.general.downloadsServiceEnabled || !cfg.download.enabled || !cfg.spotify.enabled) {
      await client.answerCallbackQuery(query.id, {
        text: '⏸ سرویس دانلود اسپاتیفای موقتاً غیرفعال شده است.',
        show_alert: true,
      });
      return;
    }

    const quota = checkUserDailyQuota(userId);
    if (!quota.allowed) {
      await client.answerCallbackQuery(query.id, {
        text: `⚠️ سهمیه روزانه شما (${quota.usedToday}/${quota.limit}) تمام شده است.`,
        show_alert: true,
      });
      return;
    }

    const parts = data.split(':');
    const reqKey = parts[1];
    const trackIdx = parseInt(parts[2] || '0', 10);

    let reqData = pendingRequests.get(reqKey);
    if (!reqData) {
      loadPendingRequests();
      reqData = pendingRequests.get(reqKey);
    }

    const track = reqData?.tracks?.[trackIdx];
    if (!reqData || !track) {
      await client.answerCallbackQuery(query.id, {
        text: '⚠️ این دکمه منقضی شده است. لطفاً لینک آلبوم/پلی‌لیست را مجدد ارسال کنید.',
        show_alert: true,
      });
      return;
    }

    await client.answerCallbackQuery(query.id, {
      text: `🎵 در حال آماده‌سازی ${track.title.slice(0, 30)}...`,
    });

    const queueMsg = await client.sendMessage(
      chatId,
      formatDownloadLoadingText({ percent: 15, stage: 'downloading', isSongFinder: true }),
      { parse_mode: 'HTML' }
    );

    await deliverSpotifyTrack(client, chatId, track.url, queueMsg.message_id, userId, userName);
    return;
  }

  // Handle Instagram Audio Extraction Button
  if (data.startsWith('dl_ig_audio:')) {
    if (!cfg.general.downloadsServiceEnabled || !cfg.download.enabled) {
      await client.answerCallbackQuery(query.id, {
        text: '⏸ سرویس دانلود موقتاً غیرفعال است.',
        show_alert: true,
      });
      return;
    }

    const quota = checkUserDailyQuota(userId);
    if (!quota.allowed) {
      await client.answerCallbackQuery(query.id, {
        text: `⚠️ سهمیه روزانه شما (${quota.usedToday}/${quota.limit}) تمام شده است.`,
        show_alert: true,
      });
      return;
    }

    const parts = data.split(':');
    const reqKey = parts[1];

    let reqData = pendingRequests.get(reqKey);
    if (!reqData) {
      loadPendingRequests();
      reqData = pendingRequests.get(reqKey);
    }

    if (!reqData) {
      await client.answerCallbackQuery(query.id, {
        text: '⚠️ این دکمه منقضی شده است. لطفاً لینک را مجدد ارسال فرمایید.',
        show_alert: true,
      });
      return;
    }

    await client.answerCallbackQuery(query.id, {
      text: '🎵 در حال استخراج و تبدیل صدای ویدیو به فایل صوتی MP3...',
    });

    const initialText = formatDownloadLoadingText({
      percent: 15,
      isSongFinder: true,
      stage: 'downloading',
    });

    const progressMsg = await client.sendMessage(chatId, initialText, { parse_mode: 'HTML' });
    addLog('استخراج صدای اینستاگرام', reqData.title, 'pending', userId, userName, 'instagram');

    let lastEditTime = Date.now();
    let lastPercent = 15;

    const onAudioProgress = async (prog: DownloadProgress) => {
      const now = Date.now();
      const currentP = Math.floor(prog.percent);
      if (now - lastEditTime < 1300 && currentP !== 100) return;
      if (currentP === lastPercent && currentP !== 100) return;
      lastEditTime = now;
      lastPercent = currentP;

      const progressText = formatDownloadLoadingText({
        percent: prog.percent,
        downloadedFormatted: prog.downloadedFormatted,
        totalFormatted: prog.totalFormatted,
        speedFormatted: prog.speedFormatted,
        etaFormatted: prog.etaFormatted,
        isSongFinder: true,
        stage: prog.stage,
      });

      try {
        await client.editMessageText(chatId, progressMsg.message_id, progressText, { parse_mode: 'HTML' });
      } catch {}
    };

    try {
      const targetSource = reqData.localFilePath && fs.existsSync(reqData.localFilePath)
        ? reqData.localFilePath
        : reqData.url;
      const audioResult = await extractInstagramAudio(targetSource, onAudioProgress, userId);
      state.totalDownloads++;
      incrementUserDownloadCount(userId);
      recordUserRequestLog({
        userId,
        platform: 'instagram',
        url: reqData.url,
        action: 'instagram_audio',
        qualityId: 'best_audio',
        status: 'success',
      });

      try {
        await client.editMessageText(
          chatId,
          progressMsg.message_id,
          formatDownloadLoadingText({ percent: 100, stage: 'uploading', isSongFinder: true }),
          { parse_mode: 'HTML' }
        );
      } catch {}

      const botUsername = state.botInfo?.username || 'Bot';
      const audioCaption =
`🎵 <b>صدای استخراج شده از اینستاگرام</b>
━━━━━━━━━━━━━━━━━━━━
🏷 <b>عنوان:</b> ${escapeHtml(reqData.title.slice(0, 100))}
👤 <b>صفحه / سازنده:</b> ${escapeHtml(reqData.uploader)}
📦 <b>حجم:</b> ${audioResult.fileSizeFormatted}
⚡ <b>کیفیت:</b> 320kbps اورجینال MP3
🔗 @${botUsername}`;

      const btns = getMessageActionButtons();
      const actionButtons = btns.length > 0 ? { inline_keyboard: btns } : undefined;

      await client.sendAudioFile(
        chatId,
        audioResult.filePath,
        audioCaption,
        reqData.title.slice(0, 60),
        reqData.uploader.slice(0, 60),
        actionButtons
      );

      await client.deleteMessage(chatId, progressMsg.message_id);
      addLog('استخراج صدای اینستاگرام موفق', `${reqData.uploader} - ${audioResult.fileSizeFormatted}`, 'success', userId, userName, 'instagram');
    } catch (err: any) {
      console.error('Instagram audio extraction error:', err);
      addLog('خطا در استخراج صدای اینستاگرام', err?.message || 'خطا', 'error', userId, userName, 'instagram');
      recordUserRequestLog({
        userId,
        platform: 'instagram',
        url: reqData.url,
        action: 'instagram_audio',
        status: 'error',
        errorMessage: err?.message || 'IG Audio error',
      });
      await client.editMessageText(
        chatId,
        progressMsg.message_id,
        '❌ <b>متاسفانه در استخراج صدای این ویدیو اینستاگرام خطایی رخ داد.</b>\nلطفاً چند لحظه بعد مجدد تلاش فرمایید.',
        { parse_mode: 'HTML' }
      );
    }
    return;
  }

  if (data.startsWith('dl:')) {
    if (!cfg.general.downloadsServiceEnabled || !cfg.download.enabled) {
      await client.answerCallbackQuery(query.id, {
        text: '⏸ سرویس دانلود موقتاً توسط مدیریت غیرفعال است.',
        show_alert: true,
      });
      return;
    }

    const quota = checkUserDailyQuota(userId);
    if (!quota.allowed) {
      await client.answerCallbackQuery(query.id, {
        text: `⚠️ سهمیه روزانه شما (${quota.usedToday}/${quota.limit}) تمام شده است.`,
        show_alert: true,
      });
      return;
    }

    const parts = data.split(':');
    const reqKey = parts[1];
    const qualityId = parts[2] || cfg.download.defaultQuality || 'best_720';

    let reqData = pendingRequests.get(reqKey);
    if (!reqData) {
      loadPendingRequests();
      reqData = pendingRequests.get(reqKey);
    }

    if (!reqData) {
      await client.answerCallbackQuery(query.id, {
        text: '⚠️ این دکمه منقضی شده است. لطفاً لینک را مجدد ارسال فرمایید.',
        show_alert: true,
      });
      return;
    }

    const isSongFinder = qualityId === 'find_song';

    await client.answerCallbackQuery(query.id, {
      text: isSongFinder
        ? '🎵 در حال تشخیص موزیک و آماده‌سازی فایل صوتی...'
        : '⏳ دانلود فایل آغاز شد...',
    });

    const initialText = formatDownloadLoadingText({
      percent: 1,
      isSongFinder,
      stage: 'downloading',
    });

    const progressMsg = await client.sendMessage(chatId, initialText, { parse_mode: 'HTML' });
    addLog(isSongFinder ? 'تشخیص موزیک' : 'شروع دانلود', `پردازش برای ${qualityId}`, 'pending', userId, userName);

    let lastEditTime = Date.now();
    let lastPercent = 1;

    const onDownloadProgress = async (prog: DownloadProgress) => {
      const now = Date.now();
      const currentP = Math.floor(prog.percent);
      if (now - lastEditTime < 1300 && currentP !== 100) return;
      if (currentP === lastPercent && currentP !== 100) return;
      lastEditTime = now;
      lastPercent = currentP;

      const progressText = formatDownloadLoadingText({
        percent: prog.percent,
        downloadedFormatted: prog.downloadedFormatted,
        totalFormatted: prog.totalFormatted,
        speedFormatted: prog.speedFormatted,
        etaFormatted: prog.etaFormatted,
        isSongFinder,
        stage: prog.stage,
      });

      try {
        await client.editMessageText(chatId, progressMsg.message_id, progressText, { parse_mode: 'HTML' });
      } catch {}
    };

    const MAX_TELEGRAM_BOT_SIZE = Math.min(49, Math.max(5, cfg.download.maxFileSizeMb || 49)) * 1024 * 1024;
    const btns = getMessageActionButtons();
    const actionButtons = btns.length > 0 ? { inline_keyboard: btns } : undefined;
    const botUsername = state.botInfo?.username || 'Bot';

    try {
      const result = await downloadMedia(reqData.url, qualityId, onDownloadProgress, userId);
      state.totalDownloads++;
      incrementUserDownloadCount(userId);
      recordUserRequestLog({
        userId,
        platform: reqData.platform,
        url: reqData.url,
        action: isSongFinder ? 'find_song' : 'media_download',
        qualityId,
        status: 'success',
      });

      try {
        await client.editMessageText(
          chatId,
          progressMsg.message_id,
          formatDownloadLoadingText({ percent: 100, stage: 'uploading', isSongFinder }),
          { parse_mode: 'HTML' }
        );
      } catch {}

      const appUrl = (process.env.APP_URL || '').trim().replace(/\/+$/, '');
      const downloadUrl = appUrl.startsWith('http') ? `${appUrl}/api/media/file/${result.id}` : '';

      if (isSongFinder) {
        const song: IdentifiedSong = result.songInfo || await identifySongFromMedia(reqData.url);
        const searchEncoded = encodeURIComponent(song.searchQuery || `${song.artist} ${song.title}`);

        const songCaption =
`🎵 <b>موزیک با موفقیت تشخیص داده شد!</b>
━━━━━━━━━━━━━━━━━━━━
🏷 <b>عنوان قطعه:</b> ${escapeHtml(song.title)}
👤 <b>خواننده / سازنده:</b> ${escapeHtml(song.artist)}
${song.album ? `💿 <b>آلبوم:</b> ${escapeHtml(song.album)}\n` : ''}📦 <b>حجم:</b> ${result.fileSizeFormatted}
⚡ <b>کیفیت:</b> 320kbps اورجینال
🔗 @${botUsername}`;

        const songMarkup = {
          inline_keyboard: [
            [
              { text: '🔍 جستجو در اسپاتیفای', url: `https://open.spotify.com/search/${searchEncoded}` },
              { text: '▶️ یوتیوب موزیک', url: `https://music.youtube.com/search?q=${searchEncoded}` },
            ],
            ...btns,
          ],
        };

        if (result.fileSizeBytes <= MAX_TELEGRAM_BOT_SIZE) {
          await client.sendAudioFile(
            chatId,
            result.filePath,
            songCaption,
            song.title,
            song.artist,
            songMarkup
          );
          await client.deleteMessage(chatId, progressMsg.message_id);
          addLog('تشخیص موزیک موفق', `${song.artist} - ${song.title}`, 'success', userId, userName);
        } else {
          const fallbackMsg = downloadUrl
            ? `${songCaption}\n\n📥 <a href="${downloadUrl}">دانلود مستقیم فایل صوتی</a>`
            : `${songCaption}\n\n⚠️ حجم فایل از سقف ارسال ۵۰ مگابایتی ربات تلگرام بیشتر است.`;
          await client.editMessageText(chatId, progressMsg.message_id, fallbackMsg, {
            parse_mode: 'HTML',
            reply_markup: songMarkup,
          });
        }
        return;
      }

      if (result.fileSizeBytes <= MAX_TELEGRAM_BOT_SIZE) {
        if (qualityId === 'best_audio' || qualityId === 'standard_audio') {
          const audioCaption =
`🎵 <b>${escapeHtml(reqData.title.slice(0, 100))}</b>
━━━━━━━━━━━━━━━━━━━━
📦 <b>حجم:</b> ${result.fileSizeFormatted}
👤 <b>هنرمند / سازنده:</b> ${escapeHtml(reqData.uploader)}
⚡ <b>کیفیت:</b> 320kbps اورجینال
🔗 @${botUsername}`;

          await client.sendAudioFile(
            chatId,
            result.filePath,
            audioCaption,
            reqData.title,
            reqData.uploader,
            actionButtons
          );
        } else {
          const mediaCaption =
`🎬 <b>ویدیو دانلود شده</b>
━━━━━━━━━━━━━━━━━━━━
${escapeHtml(reqData.title.slice(0, 120))}

📦 <b>حجم:</b> ${result.fileSizeFormatted}
👤 <b>سازنده / کانال:</b> ${escapeHtml(reqData.uploader)}
🔗 @${botUsername}`;

          await client.sendVideoFile(
            chatId,
            result.filePath,
            mediaCaption,
            actionButtons
          );
        }

        await client.deleteMessage(chatId, progressMsg.message_id);
        addLog('دانلود موفق', `فایل ${result.fileSizeFormatted} با موفقیت به تلگرام ارسال شد`, 'success', userId, userName);
      } else {
        let sentLighter = false;
        try {
          await client.editMessageText(
            chatId,
            progressMsg.message_id,
            `📦 <b>کیفیت انتخابی بالای ۵۰ مگابایت است؛ در حال آماده‌سازی و ارسال مستقیم فایل ویدیو در تلگرام...</b>`,
            { parse_mode: 'HTML' }
          );
          const lighter = await downloadMedia(reqData.url, 'best_480').catch(() => downloadMedia(reqData.url, 'best_360'));
          if (lighter && lighter.fileSizeBytes <= MAX_TELEGRAM_BOT_SIZE) {
            const mediaCaption =
`🎬 <b>ویدیو (نسخه بهینه‌شده جهت پخش و ارسال در تلگرام)</b>
━━━━━━━━━━━━━━━━━━━━
${escapeHtml(reqData.title.slice(0, 120))}

📦 <b>حجم فایل:</b> ${lighter.fileSizeFormatted}
👤 <b>کانال / سازنده:</b> ${escapeHtml(reqData.uploader)}
🔗 @${botUsername}`;

            await client.sendVideoFile(
              chatId,
              lighter.filePath,
              mediaCaption,
              actionButtons
            );
            await client.deleteMessage(chatId, progressMsg.message_id);
            sentLighter = true;
            addLog('دانلود موفق', `فایل ویدیویی بهینه‌شده در تلگرام تحویل شد`, 'success', userId, userName);
          }
        } catch (e) {
          console.warn('Lighter version delivery fallback error:', e);
        }

        if (!sentLighter) {
          await client.editMessageText(
            chatId,
            progressMsg.message_id,
            `⚠️ <b>حجم این فایل (${result.fileSizeFormatted}) بیش از سقف ارسال ربات تلگرام (۵۰ مگابایت) است.</b>\n\n💡 پیشنهاد: کیفیت‌های سبک‌تر مثل <b>🎥 720p HD</b> یا <b>📱 480p SD</b> یا کیفیت صوتی <b>🎵 دانلود فایل صوتی اورجینال</b> را انتخاب کنید تا مستقیماً به صورت فایل برایتان ارسال شود.`,
            {
              parse_mode: 'HTML',
              reply_markup: actionButtons,
            }
          );
          addLog('حجم بالا', `فایل ${result.fileSizeFormatted} بیش از سقف تلگرام`, 'pending', userId, userName);
        }
      }
    } catch (err: any) {
      console.error('Error downloading:', err);
      const errMsg = err?.message || '';

      let recovered = false;
      const isAudioReq = qualityId === 'best_audio' || qualityId === 'standard_audio' || qualityId === 'find_song';

      try {
        await client.editMessageText(
          chatId,
          progressMsg.message_id,
          `🔄 <b>در حال تلاش مجدد و آماده‌سازی مستقیم فایل...</b>`,
          { parse_mode: 'HTML' }
        );

        const recoveryQuality = isAudioReq ? 'best_audio' : 'best_360';
        const recoveryResult = await downloadMedia(reqData.url, recoveryQuality);

        if (recoveryResult && recoveryResult.fileSizeBytes <= MAX_TELEGRAM_BOT_SIZE) {
          if (isAudioReq) {
            const audioCaption =
`🎵 <b>${escapeHtml(reqData.title.slice(0, 100))}</b>
━━━━━━━━━━━━━━━━━━━━
📦 <b>حجم:</b> ${recoveryResult.fileSizeFormatted}
👤 <b>هنرمند / سازنده:</b> ${escapeHtml(reqData.uploader)}
🔗 @${botUsername}`;

            await client.sendAudioFile(
              chatId,
              recoveryResult.filePath,
              audioCaption,
              reqData.title,
              reqData.uploader,
              actionButtons
            );
          } else {
            const mediaCaption =
`🎬 <b>${escapeHtml(reqData.title.slice(0, 120))}</b>
━━━━━━━━━━━━━━━━━━━━
📦 <b>حجم:</b> ${recoveryResult.fileSizeFormatted}
👤 <b>کانال / سازنده:</b> ${escapeHtml(reqData.uploader)}
🔗 @${botUsername}`;

            await client.sendVideoFile(
              chatId,
              recoveryResult.filePath,
              mediaCaption,
              actionButtons
            );
          }

          await client.deleteMessage(chatId, progressMsg.message_id);
          recovered = true;
          addLog('دانلود موفق (بازیابی خودکار)', `فایل تحویل شد`, 'success', userId, userName);
        }
      } catch (recoveryErr) {
        console.warn('Recovery download failed:', recoveryErr);
      }

      if (!recovered) {
        addLog('خطا در دانلود', errMsg, 'error', userId, userName, reqData.platform);
        recordUserRequestLog({
          userId,
          platform: reqData.platform,
          url: reqData.url,
          action: isSongFinder ? 'find_song' : 'media_download',
          qualityId,
          status: 'error',
          errorMessage: errMsg,
        });

        if (errMsg.includes("Sign in to confirm you're not a bot") || errMsg.includes("confirm you’re not a bot")) {
          await client.editMessageText(
            chatId,
            progressMsg.message_id,
            `⚠️ <b>یوتیوب به دلیل دانلود از دیتاسنتر ابری نیاز به کوکی ورود دارد.</b>\n\nمدیر ربات می‌تواند با رفتن به بخش <b>👑 پنل مدیریت (/admin) ➔ 🍪 کوکی‌ها</b>، کوکی‌های یوتیوب را ثبت کند تا تمامی ویدیوها بدون محدودیت به صورت فایل ارسال شوند.`,
            { parse_mode: 'HTML', reply_markup: actionButtons }
          );
        } else {
          const customErr = (cfg.general.errorMessage || '').trim();
          await client.editMessageText(
            chatId,
            progressMsg.message_id,
            customErr
              ? `❌ <b>${escapeHtml(customErr)}</b>`
              : '❌ <b>متاسفانه در پردازش و ارسال فایل این رسانه خطایی رخ داد.</b>\nلطفاً چند لحظه بعد مجدد تلاش کنید یا کیفیت دیگری را انتخاب فرمایید.',
            { parse_mode: 'HTML', reply_markup: actionButtons }
          );
        }
      }
    }
    return;
  }

  await client.answerCallbackQuery(query.id).catch(() => null);
}

/**
 * Main polling loop with exponential backoff, jitter, and permanent error stop
 */
async function startPollingLoop(client: TelegramClient) {
  let offset = 0;
  let consecutiveErrors = 0;
  const myGeneration = ++activePollGeneration;
  if (pollingAbortController) {
    try { pollingAbortController.abort(); } catch {}
  }
  const localController = new AbortController();
  pollingAbortController = localController;
  lastPollActivityTime = Date.now();
  ensurePollingWatchdog(client);

  while (!isShuttingDown && !localController.signal.aborted && myGeneration === activePollGeneration) {
    try {
      const updates = await client.getUpdates(offset, 25, localController.signal);
      consecutiveErrors = 0;
      state.lastError = null;
      lastPollActivityTime = Date.now();

      for (const update of updates) {
        offset = update.update_id + 1;

        if (processedUpdateIds.has(update.update_id)) {
          continue;
        }
        processedUpdateIds.add(update.update_id);
        if (processedUpdateIds.size > 2000) {
          const oldest = Array.from(processedUpdateIds).slice(0, 500);
          for (const id of oldest) processedUpdateIds.delete(id);
        }

        if (update.message) {
          handleIncomingMessage(client, update.message).catch((e) => console.error('Handle message error:', e));
        } else if (update.callback_query) {
          handleCallbackQuery(client, update.callback_query).catch((e) => console.error('Handle callback error:', e));
        }
      }
    } catch (err: any) {
      if (isShuttingDown || localController.signal.aborted || myGeneration !== activePollGeneration) {
        break;
      }

      const errMsg = String(err?.message || err);
      if (isPermanentTelegramAuthError(errMsg)) {
        state.isActive = false;
        state.lastError = `توکن ربات نامعتبر است یا لغو شده (${errMsg})`;
        console.error('[TelegramBot] Permanent authentication error, stopping polling:', errMsg);
        addLog('توقف ربات (خطای توکن)', errMsg, 'error');
        break;
      }

      // Self-heal if an external webhook was registered that blocks getUpdates
      const isWebhookConflict =
        errMsg.toLowerCase().includes("can't use getupdates method while webhook is active") ||
        (errMsg.toLowerCase().includes('webhook') && !errMsg.toLowerCase().includes('terminated by other'));
      if (isWebhookConflict) {
        try {
          await client.deleteWebhook(false);
          state.isWebhookMode = false;
          state.webhookUrl = null;
          state.lastError = null;
          lastPollActivityTime = Date.now();
          addLog('ترمیم خودکار اتصال', 'وب‌هوک مسدودکننده پاک شد و دریافت پیام‌ها (Polling) ادامه یافت.');
          await abortableSleep(1000, localController.signal);
          continue;
        } catch {}
      }

      const isMultipleInstanceConflict =
        errMsg.toLowerCase().includes('terminated by other getupdates') ||
        errMsg.toLowerCase().includes('conflict');
      if (isMultipleInstanceConflict) {
        consecutiveErrors++;
        const conflictWait = calculateBackoffMs(Math.min(consecutiveErrors, 3), 15_000, 60_000);
        state.lastError = 'تداخل: نمونه دیگری از این ربات در حال Polling است';
        console.warn(`[TelegramBot] 409 Conflict detected. Backing off ${Math.round(conflictWait / 1000)}s...`);
        lastPollActivityTime = Date.now();
        await abortableSleep(conflictWait, localController.signal);
        lastPollActivityTime = Date.now();
        continue;
      }

      consecutiveErrors++;
      const backoffMs = calculateBackoffMs(consecutiveErrors, 2000, 60_000);
      console.warn(`[TelegramBot] Polling error (attempt #${consecutiveErrors}), retrying in ${backoffMs}ms:`, errMsg);
      state.lastError = errMsg || 'Polling error';
      if (consecutiveErrors === 5) {
        void notifyOwnerAlert(
          'telegram_polling_errors',
          `🚨 <b>هشدار اختلال اتصال به تلگرام:</b>\nربات ۵ بار پیاپی در Polling به خطا خورده است و در حال بازیابی خودکار می‌باشد.\n<code>${escapeHtml(errMsg.slice(0, 180))}</code>`,
          20 * 60_000
        );
      }
      lastPollActivityTime = Date.now();
      await abortableSleep(backoffMs, localController.signal);
    }
  }

  // Self-restart only if loop exited unexpectedly while active & not shutting down
  if (
    !isShuttingDown &&
    state.isActive &&
    !state.isWebhookMode &&
    !localController.signal.aborted &&
    myGeneration === activePollGeneration
  ) {
    console.warn('[TelegramBot] Polling loop finished unexpectedly. Restarting in 2s...');
    setTimeout(() => {
      if (!isShuttingDown && state.isActive && !state.isWebhookMode && myGeneration === activePollGeneration) {
        startPollingLoop(client);
      }
    }, 2000).unref?.();
  }
}

/**
 * Start Telegram Bot
 */
export async function startTelegramBot(token?: string): Promise<{ success: boolean; message: string; botInfo?: any; permanentError?: boolean }> {
  isShuttingDown = false;
  if (token) {
    currentToken = token.trim();
  }

  if (!currentToken) {
    state.isActive = false;
    state.lastError = 'متغیر محیطی TELEGRAM_BOT_TOKEN تنظیم نشده است.';
    return {
      success: false,
      permanentError: true,
      message: 'توکن ربات تلگرام (TELEGRAM_BOT_TOKEN) در فایل .env تنظیم نشده است.',
    };
  }

  if (pollingAbortController) {
    pollingAbortController.abort();
    pollingAbortController = null;
  }

  try {
    const client = new TelegramClient(currentToken);
    activeClient = client;
    ensureBotBridgeRegistered();

    const me = await client.getMe();
    state.botInfo = {
      id: me.id,
      username: me.username,
      first_name: me.first_name,
    };
    state.isActive = true;
    state.lastError = null;

    // Clear any stale webhook so standalone Long Polling starts immediately unless webhook mode is desired
    const whInfo = await client.getWebhookInfo().catch(() => null);
    if (whInfo?.url && process.env.BOT_MODE !== 'webhook') {
      await client.deleteWebhook(false).catch(() => null);
      state.isWebhookMode = false;
      state.webhookUrl = null;
      addLog('اتصال ربات', `ربات @${me.username} متصل شد (وب‌هوک قبلی پاک شد و Polling زنده فعال گردید).`);
      startPollingLoop(client);
    } else if (whInfo?.url && process.env.BOT_MODE === 'webhook') {
      state.isWebhookMode = true;
      state.webhookUrl = whInfo.url;
      addLog('اتصال ربات', `ربات @${me.username} متصل شد (حالت وب‌هوک فعال: ${whInfo.url})`);
    } else {
      state.isWebhookMode = false;
      state.webhookUrl = null;
      addLog('اتصال ربات', `ربات @${me.username} با موفقیت به تلگرام متصل شد (حالت Polling).`);
      startPollingLoop(client);
    }

    return {
      success: true,
      message: `ربات @${me.username} با موفقیت فعال شد و آماده پاسخگویی است.`,
      botInfo: state.botInfo,
    };
  } catch (err: any) {
    const errMsg = String(err?.message || 'خطا در اتصال به تلگرام');
    state.isActive = false;
    state.lastError = errMsg;
    console.error('Failed to start Telegram Bot:', err);
    return {
      success: false,
      permanentError: isPermanentTelegramAuthError(errMsg),
      message: `خطا در اتصال به تلگرام: ${errMsg}`,
    };
  }
}

/**
 * Gracefully stop polling and flush persistent caches synchronously
 */
export function stopTelegramBot(): void {
  isShuttingDown = true;
  state.isActive = false;
  activePollGeneration++;

  if (pollingAbortController) {
    try { pollingAbortController.abort(); } catch {}
    pollingAbortController = null;
  }
  if (watchdogTimer) {
    clearInterval(watchdogTimer);
    watchdogTimer = null;
  }

  flushPendingRequestsSync();
  flushBotUsersSync();
}

/**
 * Handle incoming Webhook update from Telegram
 */
export async function handleWebhookUpdate(update: any) {
  if (!activeClient) {
    if (currentToken) {
      activeClient = new TelegramClient(currentToken);
    } else {
      return;
    }
  }

  try {
    if (update.message) {
      await handleIncomingMessage(activeClient, update.message);
    } else if (update.callback_query) {
      await handleCallbackQuery(activeClient, update.callback_query);
    }
  } catch (err: any) {
    console.error('Webhook processing error:', err);
  }
}

/**
 * Configure Telegram Webhook (with pre-flight POST verification)
 */
export async function setBotWebhook(webhookUrl: string): Promise<{ success: boolean; message: string }> {
  try {
    if (!activeClient) {
      if (!currentToken) return { success: false, message: 'توکن ربات تنظیم نشده است.' };
      activeClient = new TelegramClient(currentToken);
    }

    try {
      const testRes = await fetch(webhookUrl, {
        method: 'POST',
        redirect: 'manual',
        signal: AbortSignal.timeout(12_000),
        headers: {
          'Content-Type': 'application/json',
          'x-telegram-bot-api-secret-token': getWebhookSecretToken(currentToken),
        },
        body: JSON.stringify({ update_id: 0 }),
      });
      const check = evaluateWebhookCheckStatus(testRes.status);
      if (!check.valid) {
        addLog('رد وب‌هوک نامعتبر', check.reasonFa || `HTTP ${testRes.status}`, 'error');
        if (!pollingAbortController) {
          startPollingLoop(activeClient);
        }
        return {
          success: false,
          message: check.reasonFa || `آدرس وب‌هوک نامعتبر است (HTTP ${testRes.status}). ربات در حالت Polling فعال ماند.`,
        };
      }
    } catch (netErr: any) {
      return {
        success: false,
        message: `امکان برقراری ارتباط با آدرس وب‌هوک وجود ندارد (${netErr?.message || 'Network Error'}). ربات در حالت Polling فعال نگه داشته شد.`,
      };
    }

    if (pollingAbortController) {
      pollingAbortController.abort();
      pollingAbortController = null;
    }

    await activeClient.setWebhook(webhookUrl);
    state.isWebhookMode = true;
    state.webhookUrl = webhookUrl;
    addLog('تنظیم وب‌هوک', `وب‌هوک با آدرس ${webhookUrl} فعال شد.`);
    return {
      success: true,
      message: `وب‌هوک تلگرام با موفقیت بررسی و ثبت شد.`,
    };
  } catch (err: any) {
    console.error('Error setting webhook:', err);
    return { success: false, message: `خطا در ثبت وب‌هوک: ${err?.message || 'نامشخص'}` };
  }
}

/**
 * Remove Telegram Webhook and resume polling
 */
export async function removeBotWebhook(): Promise<{ success: boolean; message: string }> {
  try {
    if (!activeClient) {
      if (!currentToken) return { success: false, message: 'توکن ربات تنظیم نشده است.' };
      activeClient = new TelegramClient(currentToken);
    }

    await activeClient.deleteWebhook(false);
    state.isWebhookMode = false;
    state.webhookUrl = null;
    addLog('حذف وب‌هوک', 'وب‌هوک حذف شد و ربات به حالت Polling بازگشت.');

    startPollingLoop(activeClient);
    return {
      success: true,
      message: 'وب‌هوک حذف شد و ربات در حالت Polling شروع به کار کرد.',
    };
  } catch (err: any) {
    console.error('Error deleting webhook:', err);
    return { success: false, message: `خطا در حذف وب‌هوک: ${err?.message || 'نامشخص'}` };
  }
}

/**
 * Get Telegram Webhook info
 */
export async function getBotWebhookInfo() {
  if (!activeClient) {
    if (currentToken) {
      activeClient = new TelegramClient(currentToken);
    } else {
      return { url: '', has_custom_certificate: false, pending_update_count: 0 };
    }
  }
  return await activeClient.getWebhookInfo();
}
