#!/usr/bin/env bash
# نصب و استقرار مستقل ربات تلگرام روی AWS EC2 (Ubuntu/Debian)
# اجرا: bash setup.sh
set -euo pipefail
cd "$(dirname "$0")"

APP_DIR="$(pwd)"
mkdir -p bin logs data backups /tmp/downloads
chmod 700 data backups

echo "=== ۱/۶ نصب پیش‌نیازهای سیستم‌عامل ==="
sudo apt-get update -y
sudo apt-get install -y python3 ffmpeg curl ca-certificates git

# ساخت Swap در سرورهای کم‌رم (مانند t2.micro / t3.micro)
if [ "$(free -m | awk '/Swap/{print $2}')" -lt 1000 ]; then
  echo "ساخت Swap دو گیگابایتی..."
  sudo fallocate -l 2G /swapfile 2>/dev/null || sudo dd if=/dev/zero of=/swapfile bs=1M count=2048
  sudo chmod 600 /swapfile
  sudo mkswap /swapfile
  sudo swapon /swapfile
  grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
fi

echo "=== ۲/۶ نصب Node.js 22 و PM2 ==="
NODE_MAJOR=0
if command -v node >/dev/null 2>&1; then
  NODE_MAJOR=$(node -v | sed 's/v\([0-9]*\).*/\1/')
fi
if [ "$NODE_MAJOR" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

if ! command -v pm2 >/dev/null 2>&1; then
  sudo npm install -g pm2
fi

# تنظیم چرخش خودکار لاگ‌ها برای جلوگیری از پر شدن دیسک EC2
pm2 install pm2-logrotate >/dev/null 2>&1 || true
pm2 set pm2-logrotate:max_size 10M >/dev/null 2>&1 || true
pm2 set pm2-logrotate:retain 5 >/dev/null 2>&1 || true
pm2 set pm2-logrotate:compress true >/dev/null 2>&1 || true

echo "=== ۳/۶ نصب وابستگی‌ها و دریافت باینری yt-dlp ==="
if [ ! -s bin/yt-dlp ] || head -n 1 bin/yt-dlp 2>/dev/null | grep -q '^#!.*python'; then
  ARCH=$(uname -m)
  if [ "$ARCH" = "aarch64" ] || [ "$ARCH" = "arm64" ]; then YT_BIN="yt-dlp_linux_aarch64"; else YT_BIN="yt-dlp_linux"; fi
  curl -fsSL "https://github.com/yt-dlp/yt-dlp/releases/latest/download/${YT_BIN}" -o bin/yt-dlp
fi
chmod 755 bin/yt-dlp

if [ -f package-lock.json ]; then
  npm ci --no-audit --no-fund
else
  npm install --no-audit --no-fund
fi

echo "=== ۴/۶ تایید TypeScript و تست‌ها ==="
npm run build
npm test

echo "=== ۵/۶ پیکربندی ایمن .env ==="
if [ ! -f .env ]; then
  cp .env.example .env
fi
chmod 600 .env

set -a
# shellcheck disable=SC1091
source .env || true
set +a

if [ -z "${TELEGRAM_BOT_TOKEN:-}" ] || [ "${TELEGRAM_BOT_TOKEN:-}" = "YOUR_TELEGRAM_BOT_TOKEN" ]; then
  read -r -s -p "توکن ربات تلگرام را وارد کنید (نمایش داده نمی‌شود): " INPUT_TOKEN
  echo
  if [ -z "$INPUT_TOKEN" ]; then
    echo "❌ توکن نمی‌تواند خالی باشد."
    exit 1
  fi
  TELEGRAM_BOT_TOKEN="$INPUT_TOKEN"
  if grep -q '^TELEGRAM_BOT_TOKEN=' .env; then
    sed -i "s|^TELEGRAM_BOT_TOKEN=.*|TELEGRAM_BOT_TOKEN=\"${TELEGRAM_BOT_TOKEN}\"|" .env
  else
    echo "TELEGRAM_BOT_TOKEN=\"${TELEGRAM_BOT_TOKEN}\"" >> .env
  fi
fi

if [ -z "${SUPER_ADMIN_ID:-}" ] || [ "${SUPER_ADMIN_ID:-}" = "YOUR_TELEGRAM_USER_ID" ]; then
  read -r -p "شناسه عددی تلگرام ادمین اصلی (SUPER_ADMIN_ID): " INPUT_ADMIN
  if [ -n "$INPUT_ADMIN" ]; then
    sed -i "s|^SUPER_ADMIN_ID=.*|SUPER_ADMIN_ID=\"${INPUT_ADMIN}\"|" .env
  fi
fi

if [ -z "${ADMIN_API_KEY:-}" ] || [ "${ADMIN_API_KEY:-}" = "CHANGE_ME_TO_A_LONG_RANDOM_SECRET" ]; then
  GENERATED_KEY=$(node -e "console.log(require('crypto').randomBytes(24).toString('hex'))")
  sed -i "s|^ADMIN_API_KEY=.*|ADMIN_API_KEY=\"${GENERATED_KEY}\"|" .env
fi

chmod 600 .env

echo "=== ۶/۶ راه‌اندازی تک‌نمونه‌ای با PM2 و فعال‌سازی Boot Auto-Start ==="
# توقف هر نمونه قدیمی برای جلوگیری از تداخل 409 Polling
pm2 delete telegram-bot >/dev/null 2>&1 || true
pkill -f "tsx.*src/index.ts" >/dev/null 2>&1 || true
rm -f /tmp/telegram-boy.lock

pm2 start "$APP_DIR/ecosystem.config.cjs" --only telegram-bot
pm2 save

# فعال‌سازی اجرای خودکار پس از ری‌استارت EC2
STARTUP_CMD=$(pm2 startup systemd -u "$USER" --hp "$HOME" | grep -E "sudo .*pm2" | tail -n 1 || true)
if [ -n "$STARTUP_CMD" ]; then
  eval "$STARTUP_CMD" >/dev/null 2>&1 || true
fi
pm2 save

echo
echo "⏳ در حال بررسی سلامت سرویس (۱۰ ثانیه)..."
sleep 10
HEALTH=$(curl -fsS --max-time 5 http://127.0.0.1:3000/health || echo "failed")
echo "پاسخ Healthcheck: $HEALTH"
pm2 status telegram-bot

if echo "$HEALTH" | grep -q '"status":"ok"'; then
  echo "✅ ربات مستقل با موفقیت روی EC2 نصب و اجرا شد!"
else
  echo "⚠️ هشدار: پاسخ Healthcheck دریافت نشد. آخرین لاگ‌ها:"
  pm2 logs telegram-bot --lines 30 --nostream
  exit 1
fi
