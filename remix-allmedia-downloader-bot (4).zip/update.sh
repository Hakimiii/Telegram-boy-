#!/usr/bin/env bash
# اسکریپت آپدیت ایمن ربات روی AWS EC2 با تست خودکار و Rollback در صورت خطا
# اجرا: bash update.sh
set -euo pipefail
cd "$(dirname "$0")"

PREV_COMMIT=$(git rev-parse HEAD 2>/dev/null || echo "")
mkdir -p data backups bin logs
chmod 700 data backups 2>/dev/null || true

PRE_UPDATE_BACKUP="backups/pre-update-$(date +%Y%m%d-%H%M%S).db"
if [ -f data/bot.db ]; then
  echo "=== ۰/۴ تهیه نسخه پشتیبان آنلاین از دیتابیس قبل از آپدیت ==="
  node -e '
    const fs = require("node:fs");
    if (fs.existsSync("data/bot.db")) {
      const { DatabaseSync } = require("node:sqlite");
      const db = new DatabaseSync("data/bot.db");
      db.exec("PRAGMA wal_checkpoint(TRUNCATE);");
      db.close();
      fs.copyFileSync("data/bot.db", process.argv[1]);
    }
  ' "$PRE_UPDATE_BACKUP" || true
fi

rollback() {
  echo "❌ خطا در فرآیند آپدیت! در حال بازگشت به نسخه قبلی..."
  if [ -f "$PRE_UPDATE_BACKUP" ]; then
    cp "$PRE_UPDATE_BACKUP" data/bot.db
    chmod 600 data/bot.db 2>/dev/null || true
    echo "💾 دیتابیس به نسخه پیش از آپدیت بازگردانده شد."
  fi
  if [ -n "$PREV_COMMIT" ]; then
    git reset --hard "$PREV_COMMIT"
    npm ci --no-audit --no-fund 2>/dev/null || npm install --no-audit --no-fund
    pm2 restart ecosystem.config.cjs --only telegram-bot --update-env || pm2 start ecosystem.config.cjs --only telegram-bot
    echo "↩️ ربات با موفقیت به کامیت قبلی ($PREV_COMMIT) بازگردانده شد."
  fi
  exit 1
}

trap rollback ERR

echo "=== ۱/۴ دریافت آخرین تغییرات از GitHub ==="
git pull --ff-only

echo "=== ۲/۴ نصب وابستگی‌ها و تایید سلامت کد ==="
if [ -f package-lock.json ]; then
  npm ci --no-audit --no-fund
else
  npm install --no-audit --no-fund
fi

npm run build
npm test

echo "=== ۳/۴ بروزرسانی yt-dlp و ری‌استارت تک‌نمونه‌ای PM2 ==="
mkdir -p bin logs data backups
if [ -x bin/yt-dlp ]; then
  bin/yt-dlp -U >/dev/null 2>&1 || true
fi

if pm2 describe telegram-bot >/dev/null 2>&1; then
  pm2 restart ecosystem.config.cjs --only telegram-bot --update-env
else
  pm2 start ecosystem.config.cjs --only telegram-bot
fi
pm2 save

echo "=== ۴/۴ بررسی سلامت پس از آپدیت ==="
sleep 6
HEALTH=$(curl -fsS --max-time 8 http://127.0.0.1:3000/health || echo "")
if ! echo "$HEALTH" | grep -q '"status":"ok"'; then
  echo "❌ سرویس پس از آپدیت پاسخ سالم نداد!"
  rollback
fi

echo "✅ آپدیت ربات با موفقیت کامل و بدون خطا انجام شد!"
pm2 status telegram-bot
